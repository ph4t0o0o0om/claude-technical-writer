# CARBOOKING SYSTEM
## Comprehensive User Manual

### Version Information
- **Document Version:** 1.0
- **Last Updated:** 2026-04-29
- **System Version:** Car Booking System v1.0
- **Application URL:** https://headcount.employeeskiosk.com

---

## Table of Contents

1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [System Overview](#system-overview)
4. [Before Appointment Phase](#before-appointment-phase)
5. [Approval Workflow](#approval-workflow)
6. [Scheduling](#scheduling)
7. [After Appointment Phase](#after-appointment-phase)
8. [Role-Specific Guides](#role-specific-guides)
9. [Financial and Billing Information](#financial-and-billing-information)
10. [Driver and Vehicle Management](#driver-and-vehicle-management)
11. [Reports and Analytics](#reports-and-analytics)
12. [Best Practices](#best-practices)
13. [Troubleshooting and FAQs](#troubleshooting-and-faqs)
14. [Reference Information](#reference-information)
15. [Glossary](#glossary)

---

## Introduction

### What is the Car Booking System?

The **Car Booking System** is an internal web application designed to manage and streamline vehicle reservation requests, approvals, scheduling, and post-usage reporting within an organization.

The system simulates a real-world logistics and transportation workflow, allowing users to:
- Submit booking requests for vehicles
- Route requests through a multi-level approval process
- Assign vehicles and drivers
- Track operational and financial details after each trip
- Generate comprehensive reports and analytics

### System Purpose

The Car Booking System is intended for:

- **Operational Efficiency** - Digitizing manual booking processes and reducing administrative overhead
- **Approval Workflow Management** - Enforcing structured, multi-level approval processes across different roles
- **Fleet and Driver Coordination** - Efficient assignment and management of vehicles and drivers
- **Financial Tracking and Reporting** - Transparent tracking of transportation costs and expenses
- **Audit and Transparency** - Complete audit trail through timestamp tracking and comprehensive logs

### Key Features

- Dashboard with real-time booking details
- Timestamp tracking for every edit and approval
- Mobile-responsive dashboard access
- Printable and downloadable reports
- Export data to Excel
- Role-based approvals and permissions
- Complete end-to-end booking lifecycle tracking
- Full audit trail via timestamps
- Financial transparency and reporting
- Mobile accessibility

---

## Getting Started

### Accessing the System

#### Step 1: Open Your Web Browser

Open your preferred web browser (Chrome, Firefox, Safari, or Edge).

#### Step 2: Navigate to the Application URL

Enter the following URL in your browser's address bar:

```
https://headcount.employeeskiosk.com
```

#### Step 3: Enter Your Login Credentials

When the login page appears, enter:

- **Email:** benchakino04@gmail.com
- **Password:** 123456

#### Step 4: Click Login

Click the "Login" or "Sign In" button to authenticate.

#### Step 5: Access the Car Booking System

Once logged in, navigate to the Car Booking section of the application.

### System Requirements

- **Web Browser:** Chrome, Firefox, Safari, or Edge (latest versions recommended)
- **Internet Connection:** Required for accessing the web-based application
- **Device:** Works on desktops, tablets, and mobile devices
- **JavaScript:** Must be enabled in your browser

---

## System Overview

### Main Dashboard

The main dashboard provides at-a-glance information about:

- **Active Bookings** - Number of current/upcoming vehicle bookings
- **Pending Approvals** - Bookings awaiting your review
- **Scheduled Trips** - Confirmed bookings with schedule details
- **Recent Activity** - Latest bookings and approvals
- **Financial Summary** - Total transportation costs and expenses

### Navigation Structure

The application uses a left sidebar navigation menu organized as follows:

#### Main Sections:
1. **Dashboard** - Overview and analytics
2. **Bookings** - Create and manage booking requests
3. **Approvals** - Review and approve pending requests (role-dependent)
4. **Schedule** - View and manage booking schedules
5. **Trip Reports** - Access post-trip reports and encoding
6. **Financial** - View financial tracking and billing
7. **Reports** - Generate and export reports

### Key Interface Elements

- **Top Navigation Bar** - Displays user profile, notifications, settings, and search
- **Sidebar Menu** - Provides access to all main system functions
- **Action Buttons** - Create, Edit, Delete, Export, Print buttons appear contextually
- **Data Tables** - Display booking records with sorting, filtering, and pagination options
- **Forms** - Used for creating and editing bookings and trip details

---

## Before Appointment Phase

### Phase Overview

The Before Appointment Phase includes three main steps:
1. Request Creation
2. Approval Workflow
3. Scheduling

### Step 1: Request Creation

#### Creating a New Booking Request

The requester must fill out the Car Booking form with all required information.

**How to Create a Booking:**

1. Navigate to the **Bookings** section from the main menu
2. Click the **"New Booking"** or **"Create Request"** button
3. Fill out the booking form with the following required fields:

#### Required Information

| Field | Description | Example |
|-------|-------------|---------|
| **Requester Name** | Full name of the person requesting the vehicle | John Smith |
| **Requester Department** | Department of the requester | Operations |
| **Date of Filing** | Date when the request is submitted | 2026-04-29 |
| **Client Name** | Name of the client for this trip | Fiberhome |
| **Company Assigned** | Company responsible for billing | Fiberhome – Primus |
| **Number of Passengers** | Total number of people traveling | 4 |
| **Pickup Date** | Date the vehicle is needed | 2026-05-10 |
| **Pickup Time** | Time for vehicle pickup | 08:00 AM |
| **Pickup Location** | Starting location for the trip | Office Address, BGC |
| **Drop-off Location / Purpose** | Destination and purpose of the trip | Client Site - Makati |

#### Step-by-Step Instructions

1. **Enter Requester Information:**
   - Type your full name in the Requester Name field
   - Select your department from the Department dropdown

2. **Select Filing Date:**
   - Click on the Date of Filing field
   - Select today's date from the calendar picker

3. **Enter Client Details:**
   - Type the client name (e.g., "Fiberhome")
   - Select or enter the Company Assigned (e.g., "Fiberhome – Primus")

4. **Specify Passenger Count:**
   - Enter the number of passengers (including yourself)
   - This helps determine vehicle type allocation

5. **Set Pickup Details:**
   - Click on the Pickup Date field and select the required date
   - Click on the Pickup Time field and select or type the time
   - Enter the specific pickup location address

6. **Enter Destination:**
   - Provide the drop-off location
   - Specify the purpose of the trip

7. **Review Information:**
   - Double-check all entered information for accuracy
   - Ensure all required fields are completed

8. **Submit Request:**
   - Click the **"Submit"** button to create the booking request
   - A confirmation message will appear indicating successful submission
   - You will receive a reference number for tracking

#### Important Notes

- All fields marked with **\*** are mandatory
- Information must be accurate and complete before submission
- Double-check the pickup date and time as these cannot be easily changed later
- Ensure the drop-off location is clearly specified for routing purposes
- The system will validate the location against the billing rate table

### Editing Booking Requests

**Permission:** Requester can edit booking **before RSB approval only**

#### How to Edit a Booking

1. Navigate to your submitted bookings in the **Bookings** section
2. Find the booking with status "Draft" or "Pending Department Head Approval"
3. Click the **"Edit"** button (pencil icon)
4. Modify the required fields
5. Click **"Save"** to update the booking
6. A timestamp will record the edit

**Important:** Once RSB approves the booking, you can no longer edit it directly. Contact the RSB if changes are needed after their approval.

### Important Workflow Controls

- **Rejected Bookings:** Can be rejected at any approval stage if requirements are not met
- **Cancelled Bookings:** Can be cancelled even after approval in emergency cases
- **Extended Editing:** RSB and WVB have extended editing permissions beyond the standard approval workflow

---

## Approval Workflow

### Workflow Overview

All booking requests undergo a **sequential approval process** from multiple roles. Each approver must review and approve (or reject) the request before it moves to the next stage.

### Approval Stages

The booking request progresses through the following sequential approvals:

#### Stage 1: Department Head Approval

**Role:** Department Head

**Responsibilities:**
- Review the booking request from their department
- Verify that the trip is business-justified
- Approve or reject based on departmental policies
- Add comments or notes if rejecting

**Status:** "Awaiting Department Head Approval"

**Actions Available:**
- ✓ Approve - Move to next stage
- ✗ Reject - Return to requester with feedback
- Edit - Add comments or modify details

---

#### Stage 2: RSB (Reservation Service Bureau) Approval

**Role:** RSB (Reservation Service Bureau)

**Responsibilities:**
- Review request from Department Head approval
- Verify booking feasibility and administrative requirements
- Check for any policy violations
- Approve or reject the request
- Add notes for subsequent approvers

**Status:** "Awaiting RSB Approval"

**Actions Available:**
- ✓ Approve - Move to next stage
- ✗ Reject - Return to requester
- Edit - Modify details or add comments
- Extended Editing - Can edit more fields than requester

---

#### Stage 3: WVB (Vehicle and Driver Assignment) Approval

**Role:** WVB (Vehicle and Driver Assignment Bureau)

**Responsibilities:**
- Review request from RSB approval
- **Assign appropriate vehicle** based on passenger count and trip requirements
- **Assign suitable driver** based on availability and qualifications
- Approve if vehicle and driver are available
- Reject if no suitable vehicle/driver is available
- Manage vehicle and driver allocation

**Status:** "Awaiting WVB Approval"

**Key Action - Vehicle Assignment:**

During WVB approval, a vehicle must be assigned:
- Select from available vehicles
- Vehicle selection based on:
  - Number of passengers
  - Trip distance
  - Vehicle availability
- Vehicle options include:
  - Innova Gray (Primetech)
  - Innova Red (Primus)
  - Innova Hybrid (Primus)
  - Tamaraw (Primus)

**Key Action - Driver Assignment:**

During WVB approval, a driver must be assigned:
- Select from available drivers
- Driver assigned to corresponding vehicle
- Driver mapping follows company assignments

**Actions Available:**
- ✓ Approve (with vehicle and driver assigned) - Move to next stage
- ✗ Reject - If no vehicle/driver available
- Edit - Modify vehicle, driver, or other details
- Extended Editing - Can edit all relevant fields

**Critical Note:** Booking can be **rejected by WVB** if no vehicle/driver is available.

---

#### Stage 4: ODJ (Operations and Dispatch) Approval

**Role:** ODJ (Operations and Dispatch)

**Responsibilities:**
- Review the complete request with vehicle/driver assignments
- Verify operational feasibility
- Confirm dispatch procedures
- Approve or reject based on operational constraints

**Status:** "Awaiting ODJ Approval"

**Actions Available:**
- ✓ Approve - Move to next stage
- ✗ Reject - Return with feedback
- Comment - Add operational notes

---

#### Stage 5: NAN (Final Authorization) Approval

**Role:** NAN (Final Authorization)

**Responsibilities:**
- Provide final approval before booking is confirmed
- Verify all previous approvals are complete
- Ensure all required information is present
- Authorize the booking to proceed to scheduling

**Status:** "Awaiting NAN Approval"

**Actions Available:**
- ✓ Approve - Booking moves to Scheduling
- ✗ Reject - Return for corrections
- Review - View full approval history

**Post-Approval Status:** Once NAN approves, the booking automatically moves to the Scheduling phase.

### Approval Rejection

#### When a Request is Rejected

If a request is rejected at any approval stage:

1. **Notification:** The requester receives notification of rejection
2. **Reason Provided:** The approver includes reason for rejection
3. **Status Change:** Booking status changes to "Rejected"
4. **Next Steps:** Requester can:
   - Modify the booking
   - Resubmit for approval
   - Cancel the booking

#### Resubmitting After Rejection

1. Navigate to the rejected booking
2. Click **"Resubmit"** or edit and **"Save"**
3. Booking returns to the first approval stage (Department Head)
4. The approval workflow starts again

### Approval Status Tracking

All bookings display their current approval status:

| Status | Meaning | Current Approver |
|--------|---------|------------------|
| Draft | Not yet submitted | Requester |
| Pending Department Head Approval | Awaiting first approval | Department Head |
| Pending RSB Approval | In RSB review | RSB |
| Pending WVB Approval | Awaiting vehicle/driver assignment | WVB |
| Pending ODJ Approval | Operations review in progress | ODJ |
| Pending NAN Approval | Final authorization stage | NAN |
| Approved | All approvals complete | System |
| Scheduled | Posted to booking schedule | Schedule System |
| Rejected | Approval denied at some stage | (Returned to Requester) |
| Cancelled | Trip cancelled after approval | (System) |

### Viewing Approval History

To see the complete approval history for any booking:

1. Open the booking record
2. Click **"Approval History"** or **"Timeline"** tab
3. View all approvals with:
   - Approver name
   - Approval date and time
   - Approval status (Approved/Rejected)
   - Comments added
   - Any modifications made

---

## Scheduling

### What is Scheduling?

Once all approvals are complete (NAN approval), the booking is automatically **posted to the Car Booking Schedule**. This confirms the trip and makes it visible in the master schedule.

### Accessing the Schedule

#### To View the Schedule:

1. Navigate to **"Schedule"** or **"Booking Schedule"** from the main menu
2. The schedule displays:
   - Date of the trip (Pickup Date)
   - Time of pickup
   - Pickup location
   - Drop-off location
   - Assigned vehicle
   - Assigned driver
   - Requester name
   - Status

#### Schedule Views

The schedule can be viewed in multiple formats:

**Calendar View:**
- See all bookings on a calendar grid
- Click on a date to see bookings for that day
- Color-coded by status or client

**List View:**
- Detailed table of all scheduled bookings
- Sortable columns
- Filterable by date range, location, vehicle, or driver
- Search functionality

**Day View:**
- Focus on a specific day's bookings
- Chronological order
- Shows all trip details

#### Schedule Confirmation

Once posted to the schedule:
- ✓ Booking is confirmed
- ✓ Vehicle is reserved
- ✓ Driver is assigned
- ✓ Trip appears in all relevant reports and analytics
- ✓ Notifications are sent to relevant parties

### Exporting the Schedule

The Car Booking Schedule can be exported in multiple formats:

1. Click **"Export"** button on the Schedule page
2. Choose format:
   - **PDF** - Printable format with full details
   - **Excel** - Spreadsheet format for analysis
   - **CSV** - For import into other systems
3. File is downloaded to your computer

### Mobile Schedule Access

The schedule is accessible on mobile devices:
- **Mobile-responsive design** ensures proper viewing on smartphones and tablets
- All core functionality available on mobile
- Touch-friendly interface for easy navigation
- Optimized performance for mobile networks

---

## After Appointment Phase

### Phase Overview

The After Appointment Phase includes:
1. Trip Completion Encoding
2. Validation and Sign-off

This phase documents all expenses and logistics of the completed trip.

### Step 1: Trip Completion Encoding

**Role:** RSB (Reservation Service Bureau)

After the vehicle is returned, the RSB records all trip completion details.

#### How to Encode Trip Completion

1. Navigate to **"Trip Reports"** or **"Trip Completion"** section
2. Find the completed booking (status: "Completed" or "Awaiting Trip Report")
3. Click **"Add Trip Report"** or **"Encode Trip Details"**
4. Fill in the following required fields:

#### Trip Completion Details

| Field | Description | Unit | Example |
|-------|-------------|------|---------|
| **Time Returned** | Actual return time of vehicle | Time (HH:MM) | 17:30 |
| **Start Mileage** | Odometer reading at trip start | Miles/Km | 45,230 |
| **End Mileage** | Odometer reading at trip end | Miles/Km | 45,320 |
| **Fuel Cost** | Cost of fuel consumed | PHP | 500.00 |
| **RFID Cost** | Electronic toll costs | PHP | 250.00 |
| **Parking Cost** | Parking fees incurred | PHP | 100.00 |
| **Carwash Cost** | Vehicle cleaning charges | PHP | 200.00 |
| **Other Expenses** | Any other trip-related costs | PHP | 0.00 |

#### Step-by-Step Encoding Instructions

1. **Record Return Time:**
   - Click the "Time Returned" field
   - Select or type the actual time the vehicle was returned
   - Use 24-hour format (17:30 for 5:30 PM)

2. **Enter Mileage Information:**
   - "Start Mileage": Check the trip details to find the starting odometer reading
   - "End Mileage": Record the final odometer reading when vehicle returned
   - These are automatically used to calculate total distance traveled

3. **Input Fuel Cost:**
   - Enter the amount spent on fuel during the trip
   - Include receipts for verification

4. **Record RFID/Toll Expenses:**
   - Enter any electronic toll road charges (RFID)
   - Essential for highway trips

5. **Add Parking Charges:**
   - Document all parking fees incurred
   - Include parking location and duration if applicable

6. **Include Carwash Cost:**
   - If the vehicle was washed after the trip, record the cost
   - Include paid receipt reference

7. **Document Other Expenses:**
   - Add any additional trip-related costs
   - Examples: vehicle repairs, emergency expenses, toll assistance
   - Add descriptions for clarity

8. **Review All Entries:**
   - Verify all amounts are accurate
   - Check calculations are correct
   - Ensure mileage values make sense (end should be greater than start)

9. **Save Trip Report:**
   - Click **"Save"** or **"Submit"**
   - System will calculate derived values (distance, totals, costs)
   - Timestamp is automatically recorded

#### Automatic Calculations

Once trip details are saved, the system automatically calculates:

**Distance Traveled:**
```
Distance = End Mileage - Start Mileage
```

**Total Trip Expenses:**
```
Total Expenses = Fuel Cost + RFID Cost + Parking Cost +
                 Carwash Cost + Other Expenses
```

**Driver Charges:**
Based on trip duration:
- Whole Day (8+ hours): PHP 1,200
- Half Day (less than 8 hours): PHP 600

**Vehicle Charges:**
Based on destination location (see Location-Based Billing section)

**Total Trip Cost:**
```
Total Cost = Vehicle Charges + Driver Charges + Trip Expenses
```

### Step 2: Validation and Sign-off

#### Verification by RSB2

**Role:** RSB2 (Reservation Service Bureau - Approver)

After trip completion is encoded:

1. RSB2 reviews the trip completion report
2. Verifies all amounts and calculations
3. Signs/approves the trip report
4. Sends to requester for acknowledgment

**RSB2 Responsibilities:**
- ✓ Verify accuracy of all cost entries
- ✓ Check mileage calculations
- ✓ Confirm vehicle condition notes (if any)
- ✓ Approve expenses
- ✓ Sign the trip report

**Actions Available:**
- ✓ Approve - Confirms report accuracy
- ✗ Reject - If corrections needed (returns to RSB for editing)
- Comment - Add notes for requester

#### Acknowledgment by Requester

**Role:** Requester (Original booking creator)

After RSB2 verification:

1. Requester receives notification to acknowledge trip completion
2. Reviews the trip report and associated costs
3. Confirms or disputes the charges
4. Acknowledges completion

**How to Acknowledge:**

1. Navigate to **"My Trips"** or **"Trip Reports"**
2. Find the trip awaiting your acknowledgment
3. Review all details and expenses
4. Click **"Acknowledge"** to confirm
   - OR Click **"Dispute"** to raise concerns

**Requester Verification:**
- ✓ Trip details are accurate
- ✓ Expenses are reasonable
- ✓ No unauthorized charges
- ✓ Trip purpose matches the booking

#### Dispute Process

If a requester disputes trip charges:

1. Click **"Dispute"** on the trip report
2. Provide reason for dispute
3. The dispute is escalated to RSB2 and finance team
4. Investigation is conducted
5. Resolution is documented
6. Final charges are confirmed or adjusted

#### Final Status

Once both RSB2 and Requester have signed off:
- ✓ Trip Report Status: "Completed and Signed"
- ✓ Charges are finalized
- ✓ Data flows to Financial Summary
- ✓ Trip is archived

---

## Role-Specific Guides

### Requester

**Primary Responsibilities:**
- Create booking requests
- Edit bookings before RSB approval
- Respond to approval rejections
- Acknowledge completed trip reports

**Key Workflows:**

1. **Create Booking:**
   - Navigate to Bookings > New Booking
   - Complete all required fields
   - Submit for approval

2. **Track Booking Status:**
   - View My Bookings section
   - Monitor approval progress
   - See current status and approver

3. **Edit (Before RSB Approval):**
   - Click Edit on Draft bookings
   - Modify any details
   - Save changes

4. **Respond to Rejection:**
   - Review rejection reason
   - Make necessary corrections
   - Resubmit for approval

5. **Acknowledge Trip Report:**
   - Review completed trip details and costs
   - Confirm accuracy
   - Click Acknowledge or Dispute

**Permissions:**
- ✓ Create bookings
- ✓ Edit own bookings (before RSB approval)
- ✓ View own booking history
- ✓ Acknowledge trip reports
- ✗ Cannot approve bookings
- ✗ Cannot assign vehicles/drivers

---

### Department Head

**Primary Responsibilities:**
- Review and approve booking requests from their department
- Ensure trips are business-justified
- Monitor departmental transportation spending

**Key Workflows:**

1. **Review Pending Requests:**
   - Navigate to Approvals > Pending Department Head
   - View all pending requests from your department
   - Review booking details

2. **Approve or Reject:**
   - Add comments or notes
   - Click Approve to forward to RSB
   - Click Reject if request doesn't meet departmental criteria
   - Provide reason for rejection

3. **Monitor Departmental Bookings:**
   - View department booking reports
   - Track spending by department
   - Analyze trip patterns

**Permissions:**
- ✓ Approve/Reject bookings from their department
- ✓ View department booking history
- ✓ Add comments to requests
- ✗ Cannot assign vehicles/drivers
- ✗ Cannot edit booking details
- ✗ Cannot approve bookings from other departments

---

### RSB (Reservation Service Bureau)

**Primary Responsibilities:**
- Review bookings from Department Head approval
- Verify administrative requirements
- Edit and add notes to bookings
- Encode trip completion details after trips
- Generate operational reports

**Key Workflows:**

1. **Review Bookings:**
   - Navigate to Approvals > Pending RSB
   - Review all pending requests
   - Verify booking feasibility

2. **Approve or Reject:**
   - Check for policy violations
   - Approve to forward to WVB
   - Reject if administrative requirements not met

3. **Manage Bookings:**
   - Extended editing capabilities
   - Add notes and comments
   - Modify details as needed
   - Can override certain field validations

4. **Encode Trip Completion:**
   - After trip is completed
   - Record all expense details
   - Enter mileage and time information
   - Submit for RSB2 verification

5. **Generate Reports:**
   - View all historical bookings
   - Export booking data
   - Generate operational summaries

**Permissions:**
- ✓ Approve/Reject bookings
- ✓ Edit booking details extensively
- ✓ Encode trip completion details
- ✓ View all booking records
- ✓ Add extended notes and comments
- ✗ Cannot assign vehicles/drivers (that's WVB's role)
- ✗ Cannot approve trips to RSB2 signature level

---

### WVB (Vehicle and Driver Assignment Bureau)

**Primary Responsibilities:**
- Review requests with RSB approval
- Assign appropriate vehicles
- Assign suitable drivers
- Approve or reject based on resource availability
- Manage vehicle and driver allocations

**Key Workflows:**

1. **Review Pending Assignments:**
   - Navigate to Approvals > Pending WVB
   - View all requests awaiting vehicle/driver assignment

2. **Assign Vehicle:**
   - Review passenger count and trip requirements
   - Check available vehicles
   - Select appropriate vehicle from:
     - Innova Gray (Primetech)
     - Innova Red (Primus)
     - Innova Hybrid (Primus)
     - Tamaraw (Primus)
   - Record vehicle assignment

3. **Assign Driver:**
   - Check driver availability
   - Select appropriate driver
   - Verify driver company matches vehicle company
   - Record driver assignment

4. **Approve or Reject:**
   - If vehicle and driver available: Approve to forward to ODJ
   - If no suitable vehicle/driver: Reject with reason
   - Provide detailed comments

5. **Handle Rejections:**
   - Document resource constraints
   - Suggest alternative dates if applicable
   - Communicate with requester

6. **Manage Fleet:**
   - View vehicle utilization
   - Track driver assignments
   - Monitor vehicle availability
   - Edit assignments for approved bookings

**Permissions:**
- ✓ Approve/Reject bookings
- ✓ Assign vehicles
- ✓ Assign drivers
- ✓ Edit assignments for active bookings
- ✓ View fleet and driver availability
- ✓ Override certain assignments
- ✗ Cannot approve trips beyond WVB level
- ✗ Cannot edit request details (trip location, date, etc.)

---

### ODJ (Operations and Dispatch)

**Primary Responsibilities:**
- Review fully assigned bookings
- Verify operational feasibility
- Manage dispatch logistics
- Monitor active trips

**Key Workflows:**

1. **Review Pending Approvals:**
   - Navigate to Approvals > Pending ODJ
   - View all requests with vehicle/driver assigned

2. **Verify Operational Details:**
   - Check route feasibility
   - Verify driver qualifications for route
   - Confirm vehicle condition
   - Check for scheduling conflicts

3. **Approve or Reject:**
   - If operationally feasible: Approve to forward to NAN
   - If issues exist: Reject with detailed reason
   - Add operational notes

4. **Monitor Dispatch:**
   - Track active trips
   - Monitor vehicle locations (if GPS available)
   - Handle operational issues during trips

**Permissions:**
- ✓ Approve/Reject bookings
- ✓ Add operational notes
- ✓ View dispatch schedule
- ✓ Monitor active trips
- ✗ Cannot modify booking details
- ✗ Cannot assign vehicles/drivers
- ✗ Cannot approve beyond ODJ level

---

### NAN (Final Authorization)

**Primary Responsibilities:**
- Provide final approval before booking confirmation
- Verify all approvals are complete
- Authorize booking to proceed to scheduling
- Handle final escalations

**Key Workflows:**

1. **Review Final Approvals:**
   - Navigate to Approvals > Pending NAN
   - View all requests with complete approvals

2. **Verify Completeness:**
   - Check all approval signatures are present
   - Verify all required information is complete
   - Review approval chain

3. **Approve or Reject:**
   - If everything complete: Approve
   - Booking automatically moves to Scheduled status
   - If issues exist: Reject with detailed reason

4. **Handle Escalations:**
   - Review escalated cases
   - Make final authorization decisions
   - Document special approvals

**Permissions:**
- ✓ Approve/Reject bookings
- ✓ View complete approval history
- ✓ Add final authorization notes
- ✓ Escalate to higher authority if needed
- ✗ Cannot modify booking details
- ✗ Cannot reassign vehicles/drivers
- ✗ Cannot override previous approvals

---

### RSB2 (Trip Completion Verifier)

**Primary Responsibilities:**
- Verify trip completion reports from RSB
- Confirm accuracy of expenses and calculations
- Sign off on trip reports
- Flag discrepancies for investigation

**Key Workflows:**

1. **Review Trip Reports:**
   - Navigate to Trip Reports > Pending RSB2 Verification
   - Review all submitted trip completion reports

2. **Verify Accuracy:**
   - Check mileage calculations
   - Verify expense amounts against receipts
   - Confirm driver and vehicle assignments
   - Check for policy compliance

3. **Approve or Reject:**
   - If accurate: Click Approve/Sign
   - Report moves to Requester Acknowledgment
   - If discrepancies: Click Reject
   - Request corrections from RSB

4. **Add Comments:**
   - Document verification notes
   - Flag any unusual expenses
   - Add approver signature

**Permissions:**
- ✓ Review trip reports
- ✓ Approve/Reject trip reports
- ✓ Request corrections
- ✓ View trip expense details
- ✓ Add verification comments
- ✗ Cannot edit trip expenses
- ✗ Cannot approve beyond RSB2 level

---

### Payables

**Primary Responsibilities:**
- Review financial summaries
- Verify billing and cost calculations
- Process payments
- Generate financial reports
- Sign off on consolidated charges

**Key Workflows:**

1. **Review Financial Summaries:**
   - Access Financial > Billing Summary
   - Review consolidated trip costs
   - Group charges by company or project

2. **Verify Calculations:**
   - Check driver charges
   - Verify vehicle charges
   - Confirm expense totals
   - Validate billing against rates

3. **Process Billings:**
   - Generate invoices
   - Create payment summaries
   - Distribute charges to companies
   - Record in accounting system

4. **Sign Summary:**
   - Add Payables signature to financial summary
   - Document approval date
   - Submit for MOM review

**Permissions:**
- ✓ View all trip expenses
- ✓ View financial summaries
- ✓ Sign off on billing
- ✓ Generate financial reports
- ✓ Export financial data
- ✗ Cannot edit trip expenses
- ✗ Cannot approve trips
- ✗ Cannot override calculations

---

### MOM (Management Overview and Monitoring)

**Primary Responsibilities:**
- Provide executive oversight
- Review consolidated summaries
- Authorize large expenses
- Generate management reports
- Provide final sign-off

**Key Workflows:**

1. **Review Summaries:**
   - Access Reports > Executive Summary
   - Review total transportation spending
   - Analyze trends and patterns

2. **Approve Financial Summary:**
   - Review Payables signature
   - Verify RSB signature
   - Provide final authorization
   - Add MOM signature

3. **Generate Reports:**
   - Create executive reports
   - Analyze spending trends
   - Generate year-to-date summaries
   - Export data for analysis

4. **Monitor Compliance:**
   - Ensure all approvals are followed
   - Monitor for policy violations
   - Track exceptions and overrides

**Permissions:**
- ✓ View all reports and summaries
- ✓ Sign off on financial summaries
- ✓ Generate executive reports
- ✓ View complete booking history
- ✓ Access audit trails
- ✗ Cannot edit booking or expense details
- ✗ Cannot approve individual trips
- ✗ Cannot override approval workflow

---

## Financial and Billing Information

### Location-Based Billing

The Car Booking System automatically calculates vehicle charges based on the destination location. The following table shows the billing tiers:

#### Billing Rate Table

| Destination Locations | Charge per Trip (PHP) |
|----------------------|----------------------|
| **Tier 1 - Close Proximity (500 PHP)** |
| Mandaluyong | 500 |
| Pasig | 500 |
| San Juan | 500 |
| Makati | 500 |
| Taguig | 500 |
| Pasay | 500 |
| **Tier 2 - Metro Manila Area (1,000 PHP)** |
| Manila | 1,000 |
| Quezon City | 1,000 |
| Malabon | 1,000 |
| Valenzuela | 1,000 |
| Parañaque | 1,000 |
| **Tier 3 - Adjacent Provinces (1,500 PHP)** |
| Bulacan | 1,500 |
| Cavite | 1,500 |
| Laguna | 1,500 |
| Rizal | 1,500 |
| **Tier 4 - Regional (2,500 PHP)** |
| Pampanga | 2,500 |
| **Tier 5 - Far Regional (3,500 PHP)** |
| Pangasinan | 3,500 |
| Quezon | 3,500 |
| **Tier 6 - Custom Pricing** |
| Other locations | Custom (Determined by management) |

#### How Billing Works

1. **Location Selection:** When the booking request specifies a drop-off location, the system identifies the location tier
2. **Automatic Calculation:** The system automatically assigns the corresponding vehicle charge
3. **Charge Applied:** The vehicle charge is added to the trip cost
4. **Driver Charges:** Separate driver fees are applied based on trip duration (see Driver Fees section)
5. **Expense Additions:** Trip expenses (fuel, parking, tolls, etc.) are added separately
6. **Total Calculation:** Final trip cost = Vehicle Charge + Driver Charge + Expenses

#### Custom Pricing

For destinations not in the standard table:
- Manually assigned pricing during WVB approval
- Determined by management based on distance and requirements
- Documented in booking record
- Included in trip cost calculations

### Driver Fee Structure

Driver charges are calculated based on trip duration:

#### Driver Fee Rates

| Trip Duration | Driver Fee (PHP) |
|--------------|-----------------|
| **Whole Day** (8+ hours) | 1,200 |
| **Half Day** (Less than 8 hours) | 600 |

#### How Duration is Calculated

```
Trip Duration = Time Returned - Pickup Time
```

**Examples:**

- **Whole Day Example:**
  - Pickup Time: 08:00 AM
  - Return Time: 18:00 (6:00 PM)
  - Duration: 10 hours → Driver Fee = PHP 1,200

- **Half Day Example:**
  - Pickup Time: 09:00 AM
  - Return Time: 13:00 (1:00 PM)
  - Duration: 4 hours → Driver Fee = PHP 600

### Total Trip Cost Calculation

The complete trip cost is calculated as follows:

```
TOTAL TRIP COST = Vehicle Charge + Driver Charge + Trip Expenses

Where:
- Vehicle Charge = Amount based on destination location (see Billing Rate Table)
- Driver Charge = 1,200 (whole day) or 600 (half day)
- Trip Expenses = Fuel + RFID + Parking + Carwash + Other Expenses
```

#### Example Trip Cost Calculation

**Scenario:** Trip to Makati on May 10, 2026

**Inputs:**
- Destination: Makati (Tier 1 = PHP 500 vehicle charge)
- Pickup Time: 08:00 AM
- Return Time: 18:30 (6:30 PM)
- Duration: 10.5 hours → Whole Day (PHP 1,200 driver fee)
- Fuel Cost: PHP 400
- RFID Cost: PHP 250
- Parking Cost: PHP 150
- Carwash Cost: PHP 200
- Other Expenses: PHP 0

**Calculation:**

```
Vehicle Charge        = PHP 500
Driver Charge         = PHP 1,200
Fuel Cost            = PHP 400
RFID Cost            = PHP 250
Parking Cost         = PHP 150
Carwash Cost         = PHP 200
Other Expenses       = PHP 0
                      ___________
TOTAL TRIP COST      = PHP 2,700
```

### Financial Reporting Features

The system provides comprehensive financial tracking:

#### 1. Trip-Level Financial Details
- Individual trip costs and breakdowns
- All expenses itemized
- Driver and vehicle charges clearly shown
- Timestamp of cost recording

#### 2. Company-Level Summaries
- Total charges per company (Primus, Prime, Niupro)
- Grouped by billing period
- Comparison across companies
- Monthly and year-to-date totals

#### 3. Automated Calculations
- All mathematical computations are automatic
- No manual calculation required
- Calculations verified during RSB2 review
- System maintains consistency

#### 4. Searchable Records
- Find trips by:
  - Date range
  - Company
  - Driver
  - Vehicle
  - Requester
  - Destination
  - Cost range
  - Status

#### 5. Export Capabilities
- Export to Excel spreadsheet
- Export to PDF for printing
- Export to CSV for other systems
- Maintains formatting and calculations

### RFID and Toll Tracking

**RFID Costs** refer to electronic toll road charges.

#### How to Record RFID Costs

1. Collect toll receipts during trip
2. During trip completion encoding:
   - Enter total RFID cost in "RFID Cost" field
   - Save trip report
3. RSB2 verifies against receipts
4. Charge included in total trip cost

#### RFID Transaction Reporting

The system provides:
- Complete list of toll road usage
- By trip and date
- By location/highway section
- Total RFID spending by company
- Trends and patterns

---

## Driver and Vehicle Management

### Driver Management System

The system includes comprehensive driver management with company assignments.

#### Driver-to-Company Mapping

Drivers are assigned to specific companies as follows:

| Driver Code/Name | Assigned Company |
|------------------|-----------------|
| MPR | Primus |
| DDC | Prime |
| EAB | Prime |
| CEP | Primus |
| KMB | Primus |
| WVB | Primus |
| EHM | Primus |
| Others | Configurable |

#### How Driver Assignment Works

1. **During WVB Approval:**
   - WVB selects available driver
   - System validates driver availability
   - Driver is assigned to booking

2. **Driver Company Matching:**
   - Driver company must match trip company requirements
   - E.g., If trip is for Prime company, assign DDC or EAB
   - If trip is for Primus, can assign from MPR, CEP, KMB, WVB, or EHM

3. **Driver Availability:**
   - System tracks driver schedules
   - Prevents double-booking
   - Highlights unavailable drivers
   - Suggests alternative dates if needed

4. **Qualifications:**
   - Drivers have specific route qualifications
   - ODJ verifies driver qualifications for selected route
   - Special permissions for long-distance trips

#### Managing Drivers

**For Administrators/WVB:**

1. **View Driver List:**
   - Navigate to Driver Management
   - See all drivers and assignments
   - View current bookings

2. **Update Driver Information:**
   - Edit driver company assignment
   - Update contact information
   - Modify availability status
   - Add qualifications

3. **Handle Driver Unavailability:**
   - Mark driver as unavailable
   - System prevents assignment
   - Suggests alternatives
   - Reassign existing bookings if needed

### Vehicle Management System

Vehicles are categorized by type and company assignment.

#### Vehicle Categories

| Vehicle Model | Vehicle Color | Assigned Company |
|---------------|--------------|-----------------|
| Innova | Gray | Primetech |
| Innova | Red | Primus |
| Innova Hybrid | Standard | Primus |
| Tamaraw | Standard | Primus |
| Others | Varies | Configurable |

#### Vehicle Characteristics

**Innova Gray (Primetech):**
- Passenger Capacity: 7-9 seats
- Typical Use: Standard trips
- Fuel Type: Diesel/Gasoline
- Maintenance: Primetech responsibility

**Innova Red (Primus):**
- Passenger Capacity: 7-9 seats
- Typical Use: Standard trips
- Fuel Type: Diesel
- Maintenance: Primus responsibility

**Innova Hybrid (Primus):**
- Passenger Capacity: 7-9 seats
- Typical Use: Fuel-efficient trips
- Fuel Type: Hybrid
- Maintenance: Primus responsibility

**Tamaraw (Primus):**
- Passenger Capacity: 6-8 seats
- Typical Use: Compact trips
- Fuel Type: Diesel
- Maintenance: Primus responsibility

#### How Vehicle Assignment Works

1. **During WVB Approval:**
   - Review passenger count
   - Review trip requirements
   - Check vehicle availability
   - Select appropriate vehicle
   - Vehicle is assigned to booking

2. **Passenger Count Matching:**
   - System recommends vehicles based on passenger count
   - All vehicles can accommodate standard groups (4-8 passengers)
   - Larger groups may need multiple vehicles
   - WVB can override recommendations

3. **Vehicle Availability:**
   - System tracks vehicle schedules
   - Shows available vehicles for selected date/time
   - Prevents double-booking
   - Highlights maintenance periods

4. **Company Matching:**
   - Vehicle company must align with trip company
   - E.g., Primus bookings use Primus vehicles
   - Prime bookings use Primetech vehicles where possible

#### Managing Vehicles

**For Administrators/WVB:**

1. **View Vehicle Fleet:**
   - Navigate to Vehicle Management
   - See all vehicles and status
   - View current assignments
   - Track mileage and maintenance

2. **Update Vehicle Information:**
   - Edit vehicle details
   - Update maintenance schedule
   - Mark vehicle out of service
   - Record vehicle condition

3. **Handle Vehicle Unavailability:**
   - Mark vehicle as unavailable
   - System prevents assignment
   - Suggests alternatives
   - Reassigns bookings if needed

4. **Track Vehicle Utilization:**
   - View vehicle usage reports
   - Analyze vehicle efficiency
   - Identify peak usage periods
   - Plan maintenance schedules

### Fleet Optimization

The system supports fleet optimization through:

1. **Utilization Reports:**
   - Track which vehicles are used most
   - Identify underutilized vehicles
   - Analyze cost per vehicle

2. **Driver-Vehicle Pairing:**
   - Track preferred driver-vehicle combinations
   - Monitor driver performance with specific vehicles
   - Optimize assignments for efficiency

3. **Route Analysis:**
   - Track routes by vehicle
   - Identify high-mileage routes
   - Plan route optimization

4. **Maintenance Scheduling:**
   - Track maintenance needs
   - Schedule preventive maintenance
   - Reduce unexpected downtime
   - Extend vehicle life

---

## Reports and Analytics

### Available Reports

The Car Booking System provides multiple types of reports for analysis and decision-making.

#### 1. Booking Summary Report

**Purpose:** Overview of all bookings within a time period

**Contents:**
- Total bookings created
- Bookings by status (Approved, Rejected, Scheduled)
- Booking trends over time
- Peak booking periods
- Average approval time

**How to Generate:**
1. Navigate to Reports > Booking Summary
2. Select date range
3. Apply filters (department, client, company)
4. Click Generate
5. Choose export format (PDF, Excel, CSV)

#### 2. Financial Report

**Purpose:** Detailed financial summary of all transportation costs

**Contents:**
- Total transportation costs
- Breakdown by:
  - Company (Primus, Prime, Niupro)
  - Department
  - Month/Period
  - Trip type
- Driver charges summary
- Vehicle charges summary
- Expense breakdowns (fuel, parking, tolls, etc.)
- Cost trends and comparisons

**How to Generate:**
1. Navigate to Reports > Financial Report
2. Select date range
3. Select company/department filters
4. Click Generate
5. Review summary and charts
6. Export if needed

#### 3. Trip Details Report

**Purpose:** Comprehensive details of individual trips

**Contents:**
- Trip date and time
- Pickup and drop-off locations
- Driver and vehicle assigned
- Mileage and duration
- All expenses itemized
- Approval signatures
- Timestamps for all changes

**How to Generate:**
1. Navigate to Reports > Trip Details
2. Search by:
   - Trip ID
   - Date range
   - Driver
   - Vehicle
   - Requester
3. Click on trip to view details
4. Click Export to download

#### 4. Driver Performance Report

**Purpose:** Analyze driver activity and efficiency

**Contents:**
- Number of trips per driver
- Total miles driven
- Average trip duration
- Vehicle assignments
- Any incident reports
- Performance metrics

**How to Generate:**
1. Navigate to Reports > Driver Performance
2. Select time period
3. Select specific drivers or all
4. Click Generate
5. Review metrics and charts

#### 5. Vehicle Utilization Report

**Purpose:** Track vehicle usage and efficiency

**Contents:**
- Total trips per vehicle
- Total miles driven
- Maintenance history
- Cost per mile
- Usage patterns
- Downtime periods

**How to Generate:**
1. Navigate to Reports > Vehicle Utilization
2. Select vehicle(s)
3. Select time period
4. Click Generate
5. Analyze utilization metrics

#### 6. Approval Workflow Report

**Purpose:** Monitor approval process efficiency

**Contents:**
- Average approval time per stage
- Rejection rates per approver
- Bottlenecks in workflow
- Approval trend analysis
- Stage-by-stage metrics

**How to Generate:**
1. Navigate to Reports > Workflow Analysis
2. Select date range
3. Select specific approval stages
4. Click Generate
5. Review workflow metrics

#### 7. Client Billing Report

**Purpose:** Track charges per client/company

**Contents:**
- Total charges per client
- Breakdown by trip type
- Trip frequency
- Cost trends
- Comparison with budgets
- Year-to-date totals

**How to Generate:**
1. Navigate to Reports > Client Billing
2. Select client(s)
3. Select billing period
4. Click Generate
5. Review charges and comparisons
6. Export invoice if needed

### Dashboard Analytics

The main dashboard provides at-a-glance analytics including:

#### Key Performance Indicators (KPIs)

- **Total Bookings:** Count of all active bookings
- **Pending Approvals:** Bookings awaiting action
- **Scheduled Trips:** Confirmed bookings
- **Completed Trips:** Finished trips with encoding
- **Average Approval Time:** Time from submission to final approval
- **Rejection Rate:** Percentage of rejected bookings

#### Visual Charts

- **Bookings by Status:** Pie/donut chart
- **Approvals Over Time:** Line graph showing trends
- **Costs by Company:** Bar chart comparing costs
- **Regional Distribution:** Geographic breakdown
- **Monthly Trends:** Comparison of periods

#### Filters and Customization

- Filter by date range
- Filter by company or department
- Filter by location or region
- Filter by approval status
- Save custom dashboards
- Export dashboard data

### Exporting Reports

All reports can be exported in multiple formats:

#### Export Formats

**PDF Export:**
- Formatted for printing
- Includes charts and logos
- Maintains formatting
- Professional appearance

**Excel Export:**
- Spreadsheet format for analysis
- All data included
- Formulas preserved
- Can be further analyzed or modified

**CSV Export:**
- Comma-separated values
- Universal format
- Compatible with most systems
- Plain text format

#### Export Process

1. Open the report or dashboard
2. Click the **"Export"** button
3. Select desired format (PDF, Excel, CSV)
4. Choose any formatting options
5. Click **"Download"**
6. File saves to your computer

---

## Best Practices

### For Requesters

#### 1. Accurate Information
- **Double-check all details** before submitting
- Verify client name and company assignment
- Ensure correct pickup date and time
- Specify clear destination

#### 2. Early Submission
- **Submit requests early** - at least 3-5 days before needed
- Allows time for approvals and vehicle assignment
- Reduces rush processing

#### 3. Realistic Passenger Count
- **Be accurate with passenger count**
- Affects vehicle selection
- Ensures appropriate vehicle assignment

#### 4. Clear Communication
- **Add helpful notes** for drivers in the Purpose field
- Specify special requirements or access issues
- Mention if multiple locations will be visited

#### 5. Trip Acknowledgment
- **Promptly review trip reports** when they arrive
- Verify accuracy of expenses
- Acknowledge completion timely
- Dispute only legitimate errors

### For Approvers

#### 1. Timely Review
- **Review requests promptly** - don't delay processing
- Set email alerts for pending approvals
- Schedule time for approval reviews
- Communicate delays if needed

#### 2. Thoughtful Decisions
- **Don't approve without thorough review**
- Verify all required information is present
- Check for policy compliance
- Ask clarifying questions if needed

#### 3. Clear Feedback
- **When rejecting, provide clear reasons**
- Specify what corrections are needed
- Help requester understand requirements
- Offer guidance for resubmission

#### 4. Comments and Notes
- **Add helpful comments** for next approvers
- Highlight any concerns or special conditions
- Provide context for decisions

### For WVB (Vehicle Assignment)

#### 1. Optimal Vehicle Selection
- **Match vehicle to passenger count** appropriately
- Consider trip distance and requirements
- Prefer higher-mileage vehicles for long trips
- Balance vehicle usage for maintenance scheduling

#### 2. Driver Assignment
- **Assign experienced drivers** for difficult routes
- Verify driver qualifications match trip requirements
- Avoid overworking drivers
- Consider driver preferences where possible

#### 3. Resource Planning
- **Communicate resource constraints** clearly
- If rejecting due to unavailability, suggest alternatives
- Plan ahead for peak booking periods
- Monitor vehicle and driver utilization

#### 4. Documentation
- **Document any special assignments** or overrides
- Note reasons for vehicle/driver selection
- Add comments for operational team

### For All Users

#### 1. Regular System Access
- **Check the system regularly** for updates and notifications
- Stay informed about pending approvals
- Review dashboards for operational insights

#### 2. Document Preservation
- **Keep receipts** for all trip expenses
- Document fuel, parking, toll transactions
- Maintain records for 3-6 months minimum
- Provide receipts when requested

#### 3. Compliance
- **Follow the approval workflow**
- Don't bypass approval stages
- Adhere to location-based billing
- Report errors immediately

#### 4. Communication
- **Communicate issues promptly**
- Report system problems
- Notify relevant parties of changes
- Follow up on disputed items

#### 5. Data Security
- **Don't share login credentials**
- Log out when finished
- Protect sensitive information
- Report unauthorized access

---

## Troubleshooting and FAQs

### Common Issues and Solutions

#### Issue: I Cannot Login

**Problem:** Login fails or "Invalid credentials" error appears

**Solutions:**
1. Verify email address is correct: benchakino04@gmail.com
2. Verify password is correct: 123456
3. Ensure Caps Lock is off
4. Check internet connection
5. Clear browser cache and cookies
6. Try a different browser
7. Contact system administrator if still unable to login

#### Issue: Booking Won't Submit

**Problem:** Unable to submit booking request

**Solutions:**
1. **Verify all required fields are filled:**
   - Requester Name
   - Requester Department
   - Client Name
   - Company Assigned
   - Number of Passengers
   - Pickup Date
   - Pickup Time
   - Pickup Location
   - Drop-off Location

2. **Check field formats:**
   - Date format correct (YYYY-MM-DD or system's expected format)
   - Time format correct (HH:MM or HH:MM AM/PM)
   - No extra spaces or special characters

3. **Try again:**
   - Refresh the page
   - Re-enter all information
   - Submit again

4. **Contact support** if still unable to submit

#### Issue: Booking Was Rejected

**Problem:** Your booking was rejected by an approver

**Solutions:**
1. **Review rejection reason:**
   - Click on the booking
   - Find the rejection comment
   - Understand what was wrong

2. **Make corrections:**
   - Edit the rejected booking
   - Correct the identified issues
   - Add notes for clarification

3. **Resubmit:**
   - Click Resubmit
   - Booking goes back through approval process

4. **Request clarification:**
   - If unclear why rejected, email the approver
   - Ask for specific guidance on corrections

#### Issue: Cannot Find Available Vehicle or Driver

**Problem:** WVB message "No available vehicle for this date"

**Solutions:**
1. **Suggest alternative date:**
   - Ask requester if adjacent date works
   - Check available dates in system
   - Reject with alternative suggestions

2. **Contact operations:**
   - Check if vehicle maintenance is scheduled
   - Verify driver availability
   - Explore sharing vehicles

3. **Document constraints:**
   - Note reason for non-availability
   - Track peak periods
   - Plan for future demand

#### Issue: Trip Expenses Don't Seem Correct

**Problem:** Calculated trip cost seems wrong

**Solutions:**
1. **Verify destination location:**
   - Check billing rate for destination
   - Ensure location is correctly categorized
   - Verify vehicle charge applied

2. **Check driver fee calculation:**
   - Confirm trip duration
   - Verify whole day (8+) or half day (<8) classification
   - Check correct fee applied

3. **Review all expenses:**
   - Verify fuel cost entered correctly
   - Check parking charges
   - Confirm RFID tolls recorded
   - Review other expenses

4. **Contact RSB2:**
   - If still uncertain, request clarification
   - Ask for cost breakdown
   - Request revised report if needed

#### Issue: Cannot Edit Booking

**Problem:** Edit button is grayed out or unavailable

**Solutions:**
1. **Check approval status:**
   - Requesters can only edit before RSB approval
   - If RSB already approved, cannot edit
   - Contact RSB to make changes

2. **Contact RSB or WVB:**
   - They have extended editing permissions
   - Can edit even after approvals
   - Request changes through them

3. **If trip already completed:**
   - Cannot edit completed bookings
   - Create new booking if needed
   - Reference original booking in notes

#### Issue: Trip Report Not Appearing

**Problem:** Completed trip not showing in Trip Reports

**Solutions:**
1. **Verify trip status:**
   - Check that trip is marked as completed
   - Confirm booking is in Scheduled status
   - Check date of trip

2. **Wait for processing:**
   - System may need time to update
   - Refresh the page
   - Check after a few minutes

3. **Contact RSB:**
   - Verify trip completion encoding was submitted
   - Ask if report is still being processed
   - Request immediate creation of report

#### Issue: Cannot Access Reports

**Problem:** Reports page not loading or showing error

**Solutions:**
1. **Check browser:**
   - Refresh the page
   - Clear cache and cookies
   - Try a different browser

2. **Check permissions:**
   - Verify your role allows report access
   - Contact administrator if limited access
   - Request specific reports from authorized user

3. **Check date range:**
   - Verify date range is reasonable
   - Try selecting smaller date range
   - Try "All" or "This Year"

4. **Contact support:**
   - Report the issue with screenshot
   - Provide date and time of error
   - Describe what report you were trying to access

### Frequently Asked Questions

#### Q: How long does the approval process take?

**A:** The approval timeline depends on several factors:

- **Normal timeframe:** 2-3 business days
- **Rush processing:** Can be done same-day with special permission
- **Each stage:** Usually 4-8 hours (depends on workload)
- **Weekends/holidays:** May be delayed
- **Late submissions:** Longer approvals if submitted late in day

**Recommendation:** Submit requests 5+ business days before needed date.

---

#### Q: Can I cancel a booking after it's been approved?

**A:** Yes, bookings can be cancelled after approval in emergency cases.

**Procedure:**
1. Navigate to the booking
2. Click "Cancel Booking"
3. Provide reason for cancellation
4. System records cancellation with timestamp
5. Notification sent to all approvers

**Important:**
- Cancellations should be rare
- Document the emergency situation
- May incur cancellation charges

---

#### Q: What if the trip takes longer than expected?

**A:** Trip duration affects driver fees.

**If trip exceeds planned time:**
1. Driver notes additional time
2. Actual return time is recorded
3. Driver fee recalculated based on actual duration
4. Requester approves final charges
5. Additional costs may be billed

**Example:**
- Planned: 4-hour trip (half day = PHP 600)
- Actual: 10-hour trip (whole day = PHP 1,200)
- Additional driver fee billed: PHP 600

---

#### Q: How are RFID toll costs handled?

**A:** RFID costs are transaction-based and tracked separately.

**Process:**
1. Driver uses RFID-enabled vehicle on toll roads
2. Automatic charges are recorded
3. During trip encoding, RFID amount entered
4. Receipt/transaction provided for verification
5. RSB2 confirms against actual charges
6. Amount added to trip expenses

**Verification:**
- System matches RFID costs with actual toll transactions
- Regular reconciliation with toll operators
- Disputes investigated and resolved

---

#### Q: Can multiple drivers share one vehicle?

**A:** Technically yes, but not recommended.

**Considerations:**
- One driver assigned per booking
- Handover reduces efficiency
- Increases liability issues
- Complicates expense tracking
- Not typical operational practice

**If required:**
- Contact operations management
- Document handover procedure
- Record both drivers
- Clarify responsibility for damages

---

#### Q: How do I dispute trip charges?

**A:** Use the dispute process if charges seem incorrect.

**Procedure:**
1. Navigate to Trip Report
2. Review all details carefully
3. If still disagree, click "Dispute"
4. Provide detailed reason for dispute
5. Submit dispute with supporting documents
6. Investigation team reviews
7. Decision documented
8. Charges adjusted if dispute valid

**Common grounds for disputes:**
- Incorrect mileage calculation
- Overcharged parking fees
- Duplicate RFID entries
- Wrong billing tier applied
- Expenses not incurred

---

#### Q: What information do I need for the trip report?

**A:** RSB must collect and enter following information:

**Required:**
- Time Returned (actual return time)
- Start Mileage (odometer at trip start)
- End Mileage (odometer at trip end)
- All applicable expenses

**Supporting Documents:**
- Fuel receipts
- Parking receipts
- RFID toll receipt
- Carwash receipt
- Any other expense receipts

**Suggested Process:**
- Driver collects all receipts during trip
- At return, mileage is recorded
- All receipts provided to RSB
- RSB enters all information same day
- RSB2 verifies within 24 hours

---

#### Q: Who do I contact for problems?

**A:** Contact the appropriate person based on your issue:

**For Booking Issues:**
- Department Head (first approval stage)
- Booking system support

**For Vehicle/Driver Assignment:**
- WVB (Vehicle and Driver Bureau)

**For Trip Expense Issues:**
- RSB (Reservation Service Bureau)
- RSB2 (Trip verification)

**For Financial/Billing Questions:**
- Payables department

**For Technical/System Issues:**
- IT Support or System Administrator
- Email or phone support desk

**For Management Concerns:**
- Your manager
- MOM (Management Overview and Monitoring)

---

#### Q: Can I book multiple vehicles for one event?

**A:** Yes, multiple bookings can be created for one event.

**Procedure:**
1. Create separate booking for each vehicle
2. Reference the main event in Purpose/Notes
3. Submit all bookings simultaneously
4. Each goes through same approval process
5. All can be scheduled together

**Best Practices:**
- Use consistent naming for all related bookings
- Reference other booking IDs in notes
- Coordinate with WVB for scheduling
- Ensure drivers are assigned appropriately

---

#### Q: How far in advance should I submit a booking?

**A:** Recommended timing:

**Ideal:** 5-10 business days advance
- Allows comfortable approval time
- Better chance of vehicle availability
- Reduces rush processing

**Minimum:** 2-3 business days advance
- May delay approvals
- May have vehicle unavailability
- Still possible but tight

**Emergency:** Same-day or next-day
- Contact operations directly
- Requires special approval
- May incur rush charges
- Vehicle may not be available

**Not Recommended:** Less than 24 hours
- May be rejected
- No guarantee of vehicle
- Should only be emergencies

---

#### Q: What is the vehicle capacity?

**A:** Vehicles have different capacities:

| Vehicle Type | Capacity | Notes |
|--------------|----------|-------|
| Innova Gray | 7-9 seats | Primetech vehicle |
| Innova Red | 7-9 seats | Primus vehicle |
| Innova Hybrid | 7-9 seats | Fuel-efficient option |
| Tamaraw | 6-8 seats | Compact option |

**Passenger Capacity Includes:**
- Driver (1)
- Passengers (5-8 depending on vehicle)

**For groups larger than vehicle capacity:**
- Book multiple vehicles
- Coordinate timing
- Contact operations

---

#### Q: How are expenses verified?

**A:** Multi-step verification process ensures accuracy:

**Step 1 - RSB Entry:**
- RSB enters all expense information
- Matches receipts
- Calculates totals

**Step 2 - RSB2 Verification:**
- RSB2 reviews all entries
- Matches against receipts
- Verifies calculations
- Approves or rejects

**Step 3 - Requester Acknowledgment:**
- Requester reviews charges
- Confirms accuracy
- Acknowledges or disputes

**Step 4 - Payables Review:**
- Payables verifies for billing
- Confirms company charges
- Processes payment

**Documentation:**
- All receipts kept on file
- Timestamp recorded at each step
- Audit trail maintained
- Disputes can be investigated

---

#### Q: Can I override the approval workflow?

**A:** No, the approval workflow cannot be bypassed.

**Reasons:**
- Ensures accountability
- Maintains financial controls
- Prevents unauthorized spending
- Documents decision trail

**Exception Process:**
- Management can approve exceptions
- Requires specific justification
- Documented as override in system
- Audit trail maintained
- MOM approval usually required

**Important:**
- Should be rare
- Only for emergency situations
- Must be documented thoroughly
- Should not become standard practice

---

## Reference Information

### System Roles and Permissions Summary

| Role | Can Create | Can Approve | Can Edit | Can Assign Vehicle/Driver |
|------|-----------|-----------|---------|-------------------------|
| Requester | ✓ Own bookings | ✗ | ✓ Before RSB | ✗ |
| Dept Head | ✗ | ✓ Own dept | Limited | ✗ |
| RSB | ✗ | ✓ | ✓ Extended | ✗ |
| WVB | ✗ | ✓ | ✓ Assignments | ✓ Yes |
| ODJ | ✗ | ✓ | Limited | ✗ |
| NAN | ✗ | ✓ Final | Limited | ✗ |
| RSB2 | ✗ | ✓ Trip reports | Limited | ✗ |
| Payables | ✗ | ✓ Billing | ✗ | ✗ |
| MOM | ✗ | ✓ Final | ✗ | ✗ |

### Location Quick Reference

#### Tier 1 Locations (PHP 500)
Mandaluyong, Pasig, San Juan, Makati, Taguig, Pasay

#### Tier 2 Locations (PHP 1,000)
Manila, Quezon City, Malabon, Valenzuela, Parañaque

#### Tier 3 Locations (PHP 1,500)
Bulacan, Cavite, Laguna, Rizal

#### Tier 4 Locations (PHP 2,500)
Pampanga

#### Tier 5 Locations (PHP 3,500)
Pangasinan, Quezon

#### Tier 6 Locations (Custom)
All other destinations - custom pricing determined by management

### Driver-Company Assignment Quick Reference

| Driver Code | Company |
|------------|---------|
| MPR | Primus |
| DDC | Prime |
| EAB | Prime |
| CEP | Primus |
| KMB | Primus |
| WVB | Primus |
| EHM | Primus |
| Others | Configurable |

### Vehicle-Company Assignment Quick Reference

| Vehicle | Color | Company |
|---------|-------|---------|
| Innova | Gray | Primetech |
| Innova | Red | Primus |
| Innova Hybrid | Standard | Primus |
| Tamaraw | Standard | Primus |

### Fee Reference

#### Driver Fees
| Duration | Fee |
|----------|-----|
| Whole Day (8+ hours) | PHP 1,200 |
| Half Day (<8 hours) | PHP 600 |

#### Vehicle Charges by Location
See Billing Rate Table in Financial and Billing Information section.

---

## Glossary

**Approval Workflow** - Sequential process where multiple roles review and approve booking requests

**Audit Trail** - Complete record of all system activities including timestamps and user information

**Billing Tier** - Category of destinations with associated charges

**Booking** - Vehicle reservation request for a specific date, time, and location

**Carwash Cost** - Expense for vehicle cleaning services

**Company Assigned** - Organization responsible for payment of trip

**Driver** - Professional operator of assigned vehicle

**Drop-off Location** - Destination or final location for trip

**Duration** - Length of trip, determines whole day or half day driver fee

**Expense** - Cost incurred during trip (fuel, parking, tolls, carwash, etc.)

**Filing Date** - Date when booking request is submitted

**Fuel Cost** - Expense for fuel consumed during trip

**Mileage** - Distance traveled, measured in miles or kilometers

**ODJ** - Operations and Dispatch jurisdiction; stage 4 of approval

**NAN** - Final authorization; stage 5 of approval

**Parking Cost** - Expense for parking fees during trip

**Payables** - Department responsible for financial processing and payments

**Pickup Date** - Scheduled date for vehicle collection

**Pickup Location** - Starting point for trip

**Pickup Time** - Scheduled time for vehicle collection

**Prime** - Transportation company with DDC and EAB drivers

**Primus** - Transportation company with multiple driver assignments

**Primetech** - Company assigned to Innova Gray vehicles

**Requester** - Employee requesting vehicle booking

**RFID Cost** - Electronic toll road charges

**RSB** - Reservation Service Bureau; stage 2 of approval

**RSB2** - RSB verification role; reviews completed trip reports

**Schedule** - Master calendar of all approved bookings

**Status** - Current state of booking (Draft, Pending Approval, Approved, Scheduled, Rejected, Cancelled)

**Timestamp** - Date and time record of system activity

**Total Trip Cost** - Sum of vehicle charge, driver fee, and all expenses

**Trip Report** - Documentation of completed trip with all expenses

**Vehicle** - Assigned transportation unit for trip

**WVB** - Vehicle and Driver Assignment Bureau; stage 3 of approval assigns vehicle and driver

**Whole Day** - Trip duration of 8 or more hours; driver fee PHP 1,200

**Half Day** - Trip duration of less than 8 hours; driver fee PHP 600

---

## Conclusion

The Car Booking System provides a comprehensive solution for managing vehicle bookings, approvals, and financial tracking. By following the workflows and procedures outlined in this manual, users can efficiently manage transportation requests while maintaining proper approvals and financial controls.

**Key Takeaways:**

1. **Follow the workflow** - All bookings must go through the sequential approval process
2. **Submit early** - 5+ days before needed date
3. **Be accurate** - Double-check information before submitting
4. **Maintain receipts** - Document all expenses during trips
5. **Review promptly** - Check approvals and reports as they come
6. **Communicate** - Ask clarifying questions if unsure
7. **Use the system** - All transportation should be booked through the system

For additional questions or support, contact the appropriate department based on your role and issue.

---

**Document Version 1.0**
**Last Updated: 2026-04-29**
**Car Booking System User Manual**

