# Employee Kiosk System - UI/UX Analysis & Interface Documentation

## System Interface Overview

The Employee Kiosk system uses a modern web-based interface built on the PrimeVue Ultima template with Vue.js framework. The design follows current best practices for dashboard and administrative applications.

## Layout Architecture

### Overall Page Structure

```
┌─────────────────────────────────────────────────────────────┐
│  TOP NAVIGATION BAR (Blue background, fixed height ~60px)  │
├─────────────────┬───────────────────────────────────────────┤
│                 │                                           │
│  LEFT SIDEBAR   │     MAIN CONTENT AREA                    │
│  (Fixed width   │     (Responsive, scrollable)             │
│   ~230px)       │                                           │
│                 │                                           │
│  Menu Items     │     Dashboard Components                 │
│  User Profile   │     Tables                               │
│  Icons          │     Charts                               │
│                 │                                           │
└─────────────────┴───────────────────────────────────────────┘
```

### Top Navigation Bar

**Height:** Approximately 60 pixels
**Background Color:** Solid blue (#5B5BFF or similar)
**Fixed Position:** Remains at top when scrolling

**Left Section:**
- **ULTIMA Logo:** Custom icon followed by "ULTIMA" text in white
- **Yellow Accent Icon:** Navigation toggle or app switcher
- **Menu Dropdowns:**
  - "UI KIT" dropdown (collapsible menu)
  - "UTILITIES" dropdown (collapsible menu, can expand to show Buy Now, Documentation)

**Center/Right Section:**
- **Search Icon:** Magnifying glass for global search
- **Settings Icon:** Gear/cog for user settings
- **Notifications Icon:** Bell icon for system notifications
- **Grid Icon:** Multi-view or dashboard switcher
- **User Initials:** "BA" (Benedict Aquino) - text link to profile
- **Back Arrow:** Navigation back button

### Left Sidebar Menu

**Width:** Approximately 230 pixels (collapsible/expandable)
**Background:** Light gray/white
**Scrollable:** Yes, when content exceeds viewport height
**Fixed Position:** Remains visible when main content scrolls

**Menu Structure:**

```
[DASHBOARDS Section]
├─ Analytics Dashboard (with icon)
    └─ Indicates active/current page with highlight

[HEADCOUNT Section] (Primary operational area)
├─ Site Management
├─ Company & Clients
├─ Headcount Adjustments
├─ Location Management
├─ Activity Log
├─ Headcount Snapshots
├─ Client HC Report
└─ TV Map Display

[USER MANAGEMENT Section]
├─ List
├─ Create
└─ User Profile Card
    ├─ Avatar: "Amy Elsner"
    ├─ Role: "Webmaster"
    └─ Action Buttons:
        ├─ Settings
        ├─ Profile
        ├─ Support
        └─ Logout
```

**Menu Item Styling:**
- Icons on left (approximately 20x20 pixels)
- Text label on right
- Hover state: Light background highlight
- Active state: Bold text or highlighted background
- Expandable sections with arrow indicators

### Main Content Area

**Responsive Layout:** Adjusts width based on sidebar state
**Scrollable:** Vertical scroll for extended content
**Padding:** Consistent margins from edges

**Standard Components in Main Area:**

1. **Breadcrumb Navigation** (below top bar)
   - Shows current page: "Home > [Section Name]"
   - Clickable for navigation

2. **Page Title/Heading**
   - Large heading (H1, approximately 24-32px font)
   - Bold weight
   - Indicates current section

3. **Content Sections**
   - Organized in logical groups
   - Cards or panels for grouping related content
   - Whitespace between sections

## Component Analysis

### Cards/Metric Boxes

**Used in:** Analytics Dashboard, TV Map Display, Headcount Snapshots

**Structure:**
```
┌────────────────────────┐
│ [ICON]    METRIC TITLE │
│           403          │ (Large number)
│ Description text       │
└────────────────────────┘
```

**Elements:**
- Background: White or light gray
- Border: Subtle border or shadow
- Icon: Small colored icon (top-left or top-center)
- Title: Small text above number
- Value: Large, bold number
- Description: Smaller text below value
- Color coding: Different colors for different metrics

**Examples:**
- Total Headcount: 403 (blue icon)
- Total Sites: 12 (green icon)
- Regional metrics: Luzon (252), Visayas (80), Mindanao (71)

### Tables

**Used in:** Site Management, Company & Clients, Activity Log, Location Management

**Structure:**
```
┌─────────┬─────────┬─────────┬─────────┬─────────┐
│ Header  │ Header  │ Header  │ Header  │ Header  │
├─────────┼─────────┼─────────┼─────────┼─────────┤
│ Row 1   │ Data    │ Data    │ Data    │ Actions │
├─────────┼─────────┼─────────┼─────────┼─────────┤
│ Row 2   │ Data    │ Data    │ Data    │ Actions │
├─────────┼─────────┼─────────┼─────────┼─────────┤
└─────────┴─────────┴─────────┴─────────┴─────────┘
Pagination Controls Below
```

**Features:**

1. **Column Headers:**
   - Background: Slightly darker than rows
   - Sortable: Click to sort ascending/descending
   - Cursor changes to pointer on hover
   - Arrow indicators show sort direction

2. **Data Rows:**
   - Alternating row colors (white, light gray) for readability
   - Hover state: Row background highlights
   - Clickable for expanding or viewing details

3. **Action Buttons (Final Column):**
   - Edit icon (pencil)
   - Delete icon (trash bin)
   - Menu icon (three dots) for more actions
   - Icons change color on hover

4. **Row Selection:**
   - Checkbox in first column
   - Select individual or all rows
   - Counter shows "Selected: X" count

5. **Pagination Controls (Below table):**
   - "First Page" button (disabled if on first page)
   - "Previous Page" button
   - Numbered page buttons (e.g., 1, 2, 3...)
   - "Next Page" button
   - "Last Page" button
   - "Rows per page" dropdown (default: 10)

6. **Search/Filter Bar (Above table):**
   - Text input: "Search..." placeholder
   - Real-time filtering as user types
   - Additional filter dropdowns for specific columns

**Table Examples in System:**

**Site Management Table:**
- Columns: Site Name, Client, Company, Region, Headcount, Active, Floating, Latitude, Longitude
- 12 sites displayed across multiple pages
- Geographic coordinates for each site

**Company Management Table:**
- Columns: Company Name, Clients, Created, Actions
- Shows creation date for each company
- Edit/Delete actions

**Activity Log Table:**
- Columns: Action, Type, Description, Performed By, IP Address
- Sortable by any column
- Time-based filtering

### Charts & Visualizations

**Chart Types Used:**

1. **Line Charts**
   - Shows headcount trends over time
   - Dual-axis (left: headcount numbers, right: site count)
   - X-axis: Time periods
   - Color legend showing data series
   - Tooltip on hover showing exact values

2. **Bar Charts**
   - Horizontal or vertical layout
   - Shows comparative data
   - Color-coded by category
   - Value labels on bars

3. **Donut/Pie Charts**
   - Shows distribution and proportions
   - Example: Company distribution
   - Color-coded segments
   - Legend showing percentages
   - Companies: Niupro (25), Prime (167), Primus (211)

4. **Combined Charts**
   - Multiple visualization types
   - Example: Headcount by Region (line + bar)
   - Helps identify patterns and trends

**Chart Styling:**
- Clean, minimal design
- Clear color differentiation
- Professional color palette
- Responsive sizing

### Forms & Input Elements

**Text Inputs:**
- Placeholder text guides user
- Border: Subtle gray border
- Focus state: Blue border or background highlight
- Example: "Search sites..." input in Site Management

**Dropdown Selectors:**
- Label above or beside
- Example: "Filter by Company" dropdown
- Expandable on click
- Keyboard navigable
- Options clearly labeled

**Date Pickers:**
- Calendar interface
- Used for snapshot date selection
- Click date to select
- Clear/Apply buttons

**Buttons:**

**Primary Buttons:** (Blue background)
- Examples: "Add Headcount", "Generate Report", "Take Snapshot Now"
- White text
- Rounded corners (5-10px radius)
- Hover state: Darker blue
- Active state: Pressed appearance

**Secondary Buttons:** (Light background)
- Examples: "Export", "Clear", "Delete"
- Text color matches primary theme
- Outline or minimal fill

**Icon Buttons:**
- Edit (pencil icon)
- Delete (trash icon)
- Menu (three dots)
- Minimal styling
- Hover state: Background highlight

### Filter & Control Panels

**Time Period Filters (Analytics Dashboard):**
- Button group: "7 Days", "30 Days", "90 Days", "All"
- Only one button active at a time
- Clear visual indication of selected option
- Clicking updates chart/data

**Regional Filters (Analytics Dashboard):**
- Button group: "All Regions", "Luzon", "Visayas", "Mindanao"
- Single selection
- Updates displayed metrics
- Shows count of sites in each region

**Company Filters:**
- Dropdown: "All Companies" or specific company
- Used in Client Headcount Report
- Filters displayed data

### User Profile Components

**Profile Button (Top-right):**
- Shows user initials: "BA"
- Avatar styling: Circular or square
- Background color: Differentiated from nav bar
- Dropdown trigger

**Profile Dropdown Menu:**
```
┌─────────────────────────────────┐
│ Benedict Aquino                 │
│ benchakino04@gmail.com          │
├─────────────────────────────────┤
│ ⚙ Settings                      │
├─────────────────────────────────┤
│ 👤 Profile                      │
├─────────────────────────────────┤
│ ❓ Support                      │
├─────────────────────────────────┤
│ 🚪 Logout                       │
└─────────────────────────────────┘
```

**Profile Card (Bottom of Sidebar):**
- Avatar: User initials or photo
- Name: "Amy Elsner" (displayed user)
- Role: "Webmaster"
- Action buttons below card

### Data Display Styles

**Numbers:**
- Large metrics: Bold, large font (48-72px)
- Table values: Standard font
- Thousands separator: Comma (e.g., "1,599")
- Percentages: With % symbol

**Status Indicators:**
- "LIVE" badge on TV Map Display (red/green background)
- Active count vs. Floating count distinction
- Last updated timestamp

**Color Coding:**
- Blue: Primary actions, links, positive metrics
- Green: Success states, positive indicators
- Red: Delete/dangerous actions, alerts
- Orange/Yellow: Warnings, secondary highlights
- Gray: Inactive elements, secondary text

## Navigation Patterns

### Sidebar Navigation

**Interaction:**
1. User hovers over menu item
2. Background highlights
3. User clicks menu item
4. Page navigates to new section
5. Menu item shows active state
6. Content area loads new page

**Collapsible Sections:**
- Click section name to expand/collapse
- Arrow indicator shows state
- Smooth animation
- Remember expanded state

### Breadcrumb Navigation

**Structure:** "Home > Current Section > Subsection"
**Interaction:** Click any breadcrumb to navigate
**Updates:** Changes as user navigates sections

### Top Navigation Actions

**Search:**
1. Click search icon
2. Search input appears or focuses
3. Type query
4. Results appear (real-time filtering)
5. Click result to navigate

**User Profile:**
1. Click user avatar/name
2. Dropdown menu appears
3. Select action (Settings, Logout, etc.)
4. Navigate to selected page/action

## Responsive Design Considerations

### Desktop Layout (1200px+)
- Full sidebar visible
- Wide content area
- Tables display all columns
- Optimal spacing and padding

### Tablet Layout (768px - 1199px)
- Sidebar may collapse to icons
- Content area adjusts width
- Some table columns may stack
- Buttons remain touch-friendly

### Mobile Layout (< 768px)
- Sidebar hidden or drawer-based
- Hamburger menu toggle
- Full-width content area
- Tables may show scrollable cards instead
- Buttons larger for touch interaction

## Accessibility Features

### Keyboard Navigation
- Tab key navigates through elements
- Enter key activates buttons
- Arrow keys for lists/dropdowns
- Escape key closes modals/dropdowns

### Screen Reader Support
- ARIA labels on interactive elements
- Semantic HTML structure
- Form labels associated with inputs
- Alt text for icons

### Visual Accessibility
- High contrast text (dark on light)
- Sufficient font sizes (14px+ for body text)
- Color not only indicator (also text/icons)
- Focus indicators on interactive elements

### Mobile Accessibility
- Touch-friendly button sizes (44px+ recommended)
- Adequate spacing between clickable elements
- Readable text size on mobile
- Logical tab order

## Color Scheme

### Primary Colors
- **Dark Blue:** #5B5BFF (top navigation, primary buttons)
- **Light Blue:** #E8EAFF (hover states, secondary backgrounds)

### Status Colors
- **Green:** #00C853 (success, positive metrics)
- **Blue:** #2196F3 (information, links)
- **Orange:** #FF9800 (warning)
- **Red:** #F44336 (danger, delete actions)
- **Gray:** #9E9E9E (disabled, secondary text)

### Neutral Colors
- **White:** #FFFFFF (content background)
- **Light Gray:** #F5F5F5 (section backgrounds, alternating rows)
- **Dark Gray:** #424242 (primary text)
- **Medium Gray:** #757575 (secondary text)

## Typography

### Font Family
- Primary: Sans-serif (likely Segoe UI, Roboto, or Arial)
- Monospace: Used for code/data (if applicable)

### Font Sizes
- Headings (H1): 24-32px, bold
- Subheadings (H2/H3): 18-20px, semi-bold
- Body text: 14-16px, regular
- Small text: 12-13px, regular
- Captions: 11-12px, regular

### Font Weights
- Bold: 700 (headings, emphasis)
- Semi-bold: 600 (subheadings)
- Regular: 400 (body text)
- Light: 300 (secondary text)

## Spacing & Layout

### Margins
- Top navigation: ~60px height
- Sidebar width: ~230px
- Content padding: 20-30px on sides
- Section spacing: 30-40px between sections

### Padding
- Button internal: 10-15px vertical, 20-25px horizontal
- Card internal: 20px
- Input fields: 10-12px
- Table cells: 12-15px

### Gaps/Gutters
- Between columns: 15-20px
- Between rows: 10px
- Between form fields: 15px

## Interactive States

### Button States
- **Default:** Solid background, normal cursor
- **Hover:** Darker background, pointer cursor
- **Active/Pressed:** Darker shade, inset appearance
- **Disabled:** Grayed out, not-allowed cursor
- **Focus:** Blue outline around button

### Input States
- **Default:** Light background, gray border
- **Focus:** Blue border, light blue background
- **Filled:** Content displayed
- **Error:** Red border, error message below
- **Disabled:** Grayed out, not-allowed cursor

### Row/Card States
- **Default:** White or alternating background
- **Hover:** Light background highlight
- **Selected:** Checkmark, highlighted background
- **Active:** Bold text or colored indicator

## Page Load Behavior

**Loading States:**
- Spinner icon during page transition
- Skeleton screens for large data loads
- Placeholder text in tables
- Smooth transitions between pages

**Error States:**
- "NOT FOUND" message for invalid routes
- "GO BACK TO DASHBOARD" link
- Clear error descriptions
- Suggestions for next steps

## Data Export & Actions

### Export Button Styling
- Icon: Download or export icon
- Label: "Export" or "Export CSV"
- Color: Secondary blue
- Placement: Near top-right of table/section

### File Dialog
- Browser's native file save dialog
- Filename: Auto-generated based on data type
- Format: CSV (comma-separated values)
- Date included in export: Optional

## Print Styling

**Print Considerations:**
- Dashboard optimized for screen viewing
- Charts may not print well (export as CSV instead)
- Tables printable with pagination
- Logo and header appear at top
- Page breaks handled appropriately

## Performance & Visual Feedback

### Loading Indicators
- Spinner animation during data fetch
- Progress bar for long operations
- Skeleton screens matching content layout

### Confirmation Dialogs
- "Are you sure?" confirmation for delete operations
- Clear action buttons: "Cancel", "Confirm"
- Descriptive text explaining action

### Toast Notifications
- Appear top-right of screen
- Auto-dismiss after 3-5 seconds
- Success (green), Error (red), Warning (orange), Info (blue)
- Examples: "Snapshot created successfully", "Error saving changes"

### Tooltips
- Hover over icons for explanations
- "Headcount = Active + Floating" on hover
- Region descriptions
- Last updated timestamps

## Customization Features

### Theme Selection
- Dark mode toggle (Light/Dark buttons)
- Color theme selector (noir, emerald, green, lime, orange, etc.)
- Sidebar layout options (Static, Overlay, Slim, Slim+, Reveal, Drawer)
- Sidebar position (Start, End)
- Language selection (if applicable)

### User Preferences
- Rows per page setting (default: 10)
- Saved filter preferences
- Last viewed page
- Recent reports generated

## Summary of Key UI Patterns

1. **Dashboard Pattern:** Metrics cards + Charts + Tables
2. **CRUD Pattern:** List view, Create form, Edit form, Delete confirmation
3. **Filter & Search Pattern:** Input + Buttons + Data table
4. **Report Generation:** Date picker + Filters + Generate button + Export
5. **Navigation Pattern:** Sidebar menu + Breadcrumbs + Top actions

These patterns are consistently applied throughout the application, ensuring intuitive user experience and predictable interactions.

