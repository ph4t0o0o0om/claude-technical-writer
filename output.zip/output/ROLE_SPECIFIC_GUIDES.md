# Car Booking System - Role-Specific Quick Reference Guides

## Quick Navigation by Role

---

## REQUESTER QUICK START GUIDE

### Your Main Tasks
1. ✓ Create booking requests
2. ✓ Edit bookings before RSB approval
3. ✓ Track approval status
4. ✓ Acknowledge completed trips

### Step 1: Create a Booking Request (5 minutes)

```
1. Click "Bookings" → "New Booking"
2. Enter Required Information:
   ├─ Your Name
   ├─ Your Department
   ├─ Client Name (e.g., Fiberhome)
   ├─ Company Assigned (e.g., Fiberhome – Primus)
   ├─ Number of Passengers
   ├─ Pickup Date (5+ days from today)
   ├─ Pickup Time
   ├─ Pickup Location
   └─ Drop-off Location / Purpose
3. Click "Submit"
4. You'll get a Reference Number
5. Status automatically goes to "Pending Department Head Approval"
```

### Step 2: Track Your Booking

```
1. Go to "My Bookings"
2. Find your booking by Reference Number or date
3. Click to view status:
   - "Pending Department Head Approval" → Awaiting first approval
   - "Pending RSB Approval" → In RSB review
   - "Pending WVB Approval" → Awaiting vehicle/driver assignment
   - "Pending ODJ Approval" → Operations review
   - "Pending NAN Approval" → Final authorization
   - "Approved & Scheduled" → Confirmed! Vehicle assigned.
   - "Rejected" → Need to make corrections (see Step 4)
```

### Step 3: Edit Booking (Before RSB Approval Only)

```
1. Open your booking with status "Pending Department Head" or "Pending RSB"
2. Click "Edit" button
3. Modify any fields needed
4. Click "Save"
5. Changes are noted with timestamp
6. Booking continues through approval

IMPORTANT: Cannot edit after RSB approves.
Contact RSB if changes needed later.
```

### Step 4: If Your Booking is Rejected

```
1. Open your rejected booking
2. Find "Rejection Reason" section
3. Understand what needs correction
4. Click "Edit"
5. Make necessary corrections
6. Click "Resubmit"
7. Booking goes back through approval process
8. Repeat until approved
```

### Step 5: Acknowledge Completed Trip

```
1. You'll receive notification "Trip Report Ready for Acknowledgment"
2. Go to "My Trips" or "Trip Reports"
3. Open the trip report
4. Review all details and expenses:
   - Mileage (start/end)
   - Time returned
   - All expenses listed
5. Click "Acknowledge" if correct
   OR "Dispute" if charges seem wrong
6. Trip is then finalized
```

### Timeline Expectations

| Stage | Typical Time | What's Happening |
|-------|-------------|-----------------|
| Department Head | 4-8 hours | Your manager approves |
| RSB | 4-12 hours | Administrative review |
| WVB | 4-24 hours | Vehicle & driver assigned |
| ODJ | 2-8 hours | Operations confirm |
| NAN | 2-4 hours | Final approval |
| Scheduled | Immediate | Your trip is confirmed |
| **TOTAL** | **2-3 days** | From submission to confirmed |

**Pro Tip:** Submit 5+ days before needed = plenty of time for approvals.

### Costs You'll Pay

After your trip completes:

```
TOTAL COST = Vehicle Charge + Driver Fee + Expenses

Example for Makati trip (8 hours):
├─ Vehicle Charge (Makati) = PHP 500
├─ Driver Fee (Whole Day) = PHP 1,200
├─ Fuel = PHP 400
├─ Parking = PHP 150
├─ RFID Tolls = PHP 250
└─ TOTAL = PHP 2,500
```

### Contact When You Need Help

| Issue | Contact |
|-------|---------|
| Booking rejected | Department Head (then RSB if persists) |
| Can't edit booking | RSB (they have override capabilities) |
| Cost seems wrong | RSB2 or Payables |
| Trip not scheduled | WVB or ODJ |
| General questions | Your Department Head or booking support |

---

## DEPARTMENT HEAD APPROVAL GUIDE

### Your Role
You're the **first approver** in the workflow. Your approval determines if the booking moves forward to RSB.

### Key Responsibilities

✓ Review requests from your department
✓ Verify trip is business-justified
✓ Check for policy violations
✓ Approve or reject based on departmental standards
✓ Provide feedback on rejections

### Approval Workflow

```
Step 1: Receive Notification
├─ Email or dashboard notification
├─ Shows pending requests from your department
└─ Click to view request

Step 2: Review the Request
├─ Check client name and company
├─ Verify passenger count is reasonable
├─ Confirm pickup date is valid
├─ Ensure destination is documented
└─ Review purpose/justification

Step 3: Make Your Decision
├─ APPROVE → Request goes to RSB
└─ REJECT → Request returns to requester

Step 4: Add Comments (Optional but Recommended)
├─ Add context for next approvers
├─ Explain reason if rejecting
├─ Note any special considerations
└─ Type in comments box

Step 5: Submit Your Approval/Rejection
└─ Click "Approve" or "Reject" button
```

### Approval Checklist

Before approving, verify:

- [ ] Requester is from my department
- [ ] Trip is business-justified (client/company legitimate)
- [ ] Dates and times are reasonable
- [ ] Passenger count is appropriate
- [ ] Destination is clear
- [ ] No policy violations
- [ ] Timing allows for vehicle availability

### When to REJECT

Reject if:
- Requester from different department
- No clear business purpose
- Travel violates company policy
- Dates/times are unreasonable
- Insufficient information provided
- Budget constraints apply
- Personal travel disguised as business

### Communication Tips

**When Approving:**
- "Approved for processing"
- Or just approve silently (system notifies requester)

**When Rejecting:**
- "Requires additional justification for client visit"
- "Please confirm this is essential business travel"
- "Budget limit exceeded for this month - please resubmit next month"
- "Client name not recognized - verify contact information"

Be specific so requester knows exactly what to fix.

### Timeline

- **Your approval deadline:** 8 hours (preferably faster)
- **Check system daily** for new pending requests
- **Set email alerts** if available
- **Batch review** if multiple requests arrive

### What Happens Next

After you approve:

```
Your Approval ↓
    ↓
    RSB reviews (4-12 hours)
    ↓
    WVB assigns vehicle/driver (4-24 hours)
    ↓
    ODJ confirms operationally (2-8 hours)
    ↓
    NAN gives final approval (2-4 hours)
    ↓
    Booking scheduled automatically
```

Your approval is stage 1 of 5.

### Quick Reference

| Status | Your Action |
|--------|------------|
| Pending Department Head Approval | THIS IS YOU - Review and approve/reject |
| Pending RSB Approval | No action needed - wait |
| Approved & Scheduled | Booking is confirmed |
| Rejected | Not your responsibility unless requester asks |

---

## RSB (RESERVATION SERVICE BUREAU) OPERATIONAL GUIDE

### Your Role
You're the **second-level approver** and **operational coordinator** for all bookings.

### Key Responsibilities

✓ Review bookings from Department Head
✓ Verify administrative requirements
✓ Check policy compliance
✓ Approve or reject bookings
✓ Edit and modify booking details (extended permissions)
✓ Encode trip completion details after trips
✓ Manage operational issues

### Daily Workflow

#### Morning
1. Check dashboard for pending bookings
2. Review all "Pending RSB Approval" items
3. Verify document requirements
4. Approve or reject with comments

#### During Day
1. Monitor approved bookings progressing to WVB
2. Handle incoming trip reports from previous trips
3. Respond to requester questions
4. Manage any operational adjustments

#### Evening
1. Review trip completion if any trips finished
2. Prepare reports for next day
3. Flag any issues for follow-up

### Approval Process (5-10 minutes per booking)

```
1. Open pending booking
2. Review:
   ├─ Client information (valid?)
   ├─ Requester details (complete?)
   ├─ Dates and times (reasonable?)
   ├─ Location (clear destination?)
   ├─ Passenger count (matches vehicle need?)
   ├─ Department Head approval comment
   └─ Any flags or special notes

3. Check Policy Compliance:
   ├─ Booking violates no policies
   ├─ Timing is adequate
   ├─ Destination is mapped (for billing)
   └─ Company is recognized

4. Decide:
   ├─ APPROVE → Sends to WVB for vehicle assignment
   └─ REJECT → Returns to requester for correction

5. Add Comments:
   ├─ If approving: (optional) note any considerations
   ├─ If rejecting: REQUIRED - explain what's needed
   └─ Add notes for WVB or other approvers

6. Click "Approve" or "Reject"
```

### Extended Editing Permissions

As RSB, you can edit bookings even after they're partially approved:

```
Click "Edit" on any booking
Edit allowed fields:
├─ Client name/company
├─ Pickup/drop-off location
├─ Passenger count
├─ Trip purpose/notes
├─ Dates and times (with caution)
└─ Other administrative details

Save changes
Changes are timestamped
Booking status may revert depending on changes
Other approvers notified of changes
```

### Trip Completion Encoding (After Trip)

When a vehicle returns from a trip:

```
Step 1: Access Trip Report
├─ Navigate to "Trip Completion" or "New Trip Report"
├─ Select the completed booking
└─ Click "Encode Trip Details"

Step 2: Record Actual Return Time
├─ Click "Time Returned" field
├─ Enter actual return time (24-hour format)
└─ Example: 17:30 for 5:30 PM

Step 3: Enter Mileage
├─ Start Mileage: odometer reading when trip started
├─ End Mileage: odometer reading when returned
├─ System calculates distance automatically
└─ Verify numbers make sense

Step 4: Record All Expenses
├─ Fuel Cost: PHP amount from receipt
├─ RFID Cost: toll charges (if any)
├─ Parking Cost: fees paid during trip
├─ Carwash Cost: vehicle cleaning (if done)
└─ Other Expenses: any additional costs

Step 5: Save Trip Report
├─ Review all entries
├─ Click "Save"
├─ System calculates totals
└─ Report sent to RSB2 for verification

Step 6: System Calculations (Automatic)
├─ Distance = End Mileage - Start Mileage
├─ Driver Fee = PHP 1,200 (whole day) or PHP 600 (half day)
├─ Vehicle Charge = Based on destination location
├─ Total Expenses = Sum of all expense items
└─ TOTAL TRIP COST = Vehicle + Driver + Expenses
```

### Expense Documentation Checklist

Before encoding trip report, collect from driver:

- [ ] Fuel receipt (amount & store)
- [ ] Parking receipts (if applicable)
- [ ] RFID toll receipt (highway trips)
- [ ] Carwash receipt (if done)
- [ ] Any other cost receipts
- [ ] Odometer readings confirmed
- [ ] Actual return time recorded

### Decision Criteria

**APPROVE booking if:**
- ✓ All required information present
- ✓ No policy violations
- ✓ Destination recognized
- ✓ Dates are reasonable
- ✓ Department Head approved

**REJECT booking if:**
- ✗ Missing critical information
- ✗ Policy violation identified
- ✗ Destination unclear/invalid
- ✗ Dates/times problematic
- ✗ Client not recognized
- ✗ Duplicate booking detected

### Common Issues and Solutions

| Issue | Solution |
|-------|----------|
| Incomplete booking info | Reject with specific request for info |
| Invalid client name | Edit to correct name before approving |
| Dates in past | Reject - cannot book past dates |
| Vague destination | Request clarification in rejection |
| No trip purpose | Reject - requires clear purpose |

### Reporting

Weekly reporting includes:
- Total bookings processed
- Approval/rejection rate
- Average approval time
- Common rejection reasons
- Trip completion status

### Contact and Escalation

- **Questions about policy:** Contact management
- **Operational issues:** Contact WVB or ODJ
- **System problems:** Contact IT support
- **Disputes about costs:** Escalate to RSB2 or Finance

---

## WVB (VEHICLE & DRIVER ASSIGNMENT) OPERATIONAL GUIDE

### Your Role
You're the **third-level approver** and **vehicle/driver coordinator**.

### Key Responsibilities

✓ Receive bookings from RSB approval
✓ Assign appropriate vehicles
✓ Assign suitable drivers
✓ Approve or reject based on resource availability
✓ Manage fleet scheduling
✓ Handle reassignments and changes

### Available Resources

#### Vehicles

| Vehicle | Company | Capacity | Notes |
|---------|---------|----------|-------|
| Innova Gray | Primetech | 7-9 seats | Standard |
| Innova Red | Primus | 7-9 seats | Standard |
| Innova Hybrid | Primus | 7-9 seats | Fuel-efficient |
| Tamaraw | Primus | 6-8 seats | Compact |

#### Drivers by Company

**Primus Drivers:**
- MPR
- CEP
- KMB
- WVB
- EHM

**Prime Drivers:**
- DDC
- EAB

**Others:** Configurable per management

### Assignment Workflow

```
Step 1: Open Pending Booking
├─ Navigate to "Pending WVB Approval"
├─ Find booking with RSB approval
└─ Click to open details

Step 2: Assess Requirements
├─ Number of passengers: ___
├─ Trip distance: ___
├─ Pickup date/time: ___
├─ Drop-off location: ___
└─ Special requirements: ___

Step 3: Check Vehicle Availability
├─ Note selected date: ___
├─ View available vehicles (system shows)
├─ Consider:
│  ├─ Passenger fit
│  ├─ Vehicle availability
│  ├─ Company match
│  └─ Driver availability
└─ Select vehicle

Step 4: Assign Vehicle
├─ Click "Assign Vehicle"
├─ Select from available list
├─ Confirm selection
└─ Vehicle is reserved

Step 5: Assign Driver
├─ Click "Assign Driver"
├─ Select from available drivers
├─ Confirm driver company matches vehicle
├─ Confirm selection
└─ Driver is assigned

Step 6: Review Assignment
├─ Verify vehicle & driver are appropriate
├─ Check for scheduling conflicts
├─ Add any special notes
└─ Ready to approve or reject

Step 7: Approve or Reject
├─ APPROVE → Booking goes to ODJ
├─ REJECT → if no vehicle/driver available
│   ├─ Provide clear reason
│   ├─ Suggest alternative dates
│   ├─ Return to requester
│   └─ Recommend rescheduling
└─ Click button to submit decision
```

### Vehicle Selection Criteria

**For 4-5 Passengers:**
- Any vehicle works
- Prefer compact (Tamaraw) if available
- Saves fuel, reduces costs

**For 6-8 Passengers:**
- Use standard vehicles (Innova Gray, Red, Hybrid)
- Tamaraw can work for exactly 6

**For 9+ Passengers:**
- Cannot accommodate in single vehicle
- Suggest multiple bookings
- Offer to assist with second vehicle

**By Company Matching:**
- Fiberhome – Primus → Use Primus vehicles (Red, Hybrid, Tamaraw)
- Other clients → Match to assigned company

**By Trip Type:**
- Long-distance: Use well-maintained vehicle (Red is reliable)
- Fuel-sensitive: Use Hybrid for efficiency
- Short trips: Use any available

### Driver Selection Criteria

**By Company:**
- Client = Primus → Assign Primus drivers (MPR, CEP, KMB, WVB, EHM)
- Client = Prime → Assign Prime drivers (DDC, EAB)
- Match company assignment

**By Qualifications:**
- Long-distance trips: Experienced drivers
- Highway routes: Drivers with highway experience
- Special routes: Drivers familiar with area

**By Availability:**
- Check driver schedule
- Avoid overworking drivers
- Balance workload fairly
- Keep backups for emergencies

**By Performance:**
- Assign reliable drivers first
- Consider driver safety record
- Prefer consistent performers
- Note any driver issues/concerns

### Rejection Scenarios

**REJECT with reason if:**
1. "No available vehicle for selected date"
   - Suggest alternative date 2-3 days later
   - Recommend 2-vehicle option

2. "No available driver for selected date"
   - Suggest alternative date
   - Explain driver constraints

3. "Passenger count exceeds vehicle capacity"
   - Recommend multiple vehicles
   - Suggest discussing with requester

4. "Vehicle/driver company mismatch"
   - Request clarification on company assignment
   - Flag to requester

### Extended Editing Permissions

You can edit assignments even for approved bookings:

```
Open booking → Click "Edit Assignment"
Can change:
├─ Vehicle assignment
├─ Driver assignment
├─ Assignment date/time (if still valid)
└─ Special notes

Save changes
Previous approvals not affected
Changes timestamped
```

### Fleet Management Dashboard

Access to monitor:

**Vehicle Status:**
- Currently assigned vehicles
- Available vehicles by date
- Maintenance schedules
- Vehicle utilization
- Mileage tracking

**Driver Status:**
- Currently assigned drivers
- Available drivers by date
- Driver schedules
- Performance metrics
- Driver records

**Booking Status:**
- Total pending assignments
- Quick approval/reject stats
- Average assignment time
- Bottleneck identification

### Handling Edge Cases

| Situation | Action |
|-----------|--------|
| Vehicle breaks down | Mark unavailable, reassign booking to alternate vehicle |
| Driver calls in sick | Mark unavailable, reassign booking to alternate driver |
| Urgent request | Can expedite assignment if resources available |
| Multiple options equally valid | Assign best performer or rotate fairly |
| Maintenance scheduled | Block vehicle from that date, reassign other bookings |

### Communication Protocol

**When Approving:**
- "Vehicle [name] and Driver [name] assigned. Approved for processing."
- Or just approve silently; system notifies others

**When Rejecting:**
- "No vehicle available for 2026-05-10. Please select alternative date (2026-05-12 or later)."
- "Driver availability limited. Suggest split to 2 vehicles for full group."
- Clear message so requester understands constraints

### Approvals That Follow

After your approval, booking goes to:
```
Your Assignment ↓
    ↓
    ODJ verifies operational feasibility (2-8 hours)
    ↓
    NAN provides final approval (2-4 hours)
    ↓
    Booking scheduled automatically
```

You're stage 3 of 5 in approval workflow.

---

## ODJ (OPERATIONS & DISPATCH) OPERATIONAL GUIDE

### Your Role
You're the **fourth-level approver** and **operational validator**.

### Key Responsibilities

✓ Review fully assigned bookings
✓ Verify operational feasibility
✓ Confirm dispatch procedures
✓ Monitor active trips
✓ Handle operational issues during trips
✓ Approve or reject based on operational constraints

### Approval Workflow

```
Step 1: Receive Booking
├─ Booking arrives with full assignment
├─ Vehicle already assigned
├─ Driver already assigned
└─ Ready for operational review

Step 2: Verify Operational Feasibility
├─ Check route (system shows pickup → drop-off)
├─ Verify driver qualifications for route
├─ Confirm vehicle condition
├─ Check for scheduling conflicts
└─ Review any special requirements

Step 3: Operational Checklist
├─ [ ] Vehicle registered and insured
├─ [ ] Driver licensed for vehicle type
├─ [ ] Route doesn't exceed operational limits
├─ [ ] No GPS/communication issues
├─ [ ] Vehicle fuel-ready for trip
├─ [ ] Driver familiar with destination
├─ [ ] Special equipment/permissions if needed

Step 4: Make Decision
├─ APPROVE → Booking goes to NAN for final approval
└─ REJECT → Return to requester with operational issue

Step 5: Add Comments
├─ If approving: Note any operational requirements
├─ If rejecting: Explain operational constraint
├─ Flag any special handling needs
└─ Provide context for dispatch team
```

### Operational Verification

**Route Verification:**
- Is pickup location accessible by vehicle?
- Is drop-off location reachable?
- Any road closures or restrictions?
- Parking available at destination?

**Driver Verification:**
- Licensed for vehicle type? (Truck vs Car)
- Familiar with route area?
- Any special training needed?
- Safety record acceptable?

**Vehicle Verification:**
- Vehicle condition appropriate?
- Maintenance current?
- Fuel available?
- GPS functional?
- Communications working?

### Common Operational Issues

| Issue | Resolution |
|-------|-----------|
| Driver not trained for route | Reject - reassign to different driver |
| Vehicle needs maintenance | Reject - fix vehicle first |
| Destination access restricted | Verify access with client before approving |
| High-risk area | Escalate to management if safety concern |
| Special equipment needed | Verify vehicle has required equipment |

### Approval Decision Criteria

**APPROVE if:**
- ✓ Vehicle is operational and maintained
- ✓ Driver has required qualifications
- ✓ Route is operationally feasible
- ✓ No conflicts or constraints
- ✓ All dispatch requirements met

**REJECT if:**
- ✗ Vehicle operational issues
- ✗ Driver qualification concerns
- ✗ Route not operationally feasible
- ✗ Safety or compliance issues
- ✗ Dispatch constraints

### What Happens Next

After your approval:
```
Your Approval ↓
    ↓
    NAN provides final authorization (2-4 hours)
    ↓
    Booking scheduled automatically
    ↓
    Trip appears in dispatch schedule
```

You're stage 4 of 5 in approval workflow.

### Active Trip Monitoring

Once trip is scheduled and trip day arrives:

**Pre-Trip:**
- Verify vehicle is ready
- Confirm driver is available
- Brief driver if needed
- Ensure all equipment present

**During Trip:**
- Monitor driver location (if GPS available)
- Be available for emergencies
- Handle any issues that arise
- Communicate with driver if needed

**Post-Trip:**
- Verify safe return
- Check vehicle condition
- Note any issues
- Prepare for RSB encoding

---

## NAN (FINAL AUTHORIZATION) OPERATIONAL GUIDE

### Your Role
You're the **final approver** providing ultimate authorization before booking confirmation.

### Key Responsibilities

✓ Provide final authorization
✓ Verify all approvals are complete
✓ Ensure all information is accurate
✓ Authorize booking to proceed to scheduling
✓ Handle escalations

### Final Approval Workflow

```
Step 1: Receive Fully Approved Booking
├─ Booking has 4 prior approvals:
│  ├─ Department Head ✓
│  ├─ RSB ✓
│  ├─ WVB (Vehicle/Driver) ✓
│  └─ ODJ (Operations) ✓
├─ Vehicle and driver assigned
├─ All required information present
└─ Ready for final authorization

Step 2: Quick Verification
├─ Review all approval chain
├─ Verify no conflicting comments
├─ Check for any red flags
├─ Confirm operational readiness
└─ Ensure all data is clean

Step 3: Final Approval
├─ APPROVE → Booking automatically scheduled
└─ REJECT → Return for corrections (rare)

Step 4: Booking Automatically Scheduled
├─ Trip appears on Car Booking Schedule
├─ Notification sent to requester
├─ Notification sent to all approvers
├─ Notification sent to driver
├─ Trip is finalized and confirmed
└─ Vehicle and driver are reserved
```

### Approval Verification Checklist

Before final approval, confirm:

- [ ] All 4 prior approvers have signed
- [ ] Vehicle is assigned
- [ ] Driver is assigned
- [ ] No approval notes indicate issues
- [ ] Requester information is complete
- [ ] Destination is documented
- [ ] Dates are reasonable
- [ ] No conflicting assignments

### Quick Decision Making

This is typically a quick approval (2-4 minutes):

1. Open booking
2. Scan approvals (all complete? ✓)
3. Verify vehicle/driver assigned ✓
4. Check for red flags (none? ✓)
5. Click "Approve"
6. Done - booking automatically scheduled

### When to REJECT (Rare)

Only reject if:
- Critical information is missing
- Conflicting approvals exist
- Red flags in comments
- Data integrity issues
- Escalation from requester

If rejecting:
- Clearly state reason
- Specify what needs correction
- Return to appropriate approver

### Post-Approval

Once you approve:

```
Your Final Approval ✓
    ↓
    System automatically schedules booking
    ↓
    Booking appears on Car Booking Schedule
    ↓
    Notifications sent to all parties:
    ├─ Requester (trip confirmed)
    ├─ Driver (new assignment)
    ├─ Department Head (for their records)
    ├─ All approvers (closure notification)
    └─ Dispatch/Operations (trip ready)
```

**Your approval is stage 5 of 5 - the final stage!**

---

## RSB2 (TRIP VERIFICATION) OPERATIONAL GUIDE

### Your Role
You verify trip completion reports to ensure accuracy before requester acknowledgment.

### Key Responsibilities

✓ Review trip completion reports from RSB
✓ Verify accuracy of expenses and calculations
✓ Confirm mileage calculations are correct
✓ Sign off on trip reports
✓ Flag discrepancies for investigation

### Trip Report Verification Workflow

```
Step 1: Receive Trip Report
├─ Notification: "Trip Report Awaiting RSB2 Verification"
├─ Trip has been completed and encoded by RSB
├─ All expense information entered
└─ Ready for your verification

Step 2: Access Trip Report
├─ Navigate to "Trip Reports" → "Pending RSB2 Verification"
├─ Find trip to verify
└─ Click to open detailed report

Step 3: Review Trip Information
├─ Trip Date: ___________
├─ Pickup Location: ___________
├─ Drop-off Location: ___________
├─ Vehicle Assigned: ___________
├─ Driver Assigned: ___________
└─ Requester: ___________

Step 4: Verify Mileage Calculation
├─ Start Mileage: ___
├─ End Mileage: ___
├─ Calculated Distance = End - Start
│  └─ Verify makes sense
├─ Compare to typical distance for route
└─ Flag if unreasonable (e.g., 500 km for local trip)

Step 5: Verify Time Calculation
├─ Pickup Time: ___
├─ Return Time: ___
├─ Duration = Return - Pickup
├─ Duration > 8 hours? → Whole Day (PHP 1,200)
├─ Duration < 8 hours? → Half Day (PHP 600)
└─ Verify correct fee applied

Step 6: Verify Expense Amounts
├─ Fuel Cost: PHP ___
│  └─ Reasonable for distance? ✓
├─ RFID Cost: PHP ___
│  └─ Matches toll receipt? ✓
├─ Parking Cost: PHP ___
│  └─ Matches receipts? ✓
├─ Carwash Cost: PHP ___
│  └─ If applicable, matches receipt? ✓
└─ Other Expenses: PHP ___
   └─ Documented with reason? ✓

Step 7: Verify Vehicle Charge (Automatic)
├─ Drop-off location identified
├─ System applies location-based charge
├─ Verify correct tier applied:
│  ├─ PHP 500 tier locations? → PHP 500
│  ├─ PHP 1,000 tier locations? → PHP 1,000
│  ├─ PHP 1,500 tier locations? → PHP 1,500
│  ├─ PHP 2,500 tier locations? → PHP 2,500
│  └─ PHP 3,500 tier locations? → PHP 3,500
└─ Charge correct? ✓

Step 8: Verify Total Calculation
├─ Vehicle Charge: PHP ___
├─ Driver Fee: PHP ___
├─ Fuel: PHP ___
├─ RFID: PHP ___
├─ Parking: PHP ___
├─ Carwash: PHP ___
├─ Other: PHP ___
└─ Total = ??? (should equal system total)

Step 9: Make Decision
├─ If everything correct:
│  ├─ Click "Approve"
│  ├─ Add your signature/name
│  ├─ Report moves to Requester Acknowledgment
│  └─ Requester sees and confirms
│
├─ If discrepancies found:
│  ├─ Click "Reject"
│  ├─ Specify what needs correction
│  ├─ Return to RSB for re-encoding
│  ├─ RSB corrects and resubmits
│  └─ You review again
│
└─ Add comments (optional)
   └─ Note anything unusual or special
```

### Verification Checklist

Before approving, verify:

- [ ] Mileage makes sense for trip
- [ ] Time calculation is correct
- [ ] Driver fee matches duration
- [ ] Vehicle charge matches location
- [ ] All expenses have receipts
- [ ] Expense amounts are reasonable
- [ ] No duplicate charges
- [ ] Total calculation is accurate
- [ ] All data entry is clean (no typos)

### Red Flags to Watch For

| Red Flag | Action |
|----------|--------|
| Mileage too high for location | Ask RSB to verify |
| Expense amounts very high | Request receipt verification |
| Duplicate charges | Reject - ask RSB to correct |
| Missing receipts for expenses | Reject - can't verify |
| Parking cost excessive | Verify with RSB |
| Inconsistent numbers | Reject - ask for re-entry |

### Common Discrepancies and Solutions

| Discrepancy | Solution |
|-------------|----------|
| Fuel cost seems high | Verify actual fuel consumed matches distance |
| Parking overstated | Request itemized parking details |
| RFID mismatch | Match against toll receipt from driver |
| Time calculation wrong | Recalculate; verify pickup/return times |
| Wrong vehicle charge applied | Check destination location mapping |

### Approval Decision

**APPROVE if:**
- ✓ All information accurate
- ✓ All receipts match entries
- ✓ Calculations correct
- ✓ No discrepancies found
- ✓ Amounts are reasonable

**REJECT if:**
- ✗ Discrepancies found
- ✗ Missing receipt evidence
- ✗ Calculation errors
- ✗ Duplicate charges
- ✗ Suspicious amounts

### What Happens After Approval

```
Your Approval ✓
    ↓
    Report moves to "Awaiting Requester Acknowledgment"
    ↓
    Requester reviews and confirms
    ├─ Acknowledges (accepts charges)
    └─ OR Disputes (challenges charges)
    ↓
    Payables processes for billing
    ↓
    Finance records in accounting system
```

---

## PAYABLES & MOM FINANCIAL GUIDES

### PAYABLES ROLE

**Key Responsibilities:**
✓ Review financial summaries
✓ Verify billing calculations
✓ Process payments to companies
✓ Generate invoices
✓ Sign off on financial summaries

**Quick Workflow:**

```
1. Access Financial > Billing Summary
2. Review consolidated costs by company
3. Verify RSB signature on trip reports
4. Verify calculations are accurate
5. Prepare invoices for billing
6. Add Payables signature
7. Send to MOM for final authorization
```

---

### MOM ROLE

**Key Responsibilities:**
✓ Provide executive oversight
✓ Authorize large expenses
✓ Review consolidated summaries
✓ Generate management reports
✓ Ensure policy compliance

**Quick Workflow:**

```
1. Receive financial summary from Payables
2. Review RSB and Payables signatures
3. Check for unusual expenses
4. Verify company charges reasonable
5. Add MOM signature (final approval)
6. Report finalized for accounting
```

---

## QUICK REFERENCE - ALL ROLES AT A GLANCE

| Role | Creates | Approves | Edits | Assigns Vehicle/Driver |
|------|---------|----------|-------|----------------------|
| **Requester** | ✓ Own | ✗ | ✓ Before RSB | ✗ |
| **Dept Head** | ✗ | ✓ Stage 1 | Limited | ✗ |
| **RSB** | ✗ | ✓ Stage 2 | ✓ Extended | ✗ |
| **WVB** | ✗ | ✓ Stage 3 | ✓ Assignments | ✓ Yes |
| **ODJ** | ✗ | ✓ Stage 4 | Limited | ✗ |
| **NAN** | ✗ | ✓ Stage 5 | Limited | ✗ |
| **RSB2** | ✗ | ✓ Trip reports | Limited | ✗ |
| **Payables** | ✗ | ✓ Billing | ✗ | ✗ |
| **MOM** | ✗ | ✓ Final | ✗ | ✗ |

---

**Document Version 1.0**
**Last Updated: 2026-04-29**
**Car Booking System - Role-Specific Guides**

