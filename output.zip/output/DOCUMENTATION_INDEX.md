# Car Booking System - Complete Documentation Index

## Overview

This directory contains comprehensive documentation for the **Car Booking System**, an internal web application designed to manage and streamline vehicle reservation requests, approvals, scheduling, and post-usage reporting within an organization.

---

## Documentation Files

### 1. **CARBOOKING_SYSTEM_MANUAL.md** (PRIMARY DOCUMENT)
**Purpose:** Comprehensive user manual covering all aspects of the system
**Size:** ~55 KB | **Length:** 15+ sections | **Audience:** All users

**Contents:**
- Introduction and system overview
- Getting started and login instructions
- System overview and navigation
- Before appointment phase (request creation, approval workflow, scheduling)
- Approval workflow (5 stages with detailed procedures)
- Scheduling procedures
- After appointment phase (trip completion, validation)
- Role-specific guides (Requester, Dept Head, RSB, WVB, ODJ, NAN, RSB2, Payables, MOM)
- Financial and billing information
- Driver and vehicle management
- Reports and analytics
- Best practices by role
- Troubleshooting and FAQs
- Reference information
- Glossary of terms

**How to Use:**
- Start here for comprehensive understanding
- Use Table of Contents for quick navigation
- Reference specific sections as needed

---

### 2. **ROLE_SPECIFIC_GUIDES.md** (QUICK REFERENCE)
**Purpose:** Fast, role-specific operational guides
**Size:** ~30 KB | **Length:** 9 role guides | **Audience:** Role-specific users

**Contents:**
- Requester Quick Start Guide
- Department Head Approval Guide
- RSB Operational Guide
- WVB (Vehicle & Driver Assignment) Guide
- ODJ (Operations & Dispatch) Guide
- NAN (Final Authorization) Guide
- RSB2 (Trip Verification) Guide
- Payables & MOM Financial Guides
- Quick reference table for all roles

**How to Use:**
- Find your role in the table of contents
- Read the quick start section
- Follow step-by-step procedures
- Use decision criteria for your role

---

### 3. **QUICK_REFERENCE_CARDS.md** (CHEAT SHEETS)
**Purpose:** Quick lookup cards and reference materials
**Size:** ~20 KB | **Length:** 8 reference cards | **Audience:** All users (especially for quick lookups)

**Contents:**
- Card 1: Approval workflow at a glance
- Card 2: Location billing quick lookup table
- Card 3: Driver fees and trip duration calculator
- Card 4: Vehicle and driver company mapping
- Card 5: Trip cost quick calculator
- Card 6: Approval timeline tracker
- Card 7: Common booking scenarios
- Card 8: Troubleshooting quick guide

**How to Use:**
- Bookmark for quick reference
- Print for desk reference
- Use while working in the system

---

## Key Reference Information

### System Access
- **URL:** https://headcount.employeeskiosk.com
- **Login Email:** benchakino04@gmail.com
- **Login Password:** 123456

### Critical Workflows
1. **Booking Creation** → 5 Approval Stages → Scheduling
2. **Trip Execution** → Trip Report Encoding → Verification → Acknowledgment
3. **Financial Processing** → Billing Summary → Final Approval

### Important Tables

#### Approval Workflow Stages
| Stage | Role | Duration | Decision |
|-------|------|----------|----------|
| 1 | Department Head | 4-8 hours | Business-justified? |
| 2 | RSB | 4-12 hours | Administrative requirements met? |
| 3 | WVB | 4-24 hours | Vehicle & driver available? |
| 4 | ODJ | 2-8 hours | Operationally feasible? |
| 5 | NAN | 2-4 hours | Final authorization? |

#### Location-Based Billing
| Tier | Destination Examples | Charge |
|------|----------------------|--------|
| 1 | Mandaluyong, Pasig, Makati, etc. | PHP 500 |
| 2 | Manila, QC, Malabon, etc. | PHP 1,000 |
| 3 | Bulacan, Cavite, Laguna, Rizal | PHP 1,500 |
| 4 | Pampanga | PHP 2,500 |
| 5 | Pangasinan, Quezon | PHP 3,500 |
| 6 | Other locations | Custom |

#### Driver Fees
| Duration | Fee |
|----------|-----|
| Less than 8 hours (Half Day) | PHP 600 |
| 8 hours or more (Whole Day) | PHP 1,200 |

#### Vehicle-Company Mapping
| Vehicle | Color | Company |
|---------|-------|---------|
| Innova | Gray | Primetech |
| Innova | Red | Primus |
| Innova Hybrid | Standard | Primus |
| Tamaraw | Standard | Primus |

#### Driver-Company Mapping
| Company | Drivers |
|---------|---------|
| Primus | MPR, CEP, KMB, WVB, EHM |
| Prime | DDC, EAB |
| Others | Configurable |

---

## How to Navigate This Documentation

### For First-Time Users
1. Start with **CARBOOKING_SYSTEM_MANUAL.md** - Introduction section
2. Read "Getting Started" section
3. Review your role-specific guide in **ROLE_SPECIFIC_GUIDES.md**
4. Bookmark **QUICK_REFERENCE_CARDS.md** for daily use

### For Quick Lookups
1. Use **QUICK_REFERENCE_CARDS.md** for instant answers
2. Reference tables in the manual for detailed information
3. Check troubleshooting guide for common issues

### For Role-Specific Tasks
1. Open **ROLE_SPECIFIC_GUIDES.md**
2. Find your role
3. Follow the step-by-step procedures
4. Use decision criteria provided

### For Problem Solving
1. Check **QUICK_REFERENCE_CARDS.md** - Card 8 (Troubleshooting)
2. Review **CARBOOKING_SYSTEM_MANUAL.md** - Troubleshooting section
3. Identify who to contact based on your issue

---

## Key Features Overview

### Before Appointment
- ✓ Create booking requests with complete information
- ✓ 5-stage sequential approval workflow
- ✓ Automatic posting to schedule upon approval
- ✓ Edit capability before RSB approval

### During Trip
- ✓ Trip visibility in Car Booking Schedule
- ✓ Driver and vehicle assignment tracking
- ✓ Mobile-responsive access
- ✓ Real-time status updates

### After Trip
- ✓ Trip completion encoding with all expenses
- ✓ Multi-level verification (RSB2)
- ✓ Requester acknowledgment
- ✓ Automatic cost calculations

### Financial Features
- ✓ Location-based vehicle charges
- ✓ Automatic driver fee calculation
- ✓ Comprehensive expense tracking
- ✓ Financial summaries and reports
- ✓ Export to Excel and PDF

### Administrative Features
- ✓ Full audit trail with timestamps
- ✓ Complete approval history
- ✓ Role-based permissions
- ✓ Comprehensive reporting
- ✓ Mobile accessibility

---

## Support and Contacts

### Contact Matrix
| Issue Type | Primary Contact | Escalation |
|-----------|-----------------|-----------|
| Login Problems | IT Support | - |
| Booking Questions | Your Department Head | Department Head → RSB |
| Rejected Booking | Approver who rejected | Next-level approver |
| Can't Edit | RSB (extended permissions) | RSB Manager |
| Vehicle Not Available | WVB | WVB Manager |
| Cost Questions | RSB2 or Payables | Finance Manager |
| Missing Trip Report | RSB | RSB Manager |
| System Errors | IT Support | IT Manager |
| General Help | Your Manager | Your Manager's Manager |

---

## Document Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-04-29 | Initial comprehensive documentation release |

---

## Glossary of Key Terms

- **Approval Workflow** - Sequential process where multiple roles review and approve booking requests (5 stages)
- **Audit Trail** - Complete record of all system activities including timestamps and user information
- **Booking** - Vehicle reservation request for specific date, time, and location
- **Department Head** - First-level approver verifying business justification
- **Driver Fee** - PHP 600 (half day <8 hrs) or PHP 1,200 (whole day ≥8 hrs)
- **Drop-off Location** - Final destination for the trip
- **NAN** - Final Authorization - stage 5 of approval
- **ODJ** - Operations and Dispatch - stage 4 of approval
- **Pickup Location** - Starting point for the trip
- **Requester** - Employee who creates and initiates the booking
- **RFID Cost** - Electronic toll road charges
- **RSB** - Reservation Service Bureau - stage 2 of approval, also handles trip encoding
- **RSB2** - RSB verification role - verifies trip completion reports
- **Vehicle Charge** - Cost based on destination location (PHP 500-3,500)
- **WVB** - Vehicle and Driver Assignment Bureau - stage 3, assigns vehicle and driver

---

## Quick Links to Sections

### CARBOOKING_SYSTEM_MANUAL.md
- [Introduction](#introduction) - Overview and purpose
- [Getting Started](#getting-started) - Access and login
- [Before Appointment Phase](#before-appointment-phase) - Request creation and approvals
- [Approval Workflow](#approval-workflow) - Detailed 5-stage process
- [After Appointment Phase](#after-appointment-phase) - Trip completion and verification
- [Role-Specific Guides](#role-specific-guides) - By role procedures
- [Financial Information](#financial-and-billing-information) - Costs and billing
- [Best Practices](#best-practices) - Tips and recommendations
- [Troubleshooting](#troubleshooting-and-faqs) - Problem solving
- [Reference](#reference-information) - Quick lookup tables

### ROLE_SPECIFIC_GUIDES.md
- [Requester Guide](#requester-quick-start-guide) - For those creating bookings
- [Department Head](#department-head-approval-guide) - First approvers
- [RSB Guide](#rsb-reservation-service-bureau-operational-guide) - Workflow managers
- [WVB Guide](#wvb-vehicle--driver-assignment-operational-guide) - Vehicle/driver assignment
- [ODJ Guide](#odj-operations--dispatch-operational-guide) - Operations verification
- [NAN Guide](#nan-final-authorization-operational-guide) - Final approvers

### QUICK_REFERENCE_CARDS.md
- [Approval Workflow Chart](#card-1-approval-workflow-at-a-glance) - Visual workflow
- [Billing Lookup](#card-2-location-billing-quick-lookup) - Location pricing
- [Driver Fees](#card-3-driver-fees--trip-duration) - Fee calculation
- [Company Mapping](#card-4-vehicle--driver-company-mapping) - Vehicle and driver assignments
- [Cost Calculator](#card-5-trip-cost-quick-calculator) - Calculate trip costs
- [Timeline](#card-6-approval-timeline-tracker) - Approval schedule
- [Scenarios](#card-7-common-booking-scenarios) - Common examples
- [Troubleshooting](#card-8-troubleshooting-quick-guide) - Problem solving

---

## Total Documentation Package

**Files Included:**
1. CARBOOKING_SYSTEM_MANUAL.md (Main manual)
2. ROLE_SPECIFIC_GUIDES.md (Role guides)
3. QUICK_REFERENCE_CARDS.md (Quick references)
4. DOCUMENTATION_INDEX.md (This file)

**Total Content:** ~105 KB of comprehensive documentation
**Total Sections:** 40+ detailed sections
**Total Reference Tables:** 25+ lookup tables
**Total Examples:** 20+ worked examples

---

## How to Print or Share

### Printing Recommendations
1. **Full Manual**: Print CARBOOKING_SYSTEM_MANUAL.md (60-80 pages)
2. **Role Guide Only**: Print your specific role guide from ROLE_SPECIFIC_GUIDES.md (10-15 pages)
3. **Quick Cards**: Print QUICK_REFERENCE_CARDS.md and laminate for desk reference (5-10 pages)

### Sharing Documentation
- **Email** entire package (all .md files)
- **PDF conversion** available from most text editors
- **Web hosting** on intranet for easy access
- **Print distribution** of role-specific guides

---

## Document Maintenance

This documentation is maintained and updated regularly. For the latest version, always check:
- Document version number on front page
- Last updated date
- Version history section

---

**Car Booking System Documentation Package**
**Version 1.0 | Last Updated: 2026-04-29**
**Comprehensive User Manual and Reference Guides**

