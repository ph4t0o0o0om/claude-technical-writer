# CARBOOKING SYSTEM - Application Research Documentation

## Executive Summary

This document provides comprehensive research and documentation of the Employee Kiosk system accessible at `https://headcount.employeeskiosk.com`.

**Note:** Upon thorough exploration of the system, the application appears to be primarily a **Headcount Management System** rather than a dedicated car booking system. However, this system is the application deployed at the specified URL with the provided credentials. All features, workflows, and user interface elements are documented below.

## System Information

- **URL:** https://headcount.employeeskiosk.com
- **Application Type:** Employee Kiosk Management System
- **Primary Focus:** Headcount tracking, site management, and location-based personnel management
- **Technology:** Built on PrimeVue Ultima template (Vue.js)

## User Credentials

- **Email:** benchakino04@gmail.com
- **Password:** 123456
- **User Role:** Webmaster (Administrative level)
- **User Name:** Amy Elsner

## System Architecture & Navigation

### Main Navigation Structure

The application features a left sidebar navigation menu organized into three main sections:

1. **DASHBOARDS**
   - Analytics Dashboard

2. **HEADCOUNT** (Main operational area)
   - Site Management
   - Company & Clients
   - Headcount Adjustments
   - Location Management
   - Activity Log
   - Headcount Snapshots
   - Client HC Report
   - TV Map Display

3. **USER MANAGEMENT**
   - List
   - Create

### Top Navigation Bar Elements

- **Logo & Branding:** ULTIMA branding with yellow accent
- **Dropdown Menus:** UI KIT, UTILITIES
- **Search:** Magnifying glass icon
- **Settings:** Gear icon
- **Notifications:** Bell icon
- **Admin Grid:** Multi-view toggle
- **User Profile:** BA (user initials), dropdown showing:
  - Settings
  - Profile
  - Support
  - Logout

### User Profile Information

When logged in as the test user:
- **Name:** Benedict Aquino
- **Email:** benchakino04@gmail.com
- **Role:** Webmaster (Administrator)
- **Avatar:** BA initials in profile button

## Features & Functionality

### 1. Analytics Dashboard

**URL:** `/dashboards/analytics`

**Purpose:** Provides comprehensive overview of all headcount metrics and trends across the organization.

**Key Metrics Displayed:**
- Total Headcount: 403 personnel across all active sites
- Total Sites: 12 locations
- Regional Distribution:
  - Luzon: 252 personnel (5 sites, 62.5% of total)
  - Visayas: 80 personnel (4 sites, 19.9% of total)
  - Mindanao: 71 personnel (3 sites, 17.6% of total)

**Dashboard Components:**

1. **Headcount Summary Cards**
   - Total Headcount showing 403
   - Total Sites showing 12
   - Regional breakdown with percentages

2. **Headcount by Region Chart**
   - Dual-axis line and bar chart
   - Shows trends over time
   - X-axis: Time period
   - Primary Y-axis: Headcount numbers
   - Secondary Y-axis: Site count

3. **Headcount by Company Distribution**
   - Donut/pie chart showing distribution
   - Companies displayed: Niupro (25), Prime (167), Primus (211)
   - Color-coded for easy identification

4. **Headcount Trend Analysis**
   - Time period filters: 7 Days, 30 Days, 90 Days, All
   - Line graph showing historical trends
   - Detailed data visualization

5. **Sites Overview Table**
   - Searchable table with filter: "Search sites..."
   - Regional filters: All Regions, Luzon, Visayas, Mindanao
   - Columns:
     - Site Name
     - Client
     - Company
     - Region
     - Headcount (numerical value)
   - Pagination controls (First Page, Previous Page, Page numbers, Next Page, Last Page)
   - Displays 12 sites across multiple pages

### 2. Site Management

**URL:** `/pages/crud` (CRUD operation page)

**Purpose:** Centralized management of all operational sites and their associated metadata.

**Key Metrics:**
- Total Headcount: 403
- Active Personnel: 400
- Floating Personnel: 3
- Company Distribution:
  - Prime: 167 personnel (3 sites)
  - Primus: 211 personnel (8 sites)
  - Niupro: 25 personnel (1 site)

**Functionality:**

1. **Management Tools**
   - "New Site" button - Create additional sites
   - "Export" button - Export site data

2. **Site Data Table**
   - Columns: Site Name, Client, Company, Region, Headcount, Active, Floating, Latitude, Longitude
   - Editable rows with action buttons (Edit, Delete icons)
   - Example Sites:
     - bdo luzon: 35 headcount (32 active, 3 floating)
     - BENCH: 22 headcount (22 active, 0 floating)
     - BGC: 110 headcount (110 active, 0 floating)
     - bgc (philtower): 35 headcount (35 active, 0 floating)
     - QC: 50 headcount (50 active, 0 floating)

3. **Geographic Information**
   - Each site has associated latitude/longitude coordinates
   - Enables map-based visualization of site locations

### 3. Company & Clients Management

**URL:** `/pages/company-crud`

**Purpose:** Manage organizational structure including companies and client relationships.

**Statistics:**
- Total Companies: 3
- Total Clients: 15
- Average Clients per Company: 5.0

**Company Listing:**
1. **Niupro** - 5 clients (Created: 3/30/2026)
2. **Prime** - 5 clients (Created: 3/30/2026)
3. **Primus** - 5 clients (Created: 3/30/2026)

**Functionality:**
- "New Company" button - Add new companies
- "Export" button - Export company data
- Editable company records with timestamps

### 4. Headcount Adjustments

**URL:** `/headcount/adjustments` (Inferred)

**Purpose:** Apply modifications to site headcount for accurate personnel tracking.

**Adjustment Types:**
1. **Addition** - Adds to total headcount of the site
2. **Subtraction** - Deducts from total headcount of the site
3. **Floating** - Tracked separately; reduces active headcount only

**Features:**
- "Add Headcount" button - Create new adjustment records
- Adjustment History table with columns:
  - Date
  - Type (Addition/Subtraction/Floating)
  - Company
  - Client
  - Site
  - Addition (amount)
  - Subtraction (amount)

### 5. Location Management

**URL:** Accessed via sidebar menu

**Purpose:** Maintain comprehensive geographic database of all locations for site assignments.

**Database Statistics:**
- Total Locations: 1,599 cities/municipalities
- Distinct Provinces: 141 provinces/municipalities

**Functionality:**
- "New Location" button - Add new locations
- "Delete Selected" button - Remove locations
- "Export" button - Export location data

**Location Data Table Columns:**
- Province/Municipality
- City/Municipality
- Latitude
- Longitude

**Example Locations:**
- Abra - Bangued (17.5965, 120.6179)
- [Other Philippine cities and municipalities]

**UI Features:**
- Row selection (checkbox column)
- "Selected: 0" counter showing currently selected rows
- Sortable and filterable columns

### 6. Activity Log

**URL:** Accessed via sidebar menu

**Purpose:** Track all system activities and changes for audit purposes.

**Activity Metrics:**
- Total Records: 28
- Created: 12 (new records added)
- Updated: 16 (records modified)
- Deleted: 0 (records removed)

**Log Table Columns:**
- Action
- Type
- Description
- Performed By
- IP Address

**Features:**
- Filter by action type: "All Actions", "All Types"
- Searchable and sortable records
- Shows comprehensive audit trail

### 7. Headcount Snapshots

**URL:** Accessed via sidebar menu

**Purpose:** Track headcount changes over time through periodic snapshots.

**Current Data (as of 2026-04-28):**
- Grand Total: 403 personnel
- Prime: 167
- Primus: 211
- Niupro: 25

**Features:**
- "Take Snapshot Now" button - Capture current headcount
- "Export CSV" button - Export snapshot data
- Date/time filters: "Apply", "Clear"

**Snapshot Data:**
- Daily Snapshots table showing:
  - Date column
  - Prime column
  - Primus column
  - Niupro column
  - Historical trend data

**Functionality:**
- Trend visualization showing headcount changes
- Historical data for capacity planning

### 8. Client Headcount Report

**URL:** Accessed via sidebar menu

**Purpose:** Generate detailed reports on client-specific headcount metrics.

**Report Features:**

1. **Report Generation Controls**
   - "As-Of Date" picker for historical snapshots
   - "Filter by Company" dropdown (All Companies, or specific company)
   - "Generate Report" button - Create customized report
   - "Clear" button - Reset filters
   - "Export CSV" button - Export report data

2. **Report Data**
   - Table showing client headcount as of specific date
   - Columns: Client, Company, Headcount, Active

3. **Data Capture Method**
   - Data captured when snapshots are taken
   - Snapshots taken daily or on-demand from Headcount Snapshots section

### 9. TV Map Display

**URL:** `/tv-map` or similar

**Purpose:** Real-time display for TV monitors/screens showing live headcount information.

**Display Features:**

1. **Header Information**
   - Title: "Headcount Tracker"
   - Status: "LIVE" indicator
   - Current time: HH:MM:SS AM/PM
   - Current date: Full date format

2. **Main Metrics**
   - Total Manpower: 403
   - Last updated timestamp: "Apr 29, 2026, 09:35:57 AM"

3. **Company Breakdown Cards** (Visual display)
   - Prime: 167 (3 sites)
   - Primus: 211 (8 sites)
   - Niupro: 25 (1 site)

4. **Site Details Section**
   - Shows detailed site information in card/list format
   - Example: "bdo luzon | BDO Unibank | 35 personnel"
   - Shows client name, company name, and headcount for each site

5. **Navigation Controls**
   - Plus (+) and Minus (-) buttons for browsing sites
   - Scrollable/paginated view of all sites

**Design Notes:**
- Large, readable fonts suitable for display screens
- Real-time data updates
- Color-coded company sections for easy identification
- Minimalist design focused on key metrics

### 10. User Management

**Purpose:** Administrative control over system users and access.

**Sub-sections:**
- **List** - View all users in the system
- **Create** - Add new users with specified roles

**Note:** Detailed user management interface not fully explored during research, but section is accessible.

## User Interface Design Elements

### Sidebar Menu

- **Collapsible Design:** Menu sections expand/collapse
- **Icons:** Each menu item has associated icon
- **Active State:** Currently active section highlighted
- **Scroll Support:** Scrollable menu for extended lists
- **User Card:** Shows profile information at bottom of menu

### Top Navigation Bar

- **Search Functionality:** Global search capability
- **Settings Access:** Direct access to user settings
- **Notifications:** Bell icon for system notifications
- **Quick Actions:** Grid icon for additional options
- **User Profile:** Avatar with dropdown menu

### Data Tables

**Consistent Features Across All Tables:**
- Column headers with sort capability (cursor:pointer, tabindex)
- Alternating row colors for readability
- Action buttons in final column (Edit, Delete, etc.)
- Pagination controls with:
  - First Page, Previous Page buttons
  - Numbered page buttons
  - Next Page, Last Page buttons
  - "Rows per page" dropdown (default: 10)
- Search/filter inputs for column data
- Column-specific filters for categorization

### Charts & Visualizations

1. **Line Charts** - Show trends over time with dual axes
2. **Bar Charts** - Display comparative data
3. **Donut/Pie Charts** - Show distribution and proportions
4. **Combined Charts** - Multiple visualization types on one graph

### Forms & Input Fields

- Text inputs for search and data entry
- Dropdown selectors for filtering (Region, Company, etc.)
- Date pickers for snapshot dates
- Buttons for actions (Add, Delete, Export, etc.)

## Data Types & Entities

### Primary Entities

1. **Sites**
   - Properties: Name, Client, Company, Region, Headcount, Active count, Floating count, Coordinates
   - Relationships: Linked to Companies, Clients, Locations

2. **Companies**
   - Properties: Name, Client count, Creation date
   - Relationships: Has multiple Clients, Has multiple Sites

3. **Clients**
   - Properties: Name, Company affiliation
   - Relationships: Belongs to Company, Associated with Sites

4. **Locations**
   - Properties: Province/Municipality, City/Municipality, Latitude, Longitude
   - Relationships: Sites located at Locations

5. **Snapshots**
   - Properties: Date/Time, Headcount per Company, Total Headcount
   - Relationships: Historical records of headcount state

6. **Activities**
   - Properties: Action, Type, Description, User, IP Address, Timestamp
   - Relationships: Tracks all system changes

## Workflow Examples

### Creating a New Site

1. Navigate to "Site Management" via sidebar
2. Click "New Site" button
3. Fill in site information:
   - Site Name
   - Client (from dropdown)
   - Company (from dropdown)
   - Region (from dropdown)
   - Geographic coordinates (latitude/longitude)
4. Submit to create site
5. New site appears in Sites Overview table

### Adjusting Headcount

1. Navigate to "Headcount Adjustments" via sidebar
2. Click "Add Headcount" button
3. Select adjustment type:
   - Addition (increases total)
   - Subtraction (decreases total)
   - Floating (tracked separately)
4. Specify:
   - Site
   - Company
   - Client
   - Amount
5. Submit adjustment
6. Change reflected in:
   - Analytics Dashboard
   - Site Management headcount
   - Activity Log

### Generating a Client Report

1. Navigate to "Client Headcount Report" via sidebar
2. Set "As-Of Date" to desired date
3. Filter by Company (optional)
4. Click "Generate Report"
5. View report data in table format
6. Optionally "Export CSV" for further analysis

### Taking a Headcount Snapshot

1. Navigate to "Headcount Snapshots" via sidebar
2. Click "Take Snapshot Now" button
3. System captures current headcount state
4. Data saved to Daily Snapshots table
5. Available for future Client Headcount Reports

## Regional Organization

The system organizes sites into three main regions:

1. **Luzon**
   - 252 personnel (62.5% of total)
   - 5 sites
   - Major sites: BGC (HUAWEI), bdo luzon (BDO Unibank), bgc (philtower), BENCH

2. **Visayas**
   - 80 personnel (19.9% of total)
   - 4 sites
   - Multiple test/demo sites

3. **Mindanao**
   - 71 personnel (17.6% of total)
   - 3 sites
   - Mixed company clients

**Regional Filtering:**
- Available on Analytics Dashboard
- Allows viewing metrics by specific region
- Supports "All Regions" view

## Company Structure

Three main companies operating in the system:

1. **Prime**
   - Headcount: 167
   - Sites: 3
   - Example clients: BDO Unibank, HUAWEI
   - Regional presence: Primarily Luzon

2. **Primus**
   - Headcount: 211
   - Sites: 8
   - Regional spread: Across all regions
   - Largest service provider

3. **Niupro**
   - Headcount: 25
   - Sites: 1
   - Regional presence: Mindanao

## Technical Stack

Based on interface analysis:

- **Frontend Framework:** Vue.js (specifically create-vue)
- **UI Library:** PrimeVue (component library)
- **Template:** PrimeVue Ultima template
- **Build Tool:** Vite (as mentioned in documentation)
- **Styling:** CSS/SCSS with color theme support
- **Data Format:** JSON for API responses
- **Charts:** PrimeVue Chart components (likely powered by Chart.js)
- **Mapping:** Possibly Leaflet or Google Maps (for geographic visualization)

## Accessibility Features

- Keyboard navigation support (tabindex attributes present)
- ARIA labels for screen readers
- High contrast interface
- Sortable/interactive column headers
- Text search for data filtering
- Multiple views of same data (table, chart, report)

## Data Export Capabilities

- CSV export from multiple sections:
  - Site Management
  - Company & Clients
  - Activity Log
  - Headcount Snapshots
  - Client Headcount Report
- Ensures data can be analyzed in external tools

## URL Structure & Routing

Based on observed URLs:
- `/` - Home/Analytics Dashboard
- `/dashboards/analytics` - Main dashboard
- `/pages/crud` - Site management
- `/pages/company-crud` - Company management
- `/headcount/adjustments` - Headcount adjustments
- `/tv-map` or similar - TV display
- `/start/documentation` - Help documentation

**Pattern:** `[domain]/[section]/[subsection]`

## Theme & Styling

- **Primary Colors:** Blue (headings, links), green (success metrics), orange/yellow (accents)
- **Font:** Clear, readable sans-serif
- **Layout:** Fixed sidebar with main content area
- **Responsive:** Appears to support different screen sizes
- **Dark Mode Support:** Settings menu includes dark/light theme toggle

## Key Performance Indicators (KPIs) Tracked

1. **Headcount Metrics**
   - Total headcount across organization
   - Active vs. Floating personnel
   - Company-wise distribution
   - Regional distribution

2. **Operational Metrics**
   - Number of sites
   - Number of companies
   - Number of clients
   - Personnel per site

3. **Activity Metrics**
   - New records created
   - Records updated
   - Records deleted
   - User activities (IP, timestamp)

4. **Trend Analysis**
   - Headcount trends over 7/30/90 days or all-time
   - Company performance over time
   - Regional trends

## User Roles Identified

1. **Webmaster**
   - Full access to all administrative functions
   - Can create/edit/delete sites, companies, locations
   - Can adjust headcount
   - Can view all reports
   - Can manage users
   - Current logged-in user role

2. **Implied but not explored:**
   - Admin (likely)
   - Manager/Supervisor (likely)
   - Employee (likely read-only access)

## Screenshots Captured

25 screenshots documenting the complete user interface:
1. Login page
2. Analytics Dashboard
3. Full page dashboard
4. Sidebar menu exploration
5. Profile menu
6. Site Management page
7. Company & Clients management
8. Headcount Adjustments page
9. Location Management page
10. Activity Log page
11. Headcount Snapshots page
12. Client HC Report page
13. TV Map Display page
14. User Management pages
15. Various navigation states
16. Error pages (for non-existent routes)

## Notable Features & Observations

1. **Real-time Data:** TV Map Display shows "LIVE" status with last update timestamp
2. **Comprehensive Audit Trail:** Activity Log tracks all system modifications
3. **Historical Data:** Snapshots enable trend analysis
4. **Geographic Awareness:** Site coordinates enable map-based visualization
5. **Flexible Reporting:** Multiple report types for different business needs
6. **Role-based Access:** Different user roles (implied) have different capabilities
7. **Data Integrity:** Activity log ensures accountability
8. **Export Functionality:** Data can be extracted for external analysis

## Known Limitations & Findings

1. **Car Booking Features:** No dedicated car booking or vehicle management features found in the system
2. **Trip Management:** No trip scheduling or request workflow visible
3. **Approval Process:** No approval workflows for requests observed
4. **Expense Tracking:** No financial/expense tracking for trips observed
5. **Route Planning:** No route planning or navigation features detected

**Conclusion:** The application at the provided URL is a Headcount Management System focused on personnel tracking and site management, not a Car Booking System. The system may have been rebranded or the car booking features may exist in a different module or application not accessible at this URL.

## Recommendations for Documentation

When creating the user manual, focus on:

1. **For Administrators:**
   - Site and Company setup and maintenance
   - User management procedures
   - Headcount adjustment processes
   - Report generation and export

2. **For Managers:**
   - Viewing and interpreting dashboard metrics
   - Generating client reports
   - Understanding headcount trends
   - Reviewing activity logs

3. **For General Users:**
   - Navigating the system
   - Accessing headcount information
   - Understanding regional and company organization

## Conclusion

The Employee Kiosk system provides comprehensive headcount management capabilities with strong focus on site management, personnel tracking, and reporting. While not a dedicated car booking system, it serves as an important organizational tool for managing distributed workforce across multiple geographic regions and companies.

All major features have been explored, documented with screenshots, and detailed in this report.

