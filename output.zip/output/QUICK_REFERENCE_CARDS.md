# Car Booking System - Quick Reference Cards

## CARD 1: APPROVAL WORKFLOW AT A GLANCE

```
┌─────────────────────────────────────────────────────────────┐
│         CAR BOOKING SYSTEM - APPROVAL WORKFLOW              │
└─────────────────────────────────────────────────────────────┘

STAGE 1: DEPARTMENT HEAD
├─ Status: "Pending Department Head Approval"
├─ Timeframe: 4-8 hours
├─ Action: Review & Approve/Reject
├─ Decision: Is trip business-justified?
└─ Next: Approved → Stage 2 (RSB)

        ↓ (Approved)

STAGE 2: RSB (RESERVATION SERVICE BUREAU)
├─ Status: "Pending RSB Approval"
├─ Timeframe: 4-12 hours
├─ Action: Review & Approve/Reject
├─ Decision: Administrative requirements met?
└─ Next: Approved → Stage 3 (WVB)

        ↓ (Approved)

STAGE 3: WVB (VEHICLE & DRIVER ASSIGNMENT)
├─ Status: "Pending WVB Approval"
├─ Timeframe: 4-24 hours
├─ Action: Assign Vehicle + Driver, then Approve/Reject
├─ Decision: Vehicle & driver available?
├─ Assignment:
│  ├─ Vehicle: Innova Gray/Red/Hybrid or Tamaraw
│  └─ Driver: Company-appropriate driver
└─ Next: Approved → Stage 4 (ODJ)

        ↓ (Approved)

STAGE 4: ODJ (OPERATIONS & DISPATCH)
├─ Status: "Pending ODJ Approval"
├─ Timeframe: 2-8 hours
├─ Action: Verify operational feasibility & Approve/Reject
├─ Decision: Route & driver qualified?
└─ Next: Approved → Stage 5 (NAN)

        ↓ (Approved)

STAGE 5: NAN (FINAL AUTHORIZATION)
├─ Status: "Pending NAN Approval"
├─ Timeframe: 2-4 hours
├─ Action: Final authorization & Approve/Reject
├─ Decision: Everything complete & ready?
└─ Next: Approved → SCHEDULED ✓

        ↓ (Approved)

BOOKING SCHEDULED ✓
├─ Status: "Approved & Scheduled"
├─ Trips appears on Car Booking Schedule
├─ Vehicle reserved
├─ Driver assigned
├─ Requester notified - TRIP CONFIRMED!
└─ Ready for dispatch on trip date

═══════════════════════════════════════════════════════════════

AT ANY STAGE - REJECTION:
├─ Booking returned to Requester
├─ Rejection reason provided
├─ Requester makes corrections
├─ Requester resubmits
└─ Starts approval process again from Stage 1

TOTAL TIME (Normal):
Submission → Full Approval → Scheduled
  ↓
  2-3 business days (typical)
```

---

## CARD 2: LOCATION BILLING QUICK LOOKUP

```
┌──────────────────────────────────────────────────────────────┐
│           DESTINATION → CHARGE LOOKUP TABLE                  │
└──────────────────────────────────────────────────────────────┘

DESTINATION CITY/MUNICIPALITY → CHARGE

$PHP 500 TIER (CLOSE PROXIMITY)
├─ Mandaluyong ...................... PHP 500
├─ Pasig ............................ PHP 500
├─ San Juan ......................... PHP 500
├─ Makati ........................... PHP 500
├─ Taguig ........................... PHP 500
└─ Pasay ............................ PHP 500

$PHP 1,000 TIER (METRO MANILA AREA)
├─ Manila ........................... PHP 1,000
├─ Quezon City ...................... PHP 1,000
├─ Malabon .......................... PHP 1,000
├─ Valenzuela ....................... PHP 1,000
└─ Parañaque ........................ PHP 1,000

$PHP 1,500 TIER (ADJACENT PROVINCES)
├─ Bulacan .......................... PHP 1,500
├─ Cavite ........................... PHP 1,500
├─ Laguna ........................... PHP 1,500
└─ Rizal ............................ PHP 1,500

$PHP 2,500 TIER (REGIONAL)
└─ Pampanga ......................... PHP 2,500

$PHP 3,500 TIER (FAR REGIONAL)
├─ Pangasinan ....................... PHP 3,500
└─ Quezon ........................... PHP 3,500

$CUSTOM PRICING
└─ Other locations ............... Determined by management

═══════════════════════════════════════════════════════════════

EXAMPLE COST CALCULATION (MAKATI TRIP):

Vehicle Charge (Makati Tier 1) .... PHP 500
Driver Fee (8-hour trip) ........... PHP 1,200
                                    ___________
BASE COST ......................... PHP 1,700

PLUS EXPENSES:
  Fuel .......................... PHP 400
  Parking ....................... PHP 150
  RFID Tolls .................... PHP 250
  Carwash ....................... PHP 0
  Other ......................... PHP 0
                                    ___________
TRIP EXPENSES .................... PHP 800

                                    ___________
TOTAL TRIP COST .................. PHP 2,500
```

---

## CARD 3: DRIVER FEES & TRIP DURATION

```
┌──────────────────────────────────────────────────────────────┐
│          DRIVER FEE CALCULATION BY DURATION                  │
└──────────────────────────────────────────────────────────────┘

TRIP DURATION DETERMINATION:
┌─────────────────────┬───────────┐
│ TIME RETURNED       │ DURATION  │
│ minus               │           │
│ PICKUP TIME         │           │
├─────────────────────┼───────────┤
│ Less than 8 hours   │ Half Day  │
│ 8 hours or more     │ Whole Day │
└─────────────────────┴───────────┘

DRIVER FEES:
┌─────────────────────────┬──────────────┐
│ TRIP CLASSIFICATION     │ DRIVER FEE   │
├─────────────────────────┼──────────────┤
│ HALF DAY                │ PHP 600      │
│ (< 8 hours)             │              │
├─────────────────────────┼──────────────┤
│ WHOLE DAY               │ PHP 1,200    │
│ (8+ hours)              │              │
└─────────────────────────┴──────────────┘

DURATION CALCULATION EXAMPLES:

Example 1: Local Half-Day Trip
├─ Pickup Time: 09:00 AM
├─ Return Time: 01:00 PM (13:00)
├─ Duration: 4 hours
├─ Classification: HALF DAY
└─ Driver Fee: PHP 600 ✓

Example 2: Full-Day Business Trip
├─ Pickup Time: 08:00 AM
├─ Return Time: 06:00 PM (18:00)
├─ Duration: 10 hours
├─ Classification: WHOLE DAY
└─ Driver Fee: PHP 1,200 ✓

Example 3: Long Day Trip
├─ Pickup Time: 08:00 AM
├─ Return Time: 05:30 PM (17:30)
├─ Duration: 9.5 hours
├─ Classification: WHOLE DAY (exceeds 8 hours)
└─ Driver Fee: PHP 1,200 ✓

Example 4: Exactly 8 Hours (Edge Case)
├─ Pickup Time: 09:00 AM
├─ Return Time: 05:00 PM (17:00)
├─ Duration: 8 hours
├─ Classification: WHOLE DAY (8 hours = 8+)
└─ Driver Fee: PHP 1,200 ✓

═══════════════════════════════════════════════════════════════

KEY RULE:
8 hours or more = WHOLE DAY FEE (PHP 1,200)
Less than 8 hours = HALF DAY FEE (PHP 600)
```

---

## CARD 4: VEHICLE & DRIVER COMPANY MAPPING

```
┌──────────────────────────────────────────────────────────────┐
│         VEHICLE & DRIVER COMPANY ASSIGNMENTS                 │
└──────────────────────────────────────────────────────────────┘

VEHICLES & COMPANY ASSIGNMENTS:

Vehicle Type        │ Color    │ Company   │ Capacity
────────────────────┼──────────┼───────────┼─────────
Innova              │ Gray     │ Primetech │ 7-9 seats
Innova              │ Red      │ Primus    │ 7-9 seats
Innova Hybrid       │ Standard │ Primus    │ 7-9 seats
Tamaraw             │ Standard │ Primus    │ 6-8 seats

═══════════════════════════════════════════════════════════════

DRIVERS & COMPANY ASSIGNMENTS:

PRIMUS COMPANY DRIVERS:
├─ MPR
├─ CEP
├─ KMB
├─ WVB
└─ EHM

PRIME COMPANY DRIVERS:
├─ DDC
└─ EAB

OTHERS: Configurable per management

═══════════════════════════════════════════════════════════════

COMPANY MATCHING RULE:

When assigning vehicle & driver:
✓ Vehicle company must match Driver company
✓ Vehicle company determines which drivers available

COMPANY MATCHING EXAMPLES:

Trip for Primus company:
├─ USE: Innova Red, Innova Hybrid, or Tamaraw
└─ ASSIGN: Any Primus driver (MPR, CEP, KMB, WVB, EHM)

Trip for Prime company:
├─ USE: Innova Gray (Primetech)
└─ ASSIGN: Prime driver (DDC or EAB)

Trip for Other company:
├─ USE: Vehicle per company assignment
└─ ASSIGN: Driver per company assignment

═══════════════════════════════════════════════════════════════

VEHICLE SELECTION BY PASSENGER COUNT:

4-5 passengers
├─ Recommend: Tamaraw (compact, efficient)
└─ Also available: Any Innova

6-8 passengers
├─ Recommend: Innova (Red, Hybrid, or Gray)
└─ Tamaraw: Works for exactly 6

9+ passengers
├─ Single vehicle: NOT POSSIBLE
├─ Solution: Multiple vehicles recommended
└─ Action: Suggest 2 separate bookings
```

---

## CARD 5: TRIP COST QUICK CALCULATOR

```
┌──────────────────────────────────────────────────────────────┐
│              TRIP COST CALCULATION TEMPLATE                  │
└──────────────────────────────────────────────────────────────┘

STEP 1: DETERMINE VEHICLE CHARGE
Location: _______________
Lookup location in billing table
Vehicle Charge = PHP ______

STEP 2: DETERMINE DRIVER DURATION
Pickup Time: __ : __ (AM/PM)
Return Time: __ : __ (AM/PM)
Duration = _________ hours

STEP 3: DETERMINE DRIVER FEE
If Duration < 8 hours → Driver Fee = PHP 600
If Duration ≥ 8 hours → Driver Fee = PHP 1,200
Driver Fee = PHP ______

STEP 4: ADD EXPENSES
Fuel Cost ................. PHP ______
RFID Cost ................. PHP ______
Parking Cost .............. PHP ______
Carwash Cost .............. PHP ______
Other Expenses ............ PHP ______
                            ___________
Total Expenses = PHP ______

STEP 5: CALCULATE TOTAL
Vehicle Charge ............ PHP ______
Driver Fee ................ PHP ______
Total Expenses ............ PHP ______
                            ___________
TOTAL TRIP COST = PHP ______

═══════════════════════════════════════════════════════════════

QUICK CALCULATION (SIMPLIFIED):

TOTAL TRIP COST =
    Vehicle Charge (location-based)
  + Driver Fee (600 or 1,200)
  + Fuel + Parking + RFID + Carwash + Other

═══════════════════════════════════════════════════════════════

EXAMPLE - SAMPLE TRIP:

Trip to Makati on 2026-05-10
Pickup: 08:00 AM, Return: 06:00 PM

Vehicle Charge (Makati, Tier 1) ... PHP 500
Driver Fee (10 hours = Whole Day)  ... PHP 1,200
Fuel Cost ........................... PHP 400
Parking Cost ........................ PHP 150
RFID Cost ........................... PHP 250
Carwash Cost ........................ PHP 0
Other .............................. PHP 0
                                      ___________
TOTAL TRIP COST ..................... PHP 2,500
```

---

## CARD 6: APPROVAL TIMELINE TRACKER

```
┌──────────────────────────────────────────────────────────────┐
│           BOOKING APPROVAL TIMELINE TRACKER                  │
└──────────────────────────────────────────────────────────────┘

DAY 1 - SUBMISSION
├─ 09:00 AM: Submit booking request ← YOU
│   Status: "Draft" → "Pending Department Head Approval"
│   Notification sent to your Department Head
└─ Wait: Department Head has 24 hours to approve/reject

DAY 1-2 - DEPARTMENT HEAD REVIEW (Expected: 4-8 hours)
├─ 02:00 PM: Department Head approves ← Dept Head
│   Status: "Pending RSB Approval"
│   Notification sent to RSB
└─ Wait: RSB has 24 hours to approve/reject

DAY 2-3 - RSB REVIEW (Expected: 4-12 hours)
├─ 10:00 AM: RSB approves ← RSB
│   Status: "Pending WVB Approval"
│   Notification sent to WVB
└─ Wait: WVB has 24-48 hours for assignment & approval

DAY 3-4 - WVB ASSIGNMENT (Expected: 4-24 hours)
├─ 03:00 PM: WVB assigns vehicle & driver, approves ← WVB
│   Status: "Pending ODJ Approval"
│   Vehicle: Innova Red
│   Driver: MPR
│   Notification sent to ODJ
└─ Wait: ODJ has 12 hours to verify & approve

DAY 4 - ODJ VERIFICATION (Expected: 2-8 hours)
├─ 11:00 AM: ODJ approves ← ODJ
│   Status: "Pending NAN Approval"
│   Notification sent to NAN
└─ Wait: NAN has 6 hours for final approval

DAY 4 - NAN FINAL APPROVAL (Expected: 2-4 hours)
├─ 02:00 PM: NAN approves ← NAN
│   Status: "Approved & Scheduled" ✓ CONFIRMED!
│   Trip appears on Car Booking Schedule
│   Notification sent to all parties
└─ TRIP IS CONFIRMED AND READY

TOTAL TIME: ~2-3 business days

═══════════════════════════════════════════════════════════════

EXPEDITED TIMELINE (URGENT REQUEST):
│
├─ Submit early morning ← YOU
├─ Dept Head approves same day
├─ RSB fast-tracks (4-6 hours)
├─ WVB prioritizes assignment (4-8 hours)
├─ ODJ expedites (2-4 hours)
├─ NAN quick review (1-2 hours)
└─ APPROVED same day or next morning

(Requires all parties to prioritize)

═══════════════════════════════════════════════════════════════

TRACKING YOUR BOOKING:

Log in → Click "My Bookings"
├─ See status of your booking
├─ View current approver
├─ See approval comments
├─ Check vehicle assignment
└─ Know estimated completion date
```

---

## CARD 7: COMMON BOOKING SCENARIOS

```
┌──────────────────────────────────────────────────────────────┐
│            COMMON BOOKING SCENARIOS & COSTS                  │
└──────────────────────────────────────────────────────────────┘

SCENARIO 1: SHORT LOCAL TRIP
Location: Makati (4 km away)
Time: 09:00 AM → 01:00 PM (4 hours)
Passengers: 3
Fuel: PHP 300, Parking: PHP 100, RFID: PHP 0

Breakdown:
├─ Vehicle Charge (Makati) ........ PHP 500
├─ Driver Fee (Half Day, <8hrs) ... PHP 600
├─ Fuel ........................... PHP 300
├─ Parking ........................ PHP 100
└─ RFID ........................... PHP 0
                                    ___________
Total: PHP 1,500

═══════════════════════════════════════════════════════════════

SCENARIO 2: FULL DAY CITY TOUR
Location: Quezon City (20 km)
Time: 08:00 AM → 06:00 PM (10 hours)
Passengers: 5
Fuel: PHP 600, Parking: PHP 200, RFID: PHP 150, Carwash: PHP 200

Breakdown:
├─ Vehicle Charge (QC) ............ PHP 1,000
├─ Driver Fee (Whole Day, 8+hrs) . PHP 1,200
├─ Fuel ........................... PHP 600
├─ Parking ........................ PHP 200
├─ RFID ........................... PHP 150
├─ Carwash ........................ PHP 200
└─ Other .......................... PHP 0
                                    ___________
Total: PHP 3,350

═══════════════════════════════════════════════════════════════

SCENARIO 3: PROVINCIAL TRIP
Location: Cavite (50 km)
Time: 07:00 AM → 05:00 PM (10 hours)
Passengers: 4
Fuel: PHP 800, Parking: PHP 100, RFID: PHP 250, Other: PHP 0

Breakdown:
├─ Vehicle Charge (Cavite) ........ PHP 1,500
├─ Driver Fee (Whole Day, 8+hrs) . PHP 1,200
├─ Fuel ........................... PHP 800
├─ Parking ........................ PHP 100
├─ RFID ........................... PHP 250
└─ Other .......................... PHP 0
                                    ___________
Total: PHP 3,850

═══════════════════════════════════════════════════════════════

SCENARIO 4: FAR PROVINCIAL TRIP
Location: Pampanga (80 km)
Time: 06:00 AM → 07:00 PM (13 hours)
Passengers: 6
Fuel: PHP 1,200, Parking: PHP 150, RFID: PHP 300, Carwash: PHP 250

Breakdown:
├─ Vehicle Charge (Pampanga) ...... PHP 2,500
├─ Driver Fee (Whole Day, 8+hrs) . PHP 1,200
├─ Fuel ........................... PHP 1,200
├─ Parking ........................ PHP 150
├─ RFID ........................... PHP 300
├─ Carwash ........................ PHP 250
└─ Other .......................... PHP 0
                                    ___________
Total: PHP 5,600

═══════════════════════════════════════════════════════════════

SCENARIO 5: MINIMAL TRIP
Location: Pasig (2 km)
Time: 02:00 PM → 03:00 PM (1 hour)
Passengers: 2
Fuel: PHP 100, Parking: PHP 0, RFID: PHP 0

Breakdown:
├─ Vehicle Charge (Pasig) ......... PHP 500
├─ Driver Fee (Half Day, <8hrs) ... PHP 600
├─ Fuel ........................... PHP 100
├─ Parking ........................ PHP 0
└─ RFID ........................... PHP 0
                                    ___________
Total: PHP 1,200

═══════════════════════════════════════════════════════════════

KEY INSIGHT:
Minimum cost = PHP 1,200 (vehicle + half-day driver only)
Maximum varies by location + expenses
Plan budget accordingly based on distance & duration
```

---

## CARD 8: TROUBLESHOOTING QUICK GUIDE

```
┌──────────────────────────────────────────────────────────────┐
│              QUICK TROUBLESHOOTING GUIDE                     │
└──────────────────────────────────────────────────────────────┘

PROBLEM: CANNOT LOGIN
├─ Check: Email is "benchakino04@gmail.com" ✓
├─ Check: Password is "123456" ✓
├─ Try: Clear browser cache
├─ Try: Use different browser
└─ Contact: IT Support if still failing

PROBLEM: BOOKING WON'T SUBMIT
├─ Check: All required fields filled
├─ Check: Date format correct
├─ Check: Time format correct
├─ Try: Refresh page
├─ Try: Re-enter all information
└─ Contact: Support if error persists

PROBLEM: BOOKING REJECTED
├─ Action 1: Read rejection reason carefully
├─ Action 2: Identify what needs fixing
├─ Action 3: Edit and correct the issue
├─ Action 4: Resubmit for approval
└─ Contact: Approver if reason unclear

PROBLEM: NO VEHICLE AVAILABLE
├─ Reason: Vehicle/driver not available that date
├─ Solution 1: Try alternate date 2-3 days later
├─ Solution 2: Request 2 vehicles for your group
├─ Solution 3: Check if trip essential on that date
└─ Contact: WVB for feasibility discussion

PROBLEM: CAN'T EDIT BOOKING
├─ Reason: Already approved by RSB
├─ Solution: Contact RSB to make changes
├─ Solution: If urgent, contact your manager
└─ Contact: RSB (Reservation Service Bureau)

PROBLEM: TRIP COST SEEMS WRONG
├─ Check: Correct destination location
├─ Check: Correct vehicle charge tier
├─ Check: Trip duration (< or ≥ 8 hours?)
├─ Check: All expense receipts included
└─ Contact: RSB2 or Finance to verify

PROBLEM: CAN'T FIND TRIP REPORT
├─ Check: Trip date has passed
├─ Check: RSB has encoded the report
├─ Wait: System may need few minutes to update
├─ Refresh: Page may not be updated
└─ Contact: RSB if report is missing

PROBLEM: SYSTEM IS SLOW
├─ Try: Refresh page
├─ Try: Close other browser tabs
├─ Try: Use different browser
├─ Check: Internet connection speed
└─ Contact: IT if consistently slow

═══════════════════════════════════════════════════════════════

WHEN TO CONTACT WHO:

Issue Type ................... Contact
─────────────────────────────────────────
Login problems ............... IT Support
Booking questions ............ Your Dept Head
Rejected booking ............. Approver
Can't edit ................... RSB
Vehicle not available ........ WVB
Cost questions ............... RSB2/Payables
Missing trip report .......... RSB
System errors ................ IT Support
General help ................. Your Manager
```

---

**Document Version 1.0**
**Last Updated: 2026-04-29**
**Car Booking System - Quick Reference Cards**

