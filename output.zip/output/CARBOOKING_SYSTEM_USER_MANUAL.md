# Employee Kiosk System - Comprehensive User Manual

## Version Information

- **Document Version:** 1.0
- **Last Updated:** 2026-04-29
- **System Version:** Employee Kiosk Headcount Management System
- **Application URL:** https://headcount.employeeskiosk.com

---

## Table of Contents

1. [Introduction and System Overview](#introduction-and-system-overview)
2. [Getting Started](#getting-started)
3. [Dashboard Overview](#dashboard-overview)
4. [Site Management](#site-management)
5. [Company and Client Management](#company-and-client-management)
6. [Headcount Management](#headcount-management)
7. [Location Management](#location-management)
8. [Reports and Analytics](#reports-and-analytics)
9. [Activity and Auditing](#activity-and-auditing)
10. [User Management](#user-management)
11. [Customization and Settings](#customization-and-settings)
12. [Troubleshooting and FAQs](#troubleshooting-and-faqs)
13. [Best Practices](#best-practices)
14. [Glossary](#glossary)

---

## Introduction and System Overview

### What is the Employee Kiosk System?

The Employee Kiosk System is a comprehensive web-based application designed to manage and track personnel headcount across distributed geographic locations within an organization. The system enables organizations to:

- Track total personnel headcount across multiple sites
- Manage organizational structure including companies and client relationships
- Monitor active and floating personnel assignments
- Generate detailed headcount reports and analytics
- Maintain an audit trail of all system changes
- Display real-time headcount information across multiple channels

### Key Benefits

**Operational Efficiency**
- Centralized management of all site and personnel data
- Automated headcount tracking and snapshots
- Streamlined reporting processes

**Data Transparency**
- Real-time visibility into personnel distribution
- Historical trend analysis
- Comprehensive activity logs

**Organizational Insight**
- Regional and company-level metrics
- Client-specific reporting
- Interactive dashboards with visual analytics

### Who Should Use This System?

- **System Administrators:** Manage all system operations, users, and configurations
- **Site Managers:** Oversee site-specific headcount and personnel assignments
- **Company Managers:** Monitor personnel across multiple sites for their company
- **Executive Management:** View high-level metrics and trends
- **Finance/HR Personnel:** Generate reports and analyze headcount data

### System Features at a Glance

- Real-time analytics dashboard with key metrics
- Site management with geographic coordinates
- Company and client relationship management
- Flexible headcount adjustment capabilities
- Comprehensive location database (1,599+ Philippine locations)
- Historical snapshot and trend tracking
- Client-specific headcount reporting
- TV display mode for real-time monitoring
- Complete activity audit trail
- Data export to CSV format
- Customizable user interface with themes

---

## Getting Started

### Accessing the System

#### Step 1: Open Your Web Browser

Open your preferred web browser (Chrome, Firefox, Safari, or Edge).

#### Step 2: Navigate to the Application

Enter the following URL in your browser's address bar:

```
https://headcount.employeeskiosk.com
```

#### Step 3: Login Page

You will be presented with the login page. The page displays:
- "Welcome back!" greeting
- Email input field
- Password input field
- LOGIN button
- "FORGOT PASSWORD?" link for password recovery

**Screenshot Reference:** See Login Interface (Figure 1.1)

#### Step 4: Enter Your Credentials

1. Click the email input field
2. Type your email address (e.g., benchakino04@gmail.com)
3. Click the password input field
4. Type your password (e.g., 123456)
5. Click the LOGIN button

#### Step 5: Authentication

The system will validate your credentials. Upon successful authentication, you will be directed to the Analytics Dashboard.

### First-Time User Setup

#### Understanding Your Role

When you first log in, your user role determines what features you can access. The system supports multiple roles:

- **Webmaster/Administrator:** Full access to all system features
- **Manager:** Access to view and report on assigned areas
- **Employee:** Read-only access to relevant information

Contact your system administrator if you believe you have the wrong access level.

#### Changing Your Password

For security purposes, it is recommended to change your password on first login:

1. Click your user profile icon (initials) in the top-right corner
2. Select "Settings" from the dropdown menu
3. Look for password change option
4. Follow the prompts to set a new password

#### Customizing Your View

You can customize how the system displays information:

1. Click the Settings (gear) icon in the top navigation bar
2. Choose from available options:
   - **Theme:** Select from 20+ color themes (emerald, green, blue, etc.)
   - **Layout:** Choose sidebar layout (Static, Overlay, Slim, etc.)
   - **Dark/Light Mode:** Toggle between light and dark themes

---

## Dashboard Overview

### Accessing the Dashboard

The Dashboard is the main landing page when you log in. To navigate to the Dashboard from anywhere in the system:

1. Click the "Home" or dashboard icon in the sidebar menu
2. Or select "DASHBOARDS > Analytics Dashboard" from the sidebar

### Dashboard Layout

**Screenshot Reference:** See Analytics Dashboard (Figure 2.1 and Figure 2.2)

The dashboard consists of several key sections:

#### Key Metrics Cards

At the top of the dashboard, you'll see summary cards displaying:

**Total Headcount**
- Shows total personnel across all sites
- Example: 403 personnel
- Includes both active and floating personnel

**Total Sites**
- Number of operational locations
- Example: 12 sites

**Regional Distribution**
- Breakdown by geographic region
- Displays headcount and percentage for each region
- Example regions: Luzon, Visayas, Mindanao

### Interpreting Dashboard Charts

#### Headcount by Region Chart

This dual-axis chart shows:
- **Primary Axis (Left):** Headcount numbers
- **Secondary Axis (Right):** Number of sites
- **X-Axis:** Time periods or regions
- **Visual Style:** Combined line and bar chart

**How to Read:**
- Identify the region of interest on the X-axis
- Read the headcount value from the left axis using the line
- Read the site count from the right axis using the bars

#### Headcount by Company Distribution

This donut or pie chart displays:
- Percentage distribution across companies
- Color-coded segments for each company
- Total headcount for each company
- Example: Prime (167), Primus (211), Niupro (25)

**How to Read:**
- Each segment represents one company
- Segment size indicates relative headcount
- Hover over segments to see exact numbers

### Headcount Trend Analysis

#### Time Period Filters

The dashboard includes filters to view trends over different time periods:

- **7 Days:** Last 7 days of headcount changes
- **30 Days:** Last 30 days of data
- **90 Days:** Last quarter of data
- **All:** Complete historical data

**How to Use:**
1. Click the desired time period button (7 Days, 30 Days, etc.)
2. The chart updates to show data for that period
3. The trend line shows headcount movements over time

### Sites Overview Table

The dashboard includes a searchable table displaying all sites.

**Table Columns:**
- **Site Name:** Name of the location
- **Client:** Client organization served at that site
- **Company:** Company managing the site
- **Region:** Geographic region (Luzon, Visayas, Mindanao)
- **Headcount:** Total personnel at the site

**Using the Sites Overview:**

1. **Search:** Use the search box to find specific sites by name
2. **Filter by Region:** Use the region dropdown to filter results
3. **Sort:** Click column headers to sort by that column
4. **Pagination:** Use page controls to navigate between pages
5. **Rows Per Page:** Change how many rows display on each page

---

## Site Management

### What is Site Management?

Site Management is where you view, create, edit, and delete all operational site locations. Each site represents a physical location where personnel are assigned.

### Accessing Site Management

1. In the sidebar menu, locate "HEADCOUNT"
2. Click "HEADCOUNT" to expand the submenu
3. Click "Site Management"

You will see the Site Management page with metrics and the sites table.

**Screenshot Reference:** See Site Management Interface (Figure 3.1)

### Site Management Overview

At the top of the Site Management page, you see key metrics:

**Total Headcount:** 403
- Active: 400 (personnel actively assigned)
- Floating: 3 (personnel temporarily unassigned)

**Company Distribution:**
- Prime: 167 personnel (3 sites)
- Primus: 211 personnel (8 sites)
- Niupro: 25 personnel (1 site)

### Viewing Sites

#### Sites Table

The main table displays all sites with the following columns:

| Column | Description |
|--------|-------------|
| Site Name | Name of the location |
| Client | Client organization at this site |
| Company | Company managing this site |
| Region | Geographic region (Luzon, Visayas, Mindanao) |
| Headcount | Total personnel at site |
| Active | Number of actively assigned personnel |
| Floating | Number of temporarily assigned personnel |
| Latitude | Geographic coordinate (North-South position) |
| Longitude | Geographic coordinate (East-West position) |

**Example Sites:**
- bdo luzon: 35 headcount (32 active, 3 floating)
- BENCH: 22 headcount (22 active, 0 floating)
- BGC: 110 headcount (110 active, 0 floating)

#### Searching Sites

1. Locate the search box labeled "Search sites..."
2. Type the site name or keywords
3. The table filters to show matching results
4. Clear the search box to reset and view all sites

#### Filtering and Sorting

1. **Filter by Region:** Use the region dropdown to show only sites in specific regions
2. **Sort:** Click any column header to sort by that column
3. **Multiple Sorts:** Click again to reverse sort direction

### Adding a New Site

To create a new site location:

1. Click the "New Site" button (usually at the top-right of the page)
2. A form appears with the following fields:

   **Required Information:**
   - **Site Name:** Unique name for the location
   - **Client:** Select from available clients
   - **Company:** Select managing company
   - **Region:** Choose geographic region

   **Geographic Data:**
   - **Latitude:** North-South coordinate (e.g., 14.5564)
   - **Longitude:** East-West coordinate (e.g., 121.0177)

3. Fill in all required fields
4. Click "Save" or "Create" button
5. The new site appears in the sites table

### Editing a Site

To modify existing site information:

1. Locate the site in the sites table
2. Click the "Edit" button/icon in the Actions column
3. The site details form opens for editing
4. Modify the desired fields
5. Click "Save" or "Update" button
6. Changes are reflected immediately in the table

### Deleting a Site

To remove a site from the system:

1. Locate the site in the sites table
2. Click the "Delete" button/icon in the Actions column
3. A confirmation dialog may appear asking to confirm deletion
4. Click "Confirm" or "Yes" to remove the site
5. The site is removed from the table

**Important:** Deleting a site will remove all associated data. Ensure this is intentional before confirming deletion.

### Exporting Site Data

To export all site information to a CSV file:

1. Click the "Export" button on the Site Management page
2. A CSV file is generated and downloaded to your computer
3. The file can be opened in Excel or other spreadsheet applications
4. Use this for external analysis, reporting, or backup

### Understanding Geographic Coordinates

Each site is assigned latitude and longitude coordinates for geographic identification:

**Latitude:** Measures position North or South of the equator
- Positive values = North
- Negative values = South
- Example: 14.5564 degrees North

**Longitude:** Measures position East or West of the Prime Meridian
- Positive values = East
- Negative values = West
- Example: 121.0177 degrees East

These coordinates enable map-based visualization of your site network.

---

## Company and Client Management

### Understanding the Organizational Structure

The system organizes personnel into a hierarchical structure:

**Companies** (top level) → **Clients** (middle level) → **Sites** (operational level)

- **Companies:** Operating organizations (e.g., Prime, Primus, Niupro)
- **Clients:** Organizations served by companies (e.g., BDO Unibank, HUAWEI)
- **Sites:** Physical locations where services are delivered

### Accessing Company and Client Management

1. In the sidebar menu, click "HEADCOUNT"
2. Click "Company & Clients"

You will see the Company and Client Management page.

**Screenshot Reference:** See Company & Client Management Interface (Figure 4.1)

### Company and Client Overview

At the top of the page, you see summary metrics:

**Total Companies:** 3
- Niupro
- Prime
- Primus

**Total Clients:** 15
- Distributed across the three companies

**Average Clients per Company:** 5.0

### Managing Companies

#### Viewing Companies

The main table displays all companies with columns:

| Column | Description |
|--------|-------------|
| Company Name | Name of the operating company |
| Clients | Number of clients served |
| Created | Date the company was created |
| Actions | Edit/Delete buttons |

**Example Companies:**
- Niupro: 5 clients (Created 3/30/2026)
- Prime: 5 clients (Created 3/30/2026)
- Primus: 5 clients (Created 3/30/2026)

#### Adding a New Company

1. Click the "New Company" button
2. Enter the following information:
   - **Company Name:** Unique identifier for the company
   - **Description:** Optional details about the company
3. Click "Save" or "Create"
4. The company appears in the companies table

#### Editing Company Information

1. Find the company in the table
2. Click the "Edit" button in the Actions column
3. Modify the company details
4. Click "Save" or "Update"

#### Deleting a Company

1. Find the company in the table
2. Click the "Delete" button in the Actions column
3. Confirm the deletion in the dialog
4. The company is removed from the system

**Note:** You can only delete a company if it has no associated clients or sites.

### Managing Clients

#### Viewing Clients

Switch to the "Clients" tab to view all clients. The table displays:

| Column | Description |
|--------|-------------|
| Client Name | Name of the client organization |
| Company | Company managing this client |
| Sites | Number of sites serving this client |
| Actions | Edit/Delete buttons |

#### Adding a New Client

1. Click the "New Client" button
2. Fill in the client information:
   - **Client Name:** Organization name
   - **Company:** Select the managing company
   - **Contact Information:** Optional details
3. Click "Save" or "Create"
4. The client is added to the clients list

#### Editing Client Information

1. Find the client in the table
2. Click "Edit"
3. Modify the details
4. Click "Save" or "Update"

#### Deleting a Client

1. Find the client in the table
2. Click "Delete"
3. Confirm the deletion
4. The client is removed

### Exporting Company and Client Data

1. Click the "Export" button on the Company & Clients page
2. A CSV file downloads containing all company and client information
3. Use for external analysis or backup

### Company Structure Example

**Company: Primus**
- Manages 8 sites
- Serves 5 clients:
  - BDO Unibank
  - HUAWEI
  - Fiberhome
  - RCT
  - Philtower

---

## Headcount Management

### Understanding Headcount Types

The system tracks personnel in two categories:

**Active Headcount**
- Personnel actively assigned to a site
- Full responsibility and accountability
- Counted toward total operational capacity

**Floating Headcount**
- Personnel temporarily unassigned or in transition
- Tracked separately from active headcount
- Available for deployment to sites as needed

### Accessing Headcount Adjustments

1. Click "HEADCOUNT" in the sidebar
2. Select "Headcount Adjustments"

You will see the Headcount Adjustments interface.

**Screenshot Reference:** See Headcount Adjustments Interface (Figure 5.1)

### Headcount Adjustment Types

The system supports three types of headcount adjustments:

#### 1. Addition

**Purpose:** Increase total headcount of a site

**When to Use:**
- New personnel assigned to a site
- Personnel transferred to a site
- Increase in staffing levels

**Effect:**
- Increases total site headcount
- Increases active count (unless marked floating)
- Recorded in adjustment history with timestamp

#### 2. Subtraction

**Purpose:** Decrease total headcount of a site

**When to Use:**
- Personnel leaving the organization
- Transfer out of a site
- Reduction in staffing levels

**Effect:**
- Decreases total site headcount
- Decreases active count
- Recorded in adjustment history with timestamp

#### 3. Floating

**Purpose:** Track personnel temporarily unassigned

**When to Use:**
- Personnel in transition between sites
- Temporary deployment
- Personnel on leave or standby

**Effect:**
- Reduces active headcount at site
- Increases floating count
- Maintains total headcount count
- Tracked separately for planning purposes

### Making a Headcount Adjustment

Step-by-step process:

1. Click the "Add Headcount" button
2. A form appears with the following fields:

   **Adjustment Details:**
   - **Type:** Select Addition, Subtraction, or Floating
   - **Company:** Select the company
   - **Client:** Select the client organization
   - **Site:** Select the site

   **Change Information:**
   - **Amount:** Number of personnel affected
   - **Date:** When the adjustment occurs
   - **Notes:** Optional explanation

3. Fill in all required fields
4. Click "Submit" or "Save"
5. The adjustment appears in the Adjustment History

### Viewing Adjustment History

The Adjustment History table shows all headcount changes with columns:

| Column | Description |
|--------|-------------|
| Date | When adjustment was made |
| Type | Addition, Subtraction, or Floating |
| Company | Company affected |
| Client | Client affected |
| Site | Site affected |
| Addition | Number added (if applicable) |
| Subtraction | Number subtracted (if applicable) |

### Impact on Dashboard Metrics

When you make a headcount adjustment:

1. **Immediately Updates:**
   - Site total in Site Management
   - Active/Floating counts
   - Company totals in dashboard

2. **Recorded In:**
   - Activity Log (audit trail)
   - Adjustment History
   - Snapshots (for trend analysis)

3. **Visible In:**
   - Analytics Dashboard metrics
   - All reports
   - Trend charts

---

## Location Management

### Understanding the Location Database

The system maintains a comprehensive database of geographic locations for:
- Site creation and assignment
- Address validation and standardization
- Geographic coordinate reference
- Regional organization

### Accessing Location Management

1. Click "HEADCOUNT" in the sidebar
2. Select "Location Management"

**Screenshot Reference:** See Location Management Interface (Figure 6.1)

### Location Database Overview

**Total Locations:** 1,599 cities and municipalities

**Distinct Provinces/Municipalities:** 141

**Geographic Coverage:** Complete Philippines location database

### Location Data Structure

Each location in the database contains:

| Field | Description | Example |
|-------|-------------|---------|
| Province/Municipality | Regional division | Abra |
| City/Municipality | Specific city or municipality | Bangued |
| Latitude | North-South coordinate | 17.5965 |
| Longitude | East-West coordinate | 120.6179 |

### Searching for Locations

#### Method 1: Using Search Box

1. Locate the search field at the top of the Locations table
2. Type location name (city, municipality, or province)
3. Table filters to show matching results
4. Results display matching locations with coordinates

**Examples:**
- Searching "Manila" shows all Manila-related locations
- Searching "Quezon" shows Quezon City and Quezon Province locations

#### Method 2: Browsing by Region

1. Use the region filter dropdown if available
2. Select a province or region
3. Table displays all cities/municipalities in that region
4. Scroll through results

### Viewing Location Details

When you find a location, you can see:

1. **Province/Municipality Name**
   - Regional classification
   - Used for organizational purposes

2. **City/Municipality Name**
   - Specific location identifier
   - Used for site assignment

3. **Geographic Coordinates**
   - Latitude: North-South position
   - Longitude: East-West position
   - Used for mapping and geographic calculations

### Adding a New Location

If a location is not in the database:

1. Click "New Location" button
2. Fill in the following information:
   - **Province/Municipality:** Regional classification
   - **City/Municipality:** Specific location name
   - **Latitude:** Geographic coordinate
   - **Longitude:** Geographic coordinate

3. Click "Save" or "Create"
4. New location is added to the database

**Note:** Coordinates can be found using Google Maps or GPS technology.

### Deleting Locations

To remove locations from the database:

1. **Single Delete:** Find location, click "Delete" button, confirm
2. **Bulk Delete:**
   - Check the checkbox beside locations to delete
   - Click "Delete Selected" button
   - Confirm deletion of all selected locations

**Caution:** Only delete locations not currently assigned to any sites.

### Exporting Location Data

1. Click "Export" button
2. CSV file downloads containing all location information
3. Use for external mapping applications or data analysis

### Using Coordinates for Mapping

The geographic coordinates (latitude/longitude) stored in the system enable:

1. **Map-Based Visualization** - Display sites on interactive maps
2. **Distance Calculations** - Calculate distances between locations
3. **Geographic Clustering** - Group nearby sites
4. **Route Planning** - Plan efficient routes for operations

---

## Reports and Analytics

### Understanding Report Types

The Employee Kiosk System provides several types of reports:

1. **Analytics Dashboard** - Real-time visual metrics
2. **Headcount Snapshots** - Historical snapshots over time
3. **Client Headcount Reports** - Client-specific data
4. **TV Map Display** - Real-time monitoring display
5. **Activity Reports** - Change tracking and audit trails

### Analytics Dashboard Reports

The dashboard provides real-time analytics including:

- Total headcount across organization
- Regional distribution metrics
- Company-level comparisons
- Historical trend analysis
- Sites overview

For detailed information, see [Dashboard Overview](#dashboard-overview) section.

### Headcount Snapshots

#### Purpose

Snapshots capture the state of headcount at a specific point in time, enabling:
- Trend analysis over time
- Comparison of staffing levels
- Historical record keeping
- Reporting for specific dates

#### Accessing Headcount Snapshots

1. Click "HEADCOUNT" in the sidebar
2. Select "Headcount Snapshots"

**Screenshot Reference:** See Headcount Snapshots Interface (Figure 7.1)

#### Snapshot Overview

The Headcount Snapshots page displays:

**Current Metrics (as of latest snapshot):**
- **Grand Total:** Total headcount (example: 403)
- **Company Breakdown:**
  - Prime: 167
  - Primus: 211
  - Niupro: 25

#### Viewing Snapshots

The **Daily Snapshots** table shows:

| Column | Description |
|--------|-------------|
| Date | Snapshot date |
| Prime | Prime company headcount on that date |
| Primus | Primus company headcount on that date |
| Niupro | Niupro company headcount on that date |

**Example Data:**
- 2026-04-28: Prime 167, Primus 211, Niupro 25
- 2026-04-27: Previous day's snapshot
- Historical data for trend analysis

#### Taking a Manual Snapshot

To capture the current headcount state:

1. Click "Take Snapshot Now" button
2. System immediately captures current headcount
3. Data saved with current timestamp
4. Appears in Daily Snapshots table

**Note:** System also takes automatic snapshots daily.

#### Filtering Snapshots by Date

1. Use the date range filters at the top of the Headcount Trend section
2. Click "Apply" to filter data
3. Table updates to show snapshots for selected date range
4. Click "Clear" to reset and view all snapshots

#### Analyzing Trends

1. View the Headcount Trend chart
2. Select time period: 7 Days, 30 Days, 90 Days, All
3. Chart displays headcount movement over selected period
4. Identify trends:
   - Increasing headcount (upward trend)
   - Decreasing headcount (downward trend)
   - Stable headcount (flat line)

#### Exporting Snapshot Data

1. Click "Export CSV" button
2. CSV file downloads with snapshot history
3. Open in Excel for further analysis
4. Create custom charts and reports

### Client Headcount Report

#### Purpose

Generate detailed reports on headcount for specific clients on specific dates.

#### Accessing Client Headcount Report

1. Click "HEADCOUNT" in the sidebar
2. Select "Client HC Report"

**Screenshot Reference:** See Client Headcount Report Interface (Figure 8.1)

#### Generating a Client Report

Follow these steps to create a report:

1. **Set Report Date:**
   - Click "As-Of Date" field
   - Select the desired date
   - System retrieves snapshot data from that date

2. **Filter by Company (Optional):**
   - Click "Filter by Company" dropdown
   - Select specific company or "All Companies"
   - Leave as "All Companies" to include all companies

3. **Generate Report:**
   - Click "Generate Report" button
   - System processes the request
   - Results display in table below

4. **View Report Results:**
   - Table shows clients as of selected date
   - Columns: Client, Company, Headcount, Active
   - Shows exact headcount for that specific date

#### Understanding Report Data

**Client:** Name of the client organization
**Company:** Company managing that client
**Headcount:** Total personnel assigned to client
**Active:** Number actively assigned (vs. floating)

#### Clearing and Resetting

1. Click "Clear" button to reset all filters
2. Date reverts to today
3. Company filter returns to "All Companies"
4. Table clears (ready for new report)

#### Exporting Report to CSV

1. Click "Export CSV" button
2. File downloads with current report data
3. Use for external analysis or sharing with stakeholders

### TV Map Display

#### Purpose

Display real-time headcount information on TV screens or large monitors for:
- Real-time monitoring in control rooms
- Department displays
- Executive dashboards
- Public information displays

#### Accessing TV Map Display

1. Click "HEADCOUNT" in the sidebar
2. Select "TV Map Display"

**Screenshot Reference:** See TV Map Display (Figure 9.1)

#### TV Display Features

**Header Information:**
- **Title:** "Headcount Tracker"
- **Status:** "LIVE" indicator (green = currently updating)
- **Current Time:** Real-time clock display
- **Current Date:** Full date format
- **Last Updated:** Timestamp of last data refresh

**Main Metrics:**
- **TOTAL MANPOWER:** Grand total headcount (e.g., 403)

**Company Cards:**
Display headcount and site count for each company:
- Prime: 167 headcount (3 sites)
- Primus: 211 headcount (8 sites)
- Niupro: 25 headcount (1 site)

**Site Details Section:**
Shows individual site information:
- Site Name | Client Name | Personnel Count
- Example: "bdo luzon | BDO Unibank | 35 personnel"

**Navigation Controls:**
- Plus (+) button: Next set of sites
- Minus (-) button: Previous set of sites
- Auto-scrolls through all sites

#### Using TV Display

**Installation:**
1. Connect to a large display/TV
2. Open browser on the TV computer
3. Navigate to TV Map Display
4. The display auto-updates every minute (or as configured)

**Customization:**
- Large font sizes for readability
- High-contrast colors for visibility
- Real-time data updates
- Suitable for 24/7 monitoring

---

## Activity and Auditing

### Understanding the Activity Log

The Activity Log provides a complete audit trail of all system changes, enabling:
- Accountability tracking
- Change history verification
- User activity monitoring
- Compliance and regulatory reporting

### Accessing Activity Log

1. Click "HEADCOUNT" in the sidebar
2. Select "Activity Log"

**Screenshot Reference:** See Activity Log Interface (Figure 10.1)

### Activity Log Overview

At the top of the page, you see summary metrics:

**Total Records:** 28
- All activity events in the system

**Created:** 12
- New records added

**Updated:** 16
- Existing records modified

**Deleted:** 0
- Records removed

### Activity Log Data

The Activity Log table displays:

| Column | Description |
|--------|-------------|
| Action | What was done (Create, Update, Delete, etc.) |
| Type | Category of change (Site, Company, Headcount, etc.) |
| Description | Details of what was changed |
| Performed By | User who made the change |
| IP Address | Network address of the user |
| Timestamp | Date and time of change |

### Filtering Activities

#### By Action Type

1. Click "All Actions" dropdown
2. Select specific action:
   - Create
   - Update
   - Delete
   - Edit
   - Other actions

3. Table filters to show only that action type

#### By Change Type

1. Click "All Types" dropdown
2. Select category:
   - Site changes
   - Company changes
   - Headcount adjustments
   - Location changes
   - User changes

3. Results filter accordingly

### Searching Activity Log

1. Use the search box if available
2. Type keywords related to the change
3. Results filter to matching records
4. Scroll through results

### Example Activity Log Entries

| Action | Type | Description | Performed By | Timestamp |
|--------|------|-------------|--------------|-----------|
| Create | Site | New site "BGC" created | Amy Elsner | 2026-04-20 10:30:45 |
| Update | Headcount | Added 5 to Prime at BGC | Amy Elsner | 2026-04-21 14:15:20 |
| Update | Site | Edited coordinates for bdo luzon | Amy Elsner | 2026-04-22 09:45:30 |
| Delete | Client | Removed test client | Admin User | 2026-04-23 16:22:10 |

### Using Activity Log for Compliance

1. **Track Changes:** See who changed what and when
2. **Audit Trail:** Verify data integrity
3. **User Accountability:** Monitor user activities
4. **Troubleshooting:** Find when issues occurred
5. **Reporting:** Generate compliance reports

### Exporting Activity Data

Activity Log data can typically be exported:

1. Look for "Export" button or option
2. Select export format (usually CSV)
3. File downloads with all activity data
4. Use for compliance documentation

---

## User Management

### Understanding User Roles

The system supports multiple user roles with different permissions:

**Webmaster/Administrator**
- Full access to all features
- Can create/edit/delete sites, companies, clients, locations
- Can manage other users
- Can adjust headcount
- Can view all reports

**Manager**
- Access to view assigned areas
- Can generate reports
- Limited editing capabilities
- Cannot manage users

**Employee**
- Read-only access
- Can view dashboards and reports
- Cannot make changes to data

### Accessing User Management

1. Click "USER MANAGEMENT" in the sidebar
2. You will see:
   - **List:** View all users in the system
   - **Create:** Add new users

### Viewing Users

1. Click "USER MANAGEMENT > List"
2. The Users page displays all system users

**User Information Displayed:**
- User name
- Email address
- Role/Permission level
- Status (active/inactive)
- Last login date
- Actions (Edit, Deactivate, etc.)

### Creating a New User

To add a new user to the system:

1. Click "USER MANAGEMENT > Create"
2. Fill in the user information form:

   **Required Fields:**
   - **First Name:** User's given name
   - **Last Name:** User's surname
   - **Email:** Unique email address
   - **Password:** Initial password (user should change on first login)
   - **Confirm Password:** Verify password entry

   **Role Selection:**
   - Select user role:
     - Webmaster (full access)
     - Manager (limited access)
     - Employee (read-only)

3. Click "Create User" or "Save"
4. User is added to the system
5. User receives email with login credentials

### Editing User Information

To modify an existing user's details:

1. Locate user in Users list
2. Click "Edit" button for that user
3. Modify fields as needed:
   - Name
   - Email
   - Role
   - Status

4. Click "Save" or "Update"
5. Changes take effect immediately

### Deactivating Users

To prevent a user from accessing the system:

1. Find the user in the Users list
2. Click "Deactivate" or toggle Status to "Inactive"
3. Confirm the action
4. User cannot log in; no data is deleted

### Resetting User Passwords

If a user forgets their password:

1. Locate user in Users list
2. Click "Reset Password" option
3. System sends password reset email to user
4. User follows link to create new password
5. Or administrator can set temporary password

### Viewing User Profile

To see your own user profile:

1. Click user profile icon (initials) in top-right corner
2. Click "Profile" from dropdown menu
3. See your account details:
   - Name: Benedict Aquino (example)
   - Email: benchakino04@gmail.com
   - Role: Webmaster

---

## Customization and Settings

### Accessing Settings

**Method 1: Settings Gear Icon**
1. Click the Settings (gear) icon in the top navigation bar
2. Settings panel opens with customization options

**Method 2: User Profile Menu**
1. Click user profile icon in top-right corner
2. Click "Settings" from dropdown menu
3. Settings page displays

**Screenshot Reference:** See Settings and Customization (Figure 11.1)

### Theme Customization

#### Selecting a Color Theme

The system offers 20+ color themes to match your preferences:

**Available Themes:**
- Noir (dark, professional)
- Emerald (green, calming)
- Green (bright green)
- Lime (lime green)
- Orange (vibrant orange)
- Amber (warm amber)
- Yellow (bright yellow)
- Teal (teal/cyan)
- Cyan (bright cyan)
- Sky (light blue)
- Blue (primary blue)
- Indigo (deep indigo)
- Violet (purple/violet)
- Purple (purple)
- Fuchsia (bright magenta)
- Pink (light pink)
- Rose (rose red)
- Slate (gray/slate)
- Gray (neutral gray)
- Zinc (metallic gray)
- Neutral (beige/neutral)
- Stone (stone gray)
- Soho (professional)
- Viva (vibrant)
- Ocean (ocean blue)

**To Change Theme:**
1. Access Settings
2. Locate "Theme" section
3. View thumbnail previews of available themes
4. Click desired theme
5. Interface updates immediately with new colors

#### Light/Dark Mode Toggle

1. In Settings, find "Theme Mode" or "Appearance" section
2. Toggle between:
   - **Light Mode:** Light background, dark text (default)
   - **Dark Mode:** Dark background, light text
3. Entire interface updates to selected mode
4. Setting persists across sessions

### Sidebar Layout Options

Customize how the sidebar navigation menu displays:

**Layout Options:**
- **Static:** Sidebar always visible, takes up screen space
- **Overlay:** Sidebar slides over content when opened
- **Slim:** Narrow sidebar with icons only
- **Slim+:** Narrow sidebar with expanded tooltips
- **Reveal:** Hidden sidebar slides out on hover
- **Drawer:** Mobile-style drawer menu

**To Change Layout:**
1. Access Settings
2. Find "Sidebar Layout" section
3. Click desired layout option
4. Layout updates immediately

### Sidebar Position

Choose which side of the screen the sidebar appears:

**Options:**
- **Start:** Left side (default for LTR languages)
- **End:** Right side (default for RTL languages)

### Display Settings

**Rows Per Page**
Control how many rows display in data tables:
1. Locate "Rows Per Page" setting
2. Select number (10, 25, 50, 100, etc.)
3. Tables update to show selected number of rows

**Language/Localization**
If available, select your preferred language for the interface.

### Saving Your Settings

Settings are typically saved automatically when you make selections. Your customizations persist across:
- Session exits/logins
- Browser refreshes
- Multiple days

---

## Troubleshooting and FAQs

### Common Issues and Solutions

#### Issue: Cannot Login

**Symptoms:** "Invalid credentials" message or login page repeats

**Possible Causes:**
1. Incorrect email address
2. Wrong password
3. Caps Lock enabled
4. Account not created yet
5. Account deactivated

**Solutions:**
1. Verify email address is spelled correctly
2. Check that Caps Lock is OFF
3. Carefully re-enter password
4. Click "FORGOT PASSWORD?" link to reset
5. Contact system administrator to verify account status

#### Issue: Blank Dashboard or Missing Data

**Symptoms:** Dashboard appears but shows no data or metrics

**Possible Causes:**
1. Page still loading
2. Network connectivity issue
3. Browser cache problem
4. Missing permissions

**Solutions:**
1. Wait 5-10 seconds for page to fully load
2. Check your internet connection
3. Clear browser cache:
   - Chrome: Settings > Privacy > Clear browsing data
   - Firefox: History > Clear Recent History
4. Refresh the page (F5 or Ctrl+R)
5. Try a different browser
6. Contact administrator if issue persists

#### Issue: Tables Not Displaying Correctly

**Symptoms:** Table shows no rows or appears broken

**Possible Causes:**
1. Filter is too restrictive
2. Data doesn't exist for selected criteria
3. Browser display issue
4. Search field has text that matches nothing

**Solutions:**
1. Clear all filters (click "Clear All" or reset filters)
2. Check that you're viewing correct section
3. Refresh the page
4. Check browser compatibility (use recent version of Chrome, Firefox, Safari, or Edge)
5. Clear browser cache

#### Issue: Slow Performance

**Symptoms:** System responds slowly, pages take long to load

**Possible Causes:**
1. Slow internet connection
2. Browser has too many extensions
3. Too much data in table (old data)
4. Server-side issue

**Solutions:**
1. Check your internet speed
2. Disable unnecessary browser extensions
3. Use date filters to reduce data displayed
4. Close unused browser tabs
5. Try during off-peak hours
6. Contact administrator if persists

#### Issue: Cannot Edit/Delete Records

**Symptoms:** Edit/Delete buttons disabled or don't work

**Possible Causes:**
1. Insufficient permissions for your role
2. Record is locked by another user
3. Record has dependent data
4. Browser JavaScript issue

**Solutions:**
1. Check your user role (ask administrator if you need more permissions)
2. Wait a few minutes and try again
3. Check if other records depend on this one
4. Try a different browser
5. Clear cache and cookies
6. Contact administrator

#### Issue: Export to CSV Not Working

**Symptoms:** Export button doesn't download file

**Possible Causes:**
1. Pop-up blocker enabled
2. Download folder is full or locked
3. Browser incompatibility
4. Large dataset taking too long

**Solutions:**
1. Check browser pop-up blocker settings:
   - Chrome: Allow downloads from this site
   - Firefox: Check Download settings
2. Verify you have storage space on your computer
3. Use latest version of modern browser
4. Try reducing data with filters before exporting
5. Wait longer for download to complete

#### Issue: Geographic Coordinates Not Displaying

**Symptoms:** Latitude/Longitude fields empty or showing 0

**Possible Causes:**
1. Data not entered when site was created
2. Database corruption
3. Field validation error

**Solutions:**
1. Edit the site and enter coordinates from Google Maps
2. Use search "[City Name] coordinates" to find correct values
3. Re-save the site with valid coordinates
4. Contact administrator if multiple sites affected

### Frequently Asked Questions (FAQs)

**Q: How often are headcount snapshots taken?**
A: The system takes automatic daily snapshots. You can also manually take snapshots anytime from the Headcount Snapshots page by clicking "Take Snapshot Now."

**Q: Can I undo a headcount adjustment I just made?**
A: The system doesn't have a direct "undo" feature. To correct a mistake:
1. Create an opposite adjustment (subtract what you added or vice versa)
2. Contact your administrator if you need to edit historical data

**Q: What's the difference between Active and Floating headcount?**
A: Active headcount = personnel actively assigned to a site. Floating headcount = personnel temporarily unassigned or in transition. Both count toward total, but they're tracked separately for planning purposes.

**Q: Can I see headcount for a specific date in the past?**
A: Yes. Use the Client Headcount Report feature:
1. Go to Client Headcount Report
2. Set "As-Of Date" to the historical date
3. System retrieves snapshot data from that date

**Q: How do I export all site data for external use?**
A: From the Site Management page, click the "Export" button. A CSV file downloads with all site information including geographic coordinates.

**Q: What permissions do I need to edit sites?**
A: Generally, Webmaster and Manager roles can edit sites. Employee roles have read-only access. Contact your administrator if you don't have edit permissions.

**Q: Can I filter reports by specific date ranges?**
A: Yes. Use the date filters available in:
- Analytics Dashboard (7 Days, 30 Days, 90 Days, All)
- Client Headcount Report (As-Of Date field)
- Headcount Snapshots (date range filters)

**Q: What happens if I delete a site?**
A: Deleting a site removes it from the system permanently, along with any data associated with it. The action is recorded in the Activity Log. Be certain before confirming deletion.

**Q: How can I see who made changes to the system?**
A: Review the Activity Log. It shows:
- What was changed
- Who made the change
- When it was changed
- What the change was

**Q: Is there a way to print reports?**
A: Yes. Most reports can be printed using your browser's print function (Ctrl+P or Cmd+P). Select "Save as PDF" to create a digital copy.

**Q: Can I customize which columns display in tables?**
A: This depends on your browser and the specific table. Some tables may allow column hiding. Check for a column settings icon in the table header.

**Q: What if I need to add many sites at once?**
A: You would typically need to:
1. Create sites one at a time using the "New Site" button, or
2. Contact administrator about bulk import capabilities

**Q: How do I change my password?**
A: Method 1 (from dashboard):
1. Click your profile icon (top-right)
2. Click "Settings"
3. Look for "Change Password" option

Method 2 (forgot password):
1. On login page, click "FORGOT PASSWORD?"
2. Enter your email
3. Follow reset link in email

**Q: Can I access the system on mobile devices?**
A: Yes. The system is mobile-responsive and can be accessed from tablets and smartphones. The layout adapts to smaller screens.

**Q: What if I see an error message "NOT FOUND"?**
A: This usually means:
1. You navigated to a page that doesn't exist
2. A record you tried to access was deleted
3. You don't have permission to access that page

Click "GO BACK TO DASHBOARD" to return to the main interface.

**Q: How often does the TV Map Display update?**
A: Real-time updates, typically every 1-2 minutes. The "Last Updated" timestamp shows when data was last refreshed.

**Q: What should I do if the system keeps timing out?**
A:
1. Check your internet connection
2. Refresh the page
3. Log out and log back in
4. Try during a less busy time
5. Contact your system administrator

---

## Best Practices

### Data Management Best Practices

#### 1. Regular Headcount Audits

**Why:** Ensures accuracy of personnel data

**How:**
- Review headcount metrics weekly
- Compare Active vs. Floating counts
- Verify totals match your operational records
- Investigate discrepancies immediately
- Use Headcount Snapshots to track trends

#### 2. Consistent Site Information

**Why:** Ensures data quality and reliability

**How:**
- Use consistent naming conventions for sites
- Include company and region in site names
- Always provide accurate geographic coordinates
- Update site information when locations change
- Delete unused or closed sites promptly

#### 3. Timely Headcount Adjustments

**Why:** Keeps system data current

**How:**
- Record adjustments same day they occur
- Use clear descriptions in notes field
- Verify adjustment before submitting
- Review Activity Log regularly for accuracy
- Keep floating personnel assignments current

#### 4. Regular Snapshots

**Why:** Enables trend analysis

**How:**
- Take manual snapshots weekly or monthly
- Use snapshots for reporting and analysis
- Export snapshot data for external use
- Monitor trends for planning purposes

### User Management Best Practices

#### 1. Access Control

**Why:** Maintains security and data integrity

**How:**
- Assign only necessary permissions to each user
- Use appropriate role levels (Webmaster, Manager, Employee)
- Deactivate users who leave organization
- Regularly review user list for accuracy
- Don't share login credentials

#### 2. Password Security

**Why:** Protects account and system access

**How:**
- Change default password immediately on first login
- Use strong passwords (mix of letters, numbers, symbols)
- Never share your password
- Reset password if compromised
- Change password periodically

#### 3. User Account Maintenance

**Why:** Ensures system remains manageable

**How:**
- Create new user accounts for new personnel
- Update user information when roles change
- Deactivate accounts for terminated employees
- Review user activity periodically
- Keep contact information current

### Reporting Best Practices

#### 1. Regular Dashboard Review

**Why:** Stays informed of organizational metrics

**How:**
- Review Analytics Dashboard daily or weekly
- Pay attention to trends
- Investigate unusual spikes or drops
- Share metrics with stakeholders
- Use for capacity planning

#### 2. Client Report Generation

**Why:** Provides client-specific insights

**How:**
- Generate reports on regular schedule (weekly/monthly)
- Use consistent date ranges for comparison
- Filter by company to isolate data
- Export for external distribution
- Archive reports for record-keeping

#### 3. Activity Log Review

**Why:** Maintains audit trail and accountability

**How:**
- Review Activity Log regularly
- Verify all changes are authorized
- Investigate unusual activities
- Keep logs for compliance
- Export for record retention

### Workflow Best Practices

#### 1. Site Addition Process

**Best Practice Workflow:**
1. Plan site with geographic location identified
2. Determine company and client relationship
3. Verify geographic coordinates from reliable source
4. Enter site information in system
5. Verify display in Site Management and Dashboard
6. Document creation in project notes

#### 2. Headcount Adjustment Process

**Best Practice Workflow:**
1. Receive adjustment request with details
2. Verify personnel and site information
3. Determine adjustment type (Addition, Subtraction, Floating)
4. Record adjustment in system with notes
5. Verify update in relevant metrics
6. Notify affected parties of changes
7. Keep external records synchronized

#### 3. Report Generation Process

**Best Practice Workflow:**
1. Determine report requirements and scope
2. Select appropriate report type
3. Set date range and filters
4. Generate report
5. Verify data accuracy
6. Export if needed for distribution
7. Distribute to stakeholders
8. Archive report copy

### System Security Best Practices

#### 1. Login Security

**Do:**
- Log in from secure, private networks
- Use official company devices when possible
- Log out when leaving your desk
- Report suspicious login attempts immediately
- Use strong, unique passwords

**Don't:**
- Share login credentials with others
- Use simple/obvious passwords
- Log in on public WiFi networks
- Leave session active unattended
- Use the same password across systems

#### 2. Data Protection

**Do:**
- Use the system for intended purposes only
- Protect printed reports
- Store exported data securely
- Back up important data
- Report suspected data breaches

**Don't:**
- Share access credentials
- Download/copy sensitive data unnecessarily
- Print reports and leave unattended
- Store passwords in unsecured files
- Ignore security warnings

#### 3. System Health

**Do:**
- Report errors and issues promptly
- Keep browser and software updated
- Clear browser cache regularly
- Notify administrator of suspicious activity
- Follow organizational IT policies

**Don't:**
- Ignore system error messages
- Access system through suspicious links
- Disable security features
- Use outdated browser versions
- Ignore administrator advisories

---

## Glossary

### A

**Active Headcount**
Personnel actively assigned to a site with full responsibility and accountability.

**Activity Log**
System record of all changes made to data, including who made changes, what changed, and when.

**Analytics Dashboard**
Main dashboard displaying headcount metrics, charts, trends, and site overview.

**As-Of Date**
Specific date for which a report is generated, showing system state at that point in time.

**Audit Trail**
Complete record of all system activities for accountability and compliance purposes.

### C

**Client**
Organization served by a company at operational sites. Multiple clients per company.

**Company**
Operating organization managing personnel and sites (e.g., Prime, Primus, Niupro).

**Coordinate/Coordinates (Latitude/Longitude)**
Geographic position used to identify exact location of a site.

**CSV**
Comma-Separated Values file format used for data export, compatible with spreadsheet applications.

### D

**Dashboard**
Main interface displaying system metrics, charts, and overview information.

**Dark Mode**
Interface display option with dark background and light text for reduced eye strain.

**Delete Selected**
Bulk action to remove multiple items at once.

### E

**Export**
Function to download system data to external file (typically CSV format).

### F

**Filter**
Option to display only data matching specific criteria (date, company, region, etc.).

**Floating Headcount**
Personnel temporarily unassigned or in transition, tracked separately from active headcount.

### G

**Geographic Coordinates**
Latitude and longitude values identifying exact position on Earth.

**Grand Total**
Total headcount across entire organization.

### H

**Headcount**
Total number of personnel assigned to sites or companies.

**Headcount Adjustments**
Process of adding, removing, or reassigning personnel in the system.

**Headcount Snapshot**
Point-in-time capture of headcount status, used for trend analysis.

### L

**Latitude**
North-South geographic coordinate.

**Light Mode**
Interface display option with light background and dark text (default).

**Location**
Geographic city, municipality, or province in the location database.

**Longitude**
East-West geographic coordinate.

### M

**Metrics**
Key numerical measurements displayed on dashboard (headcount, sites, etc.).

### P

**Pagination**
Navigation through large datasets using page numbers and next/previous buttons.

### R

**Role**
User permission level determining what features they can access (Webmaster, Manager, Employee).

**Row**
Horizontal line of data in a table containing information for one item.

### S

**Search**
Function to find specific items by typing keywords.

**Site**
Physical location where personnel are assigned and services delivered.

**Site Management**
Section of system for viewing, creating, editing, and deleting sites.

**Snapshot**
Captured state of headcount at specific point in time for trend analysis.

**Sort**
Arrange table data by column in ascending or descending order.

### T

**Timestamp**
Date and time when an action occurred in the system.

**Total Headcount**
Complete count of all personnel across entire organization.

**Trend**
Pattern of headcount changes over time, indicating increase, decrease, or stability.

**TV Map Display**
Real-time display mode suitable for monitors, showing live headcount information.

### U

**UI**
User Interface - visual elements and layout users interact with.

**User Role**
Permission level assigned to user account (Webmaster, Manager, Employee).

### W

**Webmaster**
Administrative user role with full access to all system features.

### Z

**Zoom**
Browser function to increase or decrease text and element size for visibility.

---

## Additional Resources

### Getting Help

**In-System Help:**
1. Click UTILITIES > Documentation for system documentation
2. Hover over field labels for tooltips
3. Check this manual for detailed instructions

**Contact Support:**
1. Click user profile icon > "Support" option
2. Submit support request with details
3. Administrator will assist

### Related Documentation

- System Research Documentation: `CARBOOKING_SYSTEM_RESEARCH.md`
- UI/UX Analysis: `UI_UX_ANALYSIS.md`
- Screenshots Index: `SCREENSHOTS_INDEX.md`

### System Requirements

**Browser Requirements:**
- Chrome (version 90+)
- Firefox (version 88+)
- Safari (version 14+)
- Edge (version 90+)

**Internet Connection:**
- Stable connection recommended
- Minimum 2 Mbps for optimal performance

**Device Requirements:**
- Desktop, laptop, tablet, or smartphone
- Screen size: 320px minimum width

### Keyboard Shortcuts (Common Browser Functions)

| Action | Windows | Mac |
|--------|---------|-----|
| Refresh Page | F5 or Ctrl+R | Cmd+R |
| Clear Cache | Ctrl+Shift+Del | Cmd+Shift+Delete |
| Print | Ctrl+P | Cmd+P |
| Find | Ctrl+F | Cmd+F |
| New Tab | Ctrl+T | Cmd+T |

---

## Document Information

**Manual Title:** Employee Kiosk System - Comprehensive User Manual

**Version:** 1.0

**Date Created:** 2026-04-29

**Target Audience:** All system users (Administrators, Managers, Employees)

**Document Status:** Complete and Ready for Use

**Next Review:** 2026-07-29

---

## Change History

| Version | Date | Changes | Author |
|---------|------|---------|--------|
| 1.0 | 2026-04-29 | Initial comprehensive manual | Technical Writer |

---

## Appendix: Screenshots Reference

### Available Screenshots

The following screenshots are referenced throughout this manual:

**Figure 1.1:** Login Interface (screenshot-1777423409828.png)
**Figure 2.1:** Analytics Dashboard Overview (screenshot-1777423540101.png)
**Figure 2.2:** Full Dashboard View (screenshot-1777424950515.png)
**Figure 3.1:** Site Management Interface (screenshot-1777425550788.png)
**Figure 4.1:** Company & Client Management (screenshot-1777426048222.png)
**Figure 5.1:** Headcount Adjustments Interface (screenshot-1777426118507.png)
**Figure 6.1:** Location Management Interface (screenshot-1777426291369.png)
**Figure 7.1:** Headcount Snapshots (screenshot-1777426474070.png)
**Figure 8.1:** Client Headcount Report (screenshot-1777426520745.png)
**Figure 9.1:** TV Map Display (screenshot-1777426557255.png)
**Figure 10.1:** Activity Log Interface (screenshot-1777426451609.png)
**Figure 11.1:** Settings and Customization (screenshot-1777423801316.png)

All screenshots are located in: `/output/`

---

**End of User Manual**

For questions or feedback about this manual, please contact your system administrator.

